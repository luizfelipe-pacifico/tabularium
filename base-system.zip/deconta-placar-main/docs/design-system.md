# Design System — Placar DêConta

Guia único de layout e design do front-end. **Toda nova tela ou componente deve
seguir estas regras** para manter proporção, espaçamento e ritmo visual
consistentes em todo o app.

> Escopo: este documento cobre **layout, proporção, espaçamento, hierarquia e
> responsividade**. Ele **não** redefine cores nem fontes — essas já vivem nos
> tokens de `src/index.css` (`--primary`, `--card`, famílias Sora / Manrope /
> JetBrains Mono) e não devem ser alteradas sem uma decisão de branding.

---

## 1. Princípios (como aplicamos)

| Princípio | Como se manifesta aqui |
|-----------|------------------------|
| **Contraste** | Título de página (`.page-heading`) domina; overline (`.section-label`) e legenda (`.page-lead`) são secundários. Peso (`font-extrabold`) reservado para números e títulos. |
| **Alinhamento** | Tudo mora numa coluna central (`.app-container`). O gutter da página (`--app-page-pad`) é o mesmo do header, então o título do header alinha com o conteúdo. |
| **Proximidade** | Blocos relacionados ficam juntos com `gap` pequeno; seções distintas usam `--app-section-gap`. Nunca misture margens soltas (`mt-6`) com gap de flex/grid. |
| **Repetição** | Um único shell de página, um único tamanho de título, uma única escala de espaçamento e raio. Cards sempre usam `.app-panel` ou `rounded-2xl border border-border`. |
| **Equilíbrio** | Grids assimétricos usam frações declaradas (`minmax(0,1.2fr) minmax(0,0.8fr)`) em vez de larguras mágicas. Ícone + texto sempre com `items-center`. |
| **Hierarquia** | Overline → Título → Legenda → Conteúdo. Um `<h1>` por página, `<h2>` para títulos de card/seção, texto em `text-sm`. |
| **Respiro / Espaço em branco** | Nada encosta na borda do container. O header, a logo e os controles têm margem de segurança contra o topo/laterais da janela (ver §11). Espaço vazio é intencional, não desperdício. |

---

## 2. Escala global (a peça central)

Toda a UI é dirigida por **dois multiplicadores** em `:root`:

```css
--app-ui-scale: 0.86;   /* escala tokens de layout (sidebar, header, gutter, raio, controles) */
--app-font-scale: 0.91; /* escala a raiz de fonte -> todo rem/tamanho de texto acompanha */
```

Como `html { font-size: calc(16px * var(--app-font-scale)) }`, **qualquer valor
em `rem` (incluindo o espaçamento do Tailwind) encolhe junto** quando reduzimos a
escala. Isso permite “diminuir tudo” num único lugar.

### Responsividade (encolher em telas menores)

Já configurado em `src/index.css`. Não replique isso em componentes — deixe o
global cuidar:

| Largura da viewport | `--app-ui-scale` | `--app-font-scale` |
|---------------------|-----------------:|-------------------:|
| padrão (> 1440px)   | 0.86             | 0.91               |
| ≤ 1440px            | 0.82             | 0.88               |
| ≤ 1180px            | 0.78             | 0.85               |
| ≤ 960px             | 0.74             | 0.82               |

| Altura da viewport | `--app-font-scale` |
|--------------------|-------------------:|
| ≤ 780px            | 0.84               |
| ≤ 680px            | 0.80               |

> **Regra:** para fazer algo responsivo, prefira `rem`/tokens de escala a
> breakpoints manuais. Só use `md:`/`xl:` do Tailwind para **mudar o layout**
> (nº de colunas), não para reduzir tamanho.

---

## 3. Shell de página (obrigatório)

Toda página de conteúdo usa este esqueleto. As classes vivem em `src/index.css`.

```tsx
<div className="app-scroll">                     {/* raiz rolável + gutter padrão */}
  <div className="app-container animate-fade-in"> {/* coluna central, max-width e ritmo */}
    <header>
      <p className="section-label">Overline</p>
      <h1 className="page-heading mt-2">Título da página</h1>
      <p className="page-lead mt-2">Uma frase de contexto.</p>
    </header>

    <section className="grid gap-5 lg:grid-cols-3">…</section>
    <section>…</section>
  </div>
</div>
```

Regras do shell:

- **Um `<header>` embrulha overline + título + legenda.** Sem isso, o `gap` do
  container separa demais as três linhas.
- **Não coloque `mt-6` entre seções.** As seções são filhas diretas de
  `.app-container`; o `--app-section-gap` já cria o respiro.
- Dashboards largos adicionam `.app-container-wide` (máx. 1600px).
- Páginas “de trabalho” full-bleed (Operadores) e o Kanban (Demandas) não usam
  `.app-container` centralizado, mas **devem** usar `--app-page-pad` no gutter e
  `--app-section-gap` no ritmo vertical.

### Classes utilitárias disponíveis

| Classe | Papel |
|--------|-------|
| `.app-scroll` | Raiz de página: 100% altura, rola no Y, scrollbar fino, `padding: var(--app-page-pad)`. |
| `.app-container` | Coluna central: `max-width: var(--app-content-max)`, flex-col, `gap: var(--app-section-gap)`. |
| `.app-container-wide` | Modificador para dashboards: `max-width: var(--app-content-max-wide)`. |
| `.page-heading` | `<h1>` de página (Sora, `--app-page-title-size`, `line-height: 1.14`). |
| `.page-lead` | Legenda sob o título (`text-sm`, `muted-foreground`, `max-width: 64ch`). |
| `.section-label` | Overline em mono maiúsculo (já existente). |
| `.app-panel` | Card padrão com borda, raio de card e sombra. |

---

## 4. Tokens de layout

Definidos em `:root` (`src/index.css`). Prefira sempre o token à constante crua.

| Token | Valor base | Uso |
|-------|-----------|-----|
| `--app-page-pad` | `clamp(1rem, 0.6rem + 1.4vw, 40px*scale)` | Gutter da página e do header. |
| `--app-section-gap` | `1.35rem` (~20px) | Distância entre seções de uma página. |
| `--app-block-gap` | `1rem` (~16px) | Distância entre blocos dentro de uma seção. |
| `--app-content-max` | `1240px` | Largura máx. de páginas de conteúdo. |
| `--app-content-max-wide` | `1600px` | Largura máx. de dashboards. |
| `--app-page-title-size` | `1.9rem` (~28px) | Tamanho do `<h1>` de página. |
| `--app-sidebar-width` | `320px*scale` | Largura da barra lateral. |
| `--app-header-height` | `84px*scale` | Altura do header. Dá respiro de borda ao conteúdo (ver §11). A logo da sidebar usa o **mesmo** token para alinhar a borda inferior com o header. |
| `--app-control-height` | `40px*scale` | Altura de botões/inputs do chrome. |
| `--app-card-radius` | `24px*scale` | Raio dos cards (`.app-panel`). |

---

## 5. Escala de espaçamento

Base de **4px** (as classes do Tailwind já são múltiplos, e em `rem` acompanham a
escala de fonte). Use estes degraus — evite valores fora da escala.

| Token Tailwind | px (aprox.) | Uso típico |
|----------------|------------:|------------|
| `gap-1` / `p-1` | 4 | Ícone + label muito próximos. |
| `gap-2` / `p-2` | 8 | Itens de lista compactos, chips. |
| `gap-3` / `p-3` | 12 | Grid interno de card, linhas de dados. |
| `gap-4` / `p-4` | 16 | Padding de card médio, grid de blocos. |
| `gap-5` / `p-5` | 20 | Padding padrão de `.app-panel`, grid de seções. |
| `--app-section-gap` | ~20 | Ritmo entre seções (via `.app-container`). |

**Padrão de padding de card:** `p-5` para painéis, `p-4` para sub-cards, `p-3`
para itens de lista densos.

---

## 6. Tipografia (tamanhos, não famílias)

| Papel | Como escrever | Tamanho |
|-------|---------------|--------:|
| Título de página (`<h1>`) | `.page-heading` | ~28px (`--app-page-title-size`) |
| Título de card/seção (`<h2>/<h3>`) | `font-display text-lg font-extrabold` | 1.125rem |
| Número em destaque | `font-display text-3xl font-extrabold` | 1.875rem |
| Corpo | `text-sm` (+ `leading-6` em parágrafos) | 0.875rem |
| Legenda / meta | `text-xs text-muted-foreground` | 0.75rem |
| Overline / mono label | `.section-label` ou `font-mono-ui text-[10px]` uppercase `tracking-[0.24em]` | 0.625–0.688rem |

Regras:
- **Um `<h1>` por página**, sempre `.page-heading`.
- Famílias fixas: **Sora** para `h1–h4`, **Manrope** para corpo, **JetBrains
  Mono** para overlines/rótulos técnicos. Não introduza novas fontes.
- Micro-texto vive em `text-[10px]`/`text-[11px]` — não invente `text-[9px]`
  novos; reutilize o que existe.

---

## 7. Raio de borda

| Elemento | Raio |
|----------|------|
| Card / painel | `--app-card-radius` (`.app-panel`) ou `rounded-2xl` |
| Sub-card / campo | `rounded-xl` |
| Botão / chip / input | `rounded-lg` |
| Badge / tag pequena | `rounded-md` |

Não misture `rounded-md`/`lg`/`xl`/`2xl` aleatoriamente no mesmo nível de
hierarquia — escolha pelo tamanho do elemento.

---

## 8. Cards e superfícies

- Card principal: `.app-panel` (borda + raio de card + sombra).
- Superfície secundária dentro de um card: `rounded-2xl border border-border
  bg-background/35 p-4`.
- Estado hover elevado: adicionar `surface-motion` (transição + `translateY`).
- Sombra de destaque: `card-glow` / `card-glow-hover` (já tokenizadas).

---

## 9. Exceções intencionais

Nem toda tela usa o shell centralizado — e tudo bem, desde que seja consciente:

- **Configurações** — layout denso de tela única (`grid-rows-[auto_minmax(0,1fr)]`,
  sem rolagem de página). Mantém título compacto e `gap` menor de propósito para
  caber tudo sem scroll. Não force `.app-container` aqui.
- **Demandas / Histórico** — Kanban com rolagem interna das colunas; a página não
  rola, então usa `overflow-hidden` + `h-full`, mas segue `--app-page-pad` e
  `--app-section-gap`.
- **Operadores** — superfície de trabalho full-bleed (sem `max-width`), mas com
  gutter e ritmo padrão.
- **Login / Conexão de workspace** — telas de entrada com hero próprio
  (`--app-login-content-max`), fora do shell do app.

---

## 10. Checklist de PR (layout)

Antes de abrir PR que mexe em UI, confirme:

- [ ] Página usa `.app-scroll` + `.app-container` (ou uma exceção documentada).
- [ ] Um único `<h1>` com `.page-heading`; overline/legenda com `.section-label`/`.page-lead`.
- [ ] Espaçamento entre seções vem do `gap` do container, não de `mt-*` avulso.
- [ ] Espaçamentos, raios e tamanhos saem da escala/tokens deste guia.
- [ ] Nada de largura/altura “mágica” em px onde existe token.
- [ ] Cores e fontes inalteradas (usar tokens existentes).
- [ ] Testado em janela estreita (~1100px) e baixa (~700px): tudo encolhe junto,
      sem overflow horizontal.
- [ ] Nada de logo/título/controle colado na borda da janela — respeitar o
      respiro de borda (§11).
- [ ] Campos usam `.field-input` (foco em borda `primary`, sem `ring`); textura e
      superfícies seguem a base da Login (§12).

---

## 11. Margem de segurança (safe area) e marca

Princípio: **nenhum elemento de chrome (header, logo, controles de janela)
encosta na borda da janela.** Como o app é uma janela Electron sem moldura
(`frameless`, com `drag-region`), a barra do topo é a primeira coisa que toca o
limite da tela — então ela precisa de respiro embutido.

### Barra superior (header) e logo

- O header tem altura `--app-header-height` (**84px × scale**) e centraliza o
  conteúdo verticalmente (`items-center`) — isso cria a margem de segurança em
  cima e embaixo automaticamente. **Não** cole o conteúdo no topo com altura
  apertada.
- O bloco da logo na sidebar usa **o mesmo** `--app-header-height` com
  `items-center`, para que a borda inferior da logo alinhe exatamente com a do
  header (princípio de **alinhamento**).
- Padding horizontal do header = `--app-page-pad` (o mesmo gutter das páginas),
  para o título do header alinhar com o conteúdo abaixo e manter margem lateral.

### Dimensão da marca

- Logo (wordmark DêConta) na sidebar: **`h-11 w-40`** (`object-contain
  object-left`). Não reduzir para caber — a marca é âncora visual e precisa de
  presença. O rótulo "PLACAR" abaixo usa `text-[10px]` mono com
  `tracking-[0.34em]`.

### Futuro (PWA / mobile)

O roadmap prevê uma versão **PWA responsiva** (ver `evolucao_deconta_placar.md`,
§4.3). Quando isso acontecer, aplicar `env(safe-area-inset-*)` ao shell externo
para respeitar notch/barra de status em celulares — o mesmo princípio de margem
de segurança, estendido para telas com recortes. Em desktop esses insets são `0`,
então não afetam o layout atual.

---

## 12. Cor, contraste e textura — base: tela de Login

A **tela de Login é a referência canônica** de cor, contraste e textura. Todo o
sistema deve ler como uma continuação dela. **A paleta (matizes) não muda** —
seguimos os tokens de `:root`; o que padronizamos é *como* eles são aplicados.

### Textura ambiente (`.ambient-grid`)

Fundo canônico extraído da Login: uma malha fina tipo blueprint (grid de 72px em
`--border`) + **dois glows radiais de `--primary`** nos cantos (topo-esquerda
mais forte, base-direita) para profundidade.

- É **fonte única**: a classe `.ambient-grid` (em `index.css`) é usada pela
  Login, pelas telas de auth e pelo `<main>` do app. Não recriar o gradiente
  inline — reutilize a classe.
- Calibrada para densidade: os glows ficam em `~0.11–0.13` de opacidade, então
  aparecem nos espaços vazios (como na Login) sem poluir dashboards densos.
- Superfícies acima da textura (`.app-panel`, cards) permanecem opacas; a textura
  respira **entre** os elementos.

### Contraste de campos (`.field-input`)

O tratamento de input da Login é o padrão do sistema:

- Fill **`bg-card/70`** (card-tint, não `bg-background` nem `bg-secondary`).
- Borda **`border-input`** que vira **`primary` sólida no foco** — sem `ring`.
- Use a classe utilitária **`.field-input`** em todo `input`/`textarea`/busca.
  Para campos com ícone (estilo Login), envolva num wrapper
  `rounded-xl border border-input bg-card/70 focus-within:border-primary`.

> ❌ Não usar `focus:ring-*` nem fundos `bg-secondary`/`bg-background/xx` em
> campos — isso quebra a consistência de contraste com a Login.

### Regras de cor (dentro da paleta)

- **Foco = borda `primary`** (cyan), nunca ring difuso.
- **Superfícies interativas** usam tom de card (`bg-card/xx`), reservando
  `bg-background/xx` para leitura passiva.
- **Acento** sempre `primary`; estados usam os tokens semânticos
  (`success`/`warning`/`destructive`/`info`), nunca cores cruas.
- **CTA primário**: `bg-primary` + glow `shadow-[0_0_34px_hsl(var(--primary)/0.24)]`
  (mesmo brilho do botão "Entrar").

### Hierarquia de superfícies (contraste vertical)

Do fundo para a frente, cada camada clareia um pouco — cria profundidade sem
mudar matiz:

1. `.ambient-grid` (fundo) → `--background` + textura.
2. `.app-panel` / card → `--card` com leve gradiente.
3. Sub-superfície dentro do card → `bg-card/35` (login) para leitura.
4. Campo interativo → `.field-input` (`bg-card/70`), foco em `primary`.
