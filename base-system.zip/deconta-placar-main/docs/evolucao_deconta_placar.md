# Plano de Evolução Estratégica: DeConta Placar

Este documento apresenta uma análise detalhada e um roadmap para a transformação do **Placar DêConta** de uma ferramenta de visualização em um ecossistema completo de gestão de demandas, suporte e roadmap estratégico.

---

## 1. Auditoria do Estado Atual
Com base na análise do código-fonte, o projeto atual é uma aplicação robusta baseada em **Electron + Vite + React + TailwindCSS**, com as seguintes características:
*   **Fonte de Dados:** Integração via API com Google Apps Script (planilhas).
*   **Interface:** Uso de Shadcn UI com foco em dashboards de performance.
*   **Funcionalidades:** Gestão de demandas ativas/histórico, relatórios em PDF/PPTX e monitoramento de operadores.
*   **Limitação:** Atualmente funciona mais como um "espelho" de dados do que como um sistema de gestão transacional com lógica de negócio complexa integrada.

---

## 2. Análise de Referências (Benchmarking)

Para atender às suas necessidades, consolidamos o melhor de cada ferramenta citada:

| Ferramenta | O que absorver para o DêConta |
| :--- | :--- |
| **HubSpot / RD CRM** | Gestão de **Tickets/Suporte** com funis de atendimento, automação de e-mails e histórico centralizado do cliente. |
| **Trello / Monday** | Visualização em **Kanban** para o Roadmap e gestão de tarefas com prazos (SLA) e responsáveis claros. |
| **Notion** | Criação de **Trilhas de Roadmap** e documentação interna vinculada às tarefas. |
| **Slack** | Sistema de **Notificações em Tempo Real** e centralização de comunicações internas. |
| **Acessórias** | Foco em **Gestão de Prazos e Obrigações**, essencial para a parte de suporte com tempo de execução fixo. |
| **Samsung/Apple Notes** | Agilidade na captura de **Insights e Notas Rápidas** que podem ser convertidas em demandas futuramente. |

---

## 3. Roadmap de Implementação

### Fase 1: Gestão de Suporte e Atendimento (Curto Prazo)
O desafio é separar o "Atendimento" do "Desenvolvimento", mesmo sendo o mesmo executor.
*   **Níveis de Suporte:** Implementar triagem (N1: Atendimento/Dúvida, N2: Ajuste Técnico, N3: Bug Crítico).
*   **Tempo de Execução Fixo (SLA):** Configurar cronômetros para tipos de suporte específicos (ex: Reset de senha = 15min; Erro de cálculo = 2h).
*   **Previsão de Ação:** Campo de "Data Prevista" baseado na carga de trabalho atual do desenvolvedor.

### Fase 2: Roadmap e Trilhas Estratégicas (Médio Prazo)
*   **Trilhas do Roadmap:** Criar visões de "Linha do Tempo" (Gantt) para projetos grandes (ex: Nova versão do www.deconta.com.br).
*   **Gestão de Demandas vs. Tarefas:** Uma demanda de suporte pode gerar uma tarefa no roadmap de desenvolvimento.
*   **Priorização Automática:** Algoritmo que sugere o que fazer primeiro com base no impacto (DêConta) vs. urgência (Suporte).

### Fase 3: Inteligência e Integrações (Longo Prazo)
*   **ChatGPT Plus API:** 
    *   Sugestão automática de respostas para suporte.
    *   Resumo de demandas complexas.
    *   Geração de código/scripts para ajustes rápidos.
*   **Integração de E-mail (Google/SMTP):**
    *   Disparo de atualizações do sistema em HTML formatado.
    *   Sincronização de e-mails recebidos para criação automática de tickets.

---

## 4. Especificações Técnicas das Novas Funcionalidades

### 4.1. Integração ChatGPT Plus
Utilizar o SDK da OpenAI para criar um assistente dentro do Electron que lê o contexto da demanda atual e sugere uma solução ou redige o e-mail de resposta para o cliente.

### 4.2. Ecossistema Google & E-mail
*   **Autenticação:** Implementar **OAuth2 do Google** para que o usuário acesse sua conta e o app tenha permissão para ler/enviar e-mails e gerenciar o Google Drive/Calendar.
*   **E-mail HTML:** Integração com bibliotecas como `React-Email` ou `MJML` para garantir que as atualizações enviadas sejam profissionais e responsivas.

### 4.3. Multiplataforma e Responsividade
*   **Desktop (Windows/Mac/Linux):** O `electron-builder` já está presente. É necessário configurar os perfis de build para `.exe`, `.dmg` e `.deb`.
*   **Mobile:** O Electron **não roda nativamente em mobile**. 
    *   *Sugestão:* Desenvolver uma versão **Web Progressiva (PWA)** do frontend que compartilha a mesma API do desktop, permitindo acesso via navegador no celular com interface responsiva.

### 4.4. Níveis de Acesso
Implementar um sistema de **RBAC (Role-Based Access Control)**:
*   **Admin:** Visão total (Placar, Financeiro, Roadmap).
*   **Operador:** Visão apenas das suas demandas e tarefas.
*   **Cliente (Visualizador):** Acesso apenas ao status das suas solicitações.

---

## 5. Próximos Passos Recomendados

1.  **Refatoração do Backend:** Migrar da dependência direta de Planilhas para um Banco de Dados real (ex: Supabase ou SQLite local sincronizado) para suportar níveis de acesso e relações complexas.
2.  **Interface de Gestão:** Criar uma nova página de "Roadmap" inspirada no Monday.com.
3.  **Módulo de E-mail:** Iniciar a configuração do OAuth2 para o disparo de e-mails.

---
*Documento gerado para a evolução do ecossistema DêConta.*
