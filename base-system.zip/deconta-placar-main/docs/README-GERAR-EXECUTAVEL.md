# Guia Manual de Build e Executavel

Este arquivo foi criado para quem baixou o projeto do GitHub e quer gerar o
pacote executavel manualmente na propria maquina Windows.

## O que este projeto gera

Hoje o processo de distribuicao gera um pacote ZIP final:

- `dist_electron\Placar DeConta.zip`

Dentro dele fica o executavel do app:

- `Placar DêConta.exe`

Ou seja: o fluxo atual nao gera um instalador tradicional `.msi`.
Ele gera um pacote ZIP pronto para distribuir, extrair e executar.

## Requisitos

Antes de comecar, instale:

- `Git`
- `Node.js` 20 ou superior
- `npm` (normalmente ja vem com o Node)
- Windows 10 ou Windows 11

## 1. Baixar o projeto

Se ainda nao clonou:

```bash
git clone https://github.com/luizfelipe-pacifico/deconta-placar.git
cd deconta-placar
```

Se voce ja clonou antes:

```bash
git pull origin main
```

## 2. Instalar as dependencias

```bash
npm install
```

## 3. Validar o projeto antes do build

Opcional, mas recomendado:

```bash
npm test
```

Se quiser abrir o app em desenvolvimento:

```bash
npm run electron:dev
```

## 4. Gerar o pacote executavel manualmente

No Windows, rode:

```bash
npm run dist:win
```

Esse comando faz tudo em sequencia:

1. sincroniza a configuracao de distribuicao
2. compila o Electron
3. gera o build do frontend
4. empacota o app para Windows
5. cria o arquivo final `dist_electron\Placar DeConta.zip`

## 5. Onde fica o resultado

Quando terminar, procure este arquivo:

```text
dist_electron\Placar DeConta.zip
```

Depois:

1. extraia o ZIP
2. abra a pasta extraida
3. execute `Placar DêConta.exe`

## 6. Comandos uteis

Rodar apenas o build web + Electron:

```bash
npm run build
```

Gerar apenas a pasta desempacotada para inspecao:

```bash
npm run pack
```

## 7. Se der erro

Tente nesta ordem:

```bash
npm install
npm test
npm run build
npm run dist:win
```

Se ainda falhar, limpe as saidas e rode de novo:

```powershell
Remove-Item -Recurse -Force .\dist -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force .\dist_electron -ErrorAction SilentlyContinue
npm install
npm run dist:win
```

## 8. Prompt pronto para IA

Se quiser pedir ajuda para uma IA, copie e cole este prompt:

```text
Estou em um projeto Electron + React + Vite chamado Placar DeConta.
Baixei o repositorio do GitHub e quero gerar manualmente o pacote executavel
do Windows na minha maquina.

Contexto:
- sistema operacional: Windows
- gerenciador de pacotes: npm
- objetivo final: gerar o arquivo dist_electron\Placar DeConta.zip
- depois extrair e executar o arquivo Placar DêConta.exe

Quero que voce me guie passo a passo para:
1. instalar dependencias
2. validar o projeto
3. rodar o build correto
4. gerar o pacote Windows
5. verificar onde saiu o arquivo final
6. diagnosticar qualquer erro caso algum comando falhe

Se possivel, responda usando comandos prontos para PowerShell.
```

## 9. Resumo rapido

Se quiser o caminho mais curto:

```bash
git clone https://github.com/luizfelipe-pacifico/deconta-placar.git
cd deconta-placar
npm install
npm run dist:win
```

Arquivo final esperado:

```text
dist_electron\Placar DeConta.zip
```
