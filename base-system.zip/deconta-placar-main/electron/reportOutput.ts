import fs from "fs/promises";
import path from "path";

export function buildVersionedOutputPath(filePath: string, version: number) {
  const parsed = path.parse(filePath);
  const baseName = parsed.name.replace(/ \(\d+\)$/u, "");
  return path.join(parsed.dir, `${baseName} (${version})${parsed.ext}`);
}

export async function resolveAvailableOutputPath(
  filePath: string,
  pathExists: (candidate: string) => Promise<boolean> = defaultPathExists,
) {
  if (!(await pathExists(filePath))) {
    return filePath;
  }

  let version = 2;
  let candidate = buildVersionedOutputPath(filePath, version);

  while (await pathExists(candidate)) {
    version += 1;
    candidate = buildVersionedOutputPath(filePath, version);
  }

  return candidate;
}

async function defaultPathExists(candidate: string) {
  try {
    await fs.access(candidate);
    return true;
  } catch {
    return false;
  }
}
