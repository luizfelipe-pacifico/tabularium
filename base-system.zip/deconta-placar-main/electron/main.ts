import fs from "fs/promises";
import path from "path";
import { app, BrowserWindow, dialog, ipcMain, Menu } from "electron";
import PptxGenJS from "pptxgenjs";
import { resolveAvailableOutputPath } from "./reportOutput.js";
import {
  fetchFromSheet,
  getCurrentConfig,
  testSourceConnection,
  updateConfig,
} from "./sheetService.js";
import type { AppConfig } from "./appConfig.js";

type ReportOutputFormat = "pdf" | "pptx" | "jpeg";

interface ReportDocumentPayload {
  html: string;
  fileName?: string;
  outputFormat?: ReportOutputFormat;
  pdfOptions?: {
    landscape?: boolean;
    pageSize?: "A4" | { width: number; height: number };
    preferCSSPageSize?: boolean;
  };
  captureOptions?: {
    width: number;
    height: number;
  };
}

let mainWindow: InstanceType<typeof BrowserWindow> | null = null;
let syncTimer: NodeJS.Timeout | null = null;

function getWindowIconPath() {
  return path.join(__dirname, "assets", "app-icon.png");
}

function createWindow() {
  const window = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 1100,
    minHeight: 720,
    show: false,
    frame: false,
    autoHideMenuBar: true,
    titleBarStyle: "hidden",
    icon: getWindowIconPath(),
    backgroundColor: "#0c1423",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow = window;
  window.removeMenu();
  window.setMenuBarVisibility(false);

  const devUrl = process.env.VITE_DEV_SERVER_URL;
  const useDevServer = Boolean(devUrl);

  if (useDevServer && devUrl) {
    window.loadURL(devUrl);
    window.webContents.openDevTools({ mode: "detach" });
  } else {
    window.loadFile(path.join(__dirname, "../dist/index.html"));
  }

  window.once("ready-to-show", () => {
    window.show();
  });

  window.webContents.on(
    "did-fail-load",
    (
      _event: unknown,
      errorCode: number,
      errorDescription: string,
      validatedURL: string,
    ) => {
      console.error("[electron] failed to load", {
        errorCode,
        errorDescription,
        validatedURL,
      });
    },
  );

  window.on("closed", () => {
    mainWindow = null;
  });
}

function notifyUpdate(data: unknown) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send("data-updated", data);
  }
}

async function fetchAndNotify() {
  const data = await fetchFromSheet();
  notifyUpdate(data);
  return data;
}

async function scheduleSync() {
  const config = await getCurrentConfig();

  if (syncTimer) {
    clearInterval(syncTimer);
    syncTimer = null;
  }

  const intervalMinutes = Math.max(1, config.intervalo || 1);

  fetchAndNotify().catch((error) => {
    console.error("[electron] initial sync failed", error);
  });

  syncTimer = setInterval(() => {
    fetchAndNotify().catch((error) => {
      console.error("[electron] scheduled sync failed", error);
    });
  }, intervalMinutes * 60 * 1000);
}

async function saveReportDocument(payload: ReportDocumentPayload) {
  const html = payload.html?.trim();
  if (!html) {
    throw new Error("O documento em HTML nao foi informado.");
  }

  const outputFormat = payload.outputFormat ?? "pdf";
  const defaultFileName = sanitizeFileName(payload.fileName, outputFormat);
  const defaultPath = path.join(app.getPath("downloads"), defaultFileName);
  const saveDialogOptions = {
    defaultPath,
    filters: [getFileFilter(outputFormat)],
  };
  const saveResult = mainWindow
    ? await dialog.showSaveDialog(mainWindow, saveDialogOptions)
    : await dialog.showSaveDialog(saveDialogOptions);

  if (saveResult.canceled || !saveResult.filePath) {
    return {
      canceled: true,
      filePath: null,
    };
  }

  const outputPath = await resolveAvailableOutputPath(saveResult.filePath);

  const renderWindow = new BrowserWindow({
    show: false,
    useContentSize: true,
    width: payload.captureOptions?.width ?? 1440,
    height: payload.captureOptions?.height ?? 900,
    resizable: false,
    backgroundColor: "#07111d",
  });

  try {
    if (payload.captureOptions) {
      renderWindow.setContentSize(
        payload.captureOptions.width,
        payload.captureOptions.height,
      );
    }

    await renderWindow.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(html)}`);
    await renderWindow.webContents.executeJavaScript(
      `
        Promise.resolve(
          document.fonts && document.fonts.ready
            ? document.fonts.ready.then(() => true)
            : true,
        ).then(() => {
          document.documentElement.style.overflow = "hidden";
          document.body.style.overflow = "hidden";
          return true;
        });
      `,
    );
    await new Promise((resolve) => setTimeout(resolve, 120));

    if (outputFormat === "pdf") {
      const pdfBuffer = await renderWindow.webContents.printToPDF({
        printBackground: true,
        landscape: Boolean(payload.pdfOptions?.landscape),
        pageSize: payload.pdfOptions?.pageSize ?? "A4",
        preferCSSPageSize: Boolean(payload.pdfOptions?.preferCSSPageSize),
        margins: {
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
        },
      });

      await fs.writeFile(outputPath, pdfBuffer);
    } else {
      const image = await renderWindow.webContents.capturePage({
        x: 0,
        y: 0,
        width: payload.captureOptions?.width ?? 1440,
        height: payload.captureOptions?.height ?? 900,
      });

      if (outputFormat === "jpeg") {
        await fs.writeFile(outputPath, image.toJPEG(92));
      } else {
        await writePptxFromImage(outputPath, image.toPNG().toString("base64"));
      }
    }

    return {
      canceled: false,
      filePath: outputPath,
    };
  } finally {
    if (!renderWindow.isDestroyed()) {
      renderWindow.destroy();
    }
  }
}

async function writePptxFromImage(filePath: string, base64Png: string) {
  const pptx = new PptxGenJS();
  pptx.layout = "LAYOUT_WIDE";
  pptx.author = "Placar DeConta";
  pptx.company = "DeConta";
  pptx.subject = "Apresentacao executiva";
  pptx.title = "Placar DeConta";

  const slide = pptx.addSlide();
  slide.background = { color: "07111D" };
  slide.addImage({
    data: `data:image/png;base64,${base64Png}`,
    x: 0,
    y: 0,
    w: 13.333,
    h: 7.5,
  });

  await pptx.writeFile({ fileName: filePath });
}

function getFileFilter(format: ReportOutputFormat) {
  if (format === "pptx") {
    return { name: "PowerPoint", extensions: ["pptx"] };
  }

  if (format === "jpeg") {
    return { name: "Imagem JPEG", extensions: ["jpeg", "jpg"] };
  }

  return { name: "PDF", extensions: ["pdf"] };
}

function registerIpcHandlers() {
  ipcMain.handle("get-config", async () => getCurrentConfig());

  ipcMain.handle(
    "set-config",
    async (_event: unknown, config: Partial<AppConfig>) => {
      const savedConfig = await updateConfig(config);
      await scheduleSync();
      return savedConfig;
    },
  );

  ipcMain.handle("test-source-url", async (_event: unknown, url?: string) => {
    return testSourceConnection(url);
  });

  ipcMain.handle("fetch-data", async () => fetchFromSheet());
  ipcMain.handle("sync-now", fetchAndNotify);
  ipcMain.handle(
    "save-report-document",
    async (_event: unknown, payload: ReportDocumentPayload) =>
      saveReportDocument(payload),
  );
  ipcMain.handle("reload-app", () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.reloadIgnoringCache();
    }
  });
  ipcMain.handle("window-minimize", () => {
    mainWindow?.minimize();
  });
  ipcMain.handle("window-toggle-maximize", () => {
    if (!mainWindow || mainWindow.isDestroyed()) {
      return;
    }

    if (mainWindow.isMaximized()) {
      mainWindow.unmaximize();
      return;
    }

    mainWindow.maximize();
  });
  ipcMain.handle("app-quit", () => {
    app.quit();
  });
}

app.whenReady().then(async () => {
  Menu.setApplicationMenu(null);
  createWindow();
  registerIpcHandlers();
  await getCurrentConfig();
  await scheduleSync();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("window-all-closed", () => {
  if (syncTimer) {
    clearInterval(syncTimer);
    syncTimer = null;
  }

  if (process.platform !== "darwin") {
    app.quit();
  }
});

function sanitizeFileName(value: string | undefined, format: ReportOutputFormat) {
  const fallback = format === "pptx" ? "apresentacao-performance.pptx" : format === "jpeg" ? "apresentacao-performance.jpeg" : "relatorio-performance.pdf";
  const baseName = (value || fallback).replace(/[<>:"/\\|?*\u0000-\u001F]/g, "-").trim();

  if (!baseName) {
    return fallback;
  }

  if (format === "jpeg") {
    return /\.(jpeg|jpg)$/i.test(baseName) ? baseName : `${baseName}.jpeg`;
  }

  const expectedExtension = `.${format}`;
  return baseName.toLowerCase().endsWith(expectedExtension)
    ? baseName
    : `${baseName}${expectedExtension}`;
}
