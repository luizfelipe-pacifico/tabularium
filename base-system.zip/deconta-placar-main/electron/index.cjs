// CommonJS wrapper for ESM main module
const path = require("path");
const { pathToFileURL } = require("url");

(async () => {
  globalThis.__electronMain = require("electron");
  const mainModuleUrl = pathToFileURL(path.join(__dirname, "main.js")).href;
  await import(mainModuleUrl);
})();
