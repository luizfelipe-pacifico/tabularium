import path from "path";
import fs from "fs";
import { app } from "electron";
import initSqlJs, { Database } from "sql.js";

let db: Database | null = null;
let dbPath: string = "";
let isInitialized = false;

const initDb = async () => {
  if (isInitialized) return;
  
  dbPath = path.join(app.getPath("userData"), "deconta.db");
  const SQL = await initSqlJs();
  
  try {
    if (fs.existsSync(dbPath)) {
      const buffer = fs.readFileSync(dbPath);
      db = new SQL.Database(buffer);
    } else {
      db = new SQL.Database();
    }
  } catch {
    db = new SQL.Database();
  }

  // initialize tables
  if (db) {
    db.run(`
      CREATE TABLE IF NOT EXISTS config (
        key TEXT PRIMARY KEY,
        value TEXT
      );
      CREATE TABLE IF NOT EXISTS cache (
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message TEXT,
        level TEXT,
        timestamp INTEGER
      );
    `);
    saveDb();
  }
  
  isInitialized = true;
};

const saveDb = () => {
  if (db && dbPath) {
    try {
      const data = db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(dbPath, buffer);
    } catch (e) {
      console.error("Failed to save database:", e);
    }
  }
};

export async function getConfig(key: string) {
  if (!db) await initDb();
  if (!db) return null;
  
  try {
    const stmt = db.prepare("SELECT value FROM config WHERE key = ?");
    stmt.bind([key]);
    if (stmt.step()) {
      const row = stmt.getAsObject();
      stmt.free();
      const val = row.value as string;
      return val ? JSON.parse(val) : null;
    }
    stmt.free();
  } catch {
    // ignore
  }
  return null;
}

export async function setConfig(key: string, value: any) {
  if (!db) await initDb();
  if (!db) return;
  
  try {
    const str = JSON.stringify(value);
    db.run("INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)", [key, str]);
    saveDb();
  } catch (e) {
    console.error("Failed to set config:", e);
  }
}

export async function getCache(key: string) {
  if (!db) await initDb();
  if (!db) return null;
  
  try {
    const stmt = db.prepare("SELECT value FROM cache WHERE key = ?");
    stmt.bind([key]);
    if (stmt.step()) {
      const row = stmt.getAsObject();
      stmt.free();
      const val = row.value as string;
      return val ? JSON.parse(val) : null;
    }
    stmt.free();
  } catch {
    // ignore
  }
  return null;
}

export async function setCache(key: string, value: any) {
  if (!db) await initDb();
  if (!db) return;
  
  try {
    const str = JSON.stringify(value);
    const now = Date.now();
    db.run("INSERT OR REPLACE INTO cache (key, value, updated_at) VALUES (?, ?, ?)", [key, str, now]);
    saveDb();
  } catch (e) {
    console.error("Failed to set cache:", e);
  }
}

export async function log(message: string, level = "info") {
  if (!db) await initDb();
  if (!db) return;
  
  try {
    const ts = Date.now();
    db.run("INSERT INTO logs (message, level, timestamp) VALUES (?, ?, ?)", [message, level, ts]);
    saveDb();
  } catch (e) {
    console.error("Failed to log:", e);
  }
}

export { initDb as initDatabase };
