import {
  contextBridge,
  ipcRenderer,
  type IpcRendererEvent,
} from "electron";

contextBridge.exposeInMainWorld("electronAPI", {
  getConfig: () => ipcRenderer.invoke("get-config"),
  setConfig: (config: unknown) => ipcRenderer.invoke("set-config", config),
  testSourceUrl: (url?: string) => ipcRenderer.invoke("test-source-url", url),
  fetchData: () => ipcRenderer.invoke("fetch-data"),
  syncNow: () => ipcRenderer.invoke("sync-now"),
  saveReportDocument: (payload: unknown) => ipcRenderer.invoke("save-report-document", payload),
  reloadApp: () => ipcRenderer.invoke("reload-app"),
  minimizeWindow: () => ipcRenderer.invoke("window-minimize"),
  toggleMaximizeWindow: () => ipcRenderer.invoke("window-toggle-maximize"),
  onDataUpdate: (callback: (event: IpcRendererEvent, data: unknown) => void) =>
    ipcRenderer.on("data-updated", callback),
  offDataUpdate: (callback: (event: IpcRendererEvent, data: unknown) => void) =>
    ipcRenderer.removeListener("data-updated", callback),
  quit: () => ipcRenderer.invoke("app-quit"),
});
