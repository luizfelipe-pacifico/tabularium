import axios from "axios";
import { getCache, log, setCache } from "./db.js";
import {
  loadAppConfig,
  normalizeSourceUrl,
  saveAppConfig,
  type AppConfig,
} from "./appConfig.js";
import {
  adaptApiPayload,
  createEmptyAppData,
  isPartialApiPayload,
  mergeRemoteWithStoredData,
  normalizeStoredData,
  toAppDataSnapshot,
  type AppData,
} from "./dataAdapter.js";

const LAST_DATA_CACHE_KEY = "lastData";

export async function fetchFromSheet(): Promise<AppData> {
  const config = await loadAppConfig();
  const fonteUrl = normalizeSourceUrl(config.fonteUrl);
  const fetchedAt = new Date().toISOString();
  const cachedSnapshot = await getCache(LAST_DATA_CACHE_KEY);

  try {
    const response = await axios.get(fonteUrl, {
      timeout: 15000,
      maxRedirects: 5,
      responseType: "text",
      transformResponse: [(value) => value],
      params: {
        _: Date.now(),
      },
      headers: {
        Accept: "application/json",
        "Cache-Control": "no-cache",
        Pragma: "no-cache",
      },
    });
    await log(buildResponsePreview(response), "info");
    const payload = coerceResponsePayload(response.data);

    console.log('[sheetService] Raw API payload:', JSON.stringify(payload, null, 2));
    console.log('[sheetService] Parsed payload keys:', Object.keys(payload as any));
    console.log('[sheetService] Payload success:', (payload as any).success);

    let normalized = adaptApiPayload(payload, {
      config: {
        ...config,
        fonteUrl,
      },
      mode: "remote",
      message: "Dados atualizados da API do Google Apps Script.",
      fetchedAt,
    });
    const partialPayload = isPartialApiPayload(payload);

    console.log(
      "[sheetService] Adapted payload:",
      JSON.stringify(toAppDataSnapshot(normalized), null, 2),
    );

    if (!hasUsableRemoteData(normalized)) {
      throw new Error(
        "A fonte remota respondeu sem JSON util. Verifique a publicacao do Apps Script.",
      );
    }

    if (partialPayload && cachedSnapshot) {
      normalized = mergeRemoteWithStoredData(normalized, cachedSnapshot);
      normalized.sourceStatus = {
        mode: "cache",
        message: "A API respondeu parcialmente. Exibindo o ultimo cache valido.",
        error:
          "Resposta parcial da API. Listas completas e totais nao vieram da fonte remota.",
      };
    } else if (partialPayload) {
      normalized.sourceStatus = {
        mode: "remote",
        message:
          "A API respondeu, mas o payload veio parcial. O app preservou a resposta remota e nao marcou a conexao como saudavel.",
        error:
          "Resposta parcial da API. Demandas estruturadas e totais confiaveis nao vieram completos.",
      };
    }

    normalized.debug = {
      rawApiPayload: payload,
      adaptedPayload: toAppDataSnapshot(normalized),
      cache: {
        status: partialPayload && cachedSnapshot ? "used" : "not-used",
        message:
          partialPayload && cachedSnapshot
            ? "Resposta parcial da API. Cache local aplicado."
            : "App exibindo resposta online da API. O cache local foi atualizado apenas para fallback.",
        updatedAt: fetchedAt,
      },
    };

    console.log(
      "[sheetService] Final payload:",
      JSON.stringify(toAppDataSnapshot(normalized), null, 2),
    );

    await setCache(LAST_DATA_CACHE_KEY, normalized);
    await saveAppConfig({
      fonteUrl,
      ultimaSincronizacao: normalized.lastUpdated,
    });
    await log(`Sincronizacao concluida: ${fonteUrl}`, "info");

    return normalized;
  } catch (error) {
    const errorMessage = getErrorMessage(error);
    await log(
      `Falha ao sincronizar ${fonteUrl}: ${errorMessage}`,
      "error",
    );

    if (cachedSnapshot) {
      await log("Usando cache local apos falha remota", "warn");
      const normalized = normalizeStoredData(cachedSnapshot, {
        config: {
          ...config,
          fonteUrl,
        },
        mode: "cache",
        message: "Falha ao acessar a API. Exibindo o ultimo cache valido.",
        error: errorMessage,
        fetchedAt,
      });
      console.log(
        "[sheetService] Final payload from cache:",
        JSON.stringify(toAppDataSnapshot(normalized), null, 2),
      );
      return normalized;
    }

    await log("Nenhum cache disponivel. Retornando estrutura zerada.", "warn");
    const fallback = createEmptyAppData({
      config: {
        ...config,
        fonteUrl,
      },
      mode: "fallback",
      message:
        "Falha ao acessar a API e nenhum cache valido foi encontrado. Exibindo estrutura zerada.",
      error: errorMessage,
      fetchedAt,
    });
    console.log(
      "[sheetService] Final fallback payload:",
      JSON.stringify(toAppDataSnapshot(fallback), null, 2),
    );
    return fallback;
  }
}

function coerceResponsePayload(value: unknown): unknown {
  if (typeof value !== "string") {
    return value;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    throw new Error("A fonte remota retornou conteudo vazio.");
  }

  if (trimmed.startsWith("<")) {
    throw new Error(
      "A fonte remota retornou HTML em vez de JSON. Verifique permissoes/publicacao da Apps Script.",
    );
  }

  try {
    return JSON.parse(trimmed);
  } catch {
    throw new Error("A fonte remota retornou texto invalido para JSON.");
  }
}

function hasUsableRemoteData(data: AppData): boolean {
  return Boolean(
    data.generatedAt ||
      data.demandas.length > 0 ||
      data.demandasAtivas.length > 0 ||
      data.demandasHistorico.length > 0 ||
      data.ultimasDemandas.length > 0,
  );
}

export async function updateConfig(
  nextConfig: Partial<AppConfig>,
): Promise<AppConfig> {
  const savedConfig = await saveAppConfig(nextConfig);
  await log("Configuracao atualizada", "info");
  return savedConfig;
}

export async function getCurrentConfig(): Promise<AppConfig> {
  return loadAppConfig();
}

export async function getLastData(): Promise<AppData> {
  const config = await loadAppConfig();
  const fonteUrl = normalizeSourceUrl(config.fonteUrl);
  const cached = await getCache(LAST_DATA_CACHE_KEY);

  if (cached) {
    return normalizeStoredData(cached, {
      config: {
        ...config,
        fonteUrl,
      },
      mode: "cache",
      message: "Exibindo o ultimo cache local valido.",
    });
  }

  return createEmptyAppData({
    config: {
      ...config,
      fonteUrl,
    },
    mode: "fallback",
    message: "Nenhum cache local foi encontrado.",
  });
}

export async function testSourceConnection(url?: string): Promise<{
  ok: boolean;
  status: number | null;
  error?: string | null;
}> {
  const config = await loadAppConfig();
  const targetUrl = normalizeSourceUrl(
    typeof url === "string" && url.trim().length > 0 ? url : config.fonteUrl,
  );

  try {
    const response = await axios.get(targetUrl, {
      timeout: 15000,
      maxRedirects: 5,
      responseType: "text",
      transformResponse: [(value) => value],
      headers: {
        Accept: "application/json",
      },
    });
    coerceResponsePayload(response.data);

    return {
      ok: response.status >= 200 && response.status < 300,
      status: response.status,
      error: null,
    };
  } catch (error) {
    return {
      ok: false,
      status: axios.isAxiosError(error) ? error.response?.status ?? null : null,
      error: getErrorMessage(error),
    };
  }
}

function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    return (
      error.response?.data?.message ||
      error.message ||
      "Erro desconhecido ao acessar a API."
    );
  }

  if (error instanceof Error) {
    return error.message;
  }

  return "Erro desconhecido ao acessar a API.";
}

function buildResponsePreview(response: {
  status: number;
  headers?: Record<string, unknown>;
  data: unknown;
  request?: unknown;
}): string {
  const contentType =
    typeof response.headers?.["content-type"] === "string"
      ? response.headers["content-type"]
      : "desconhecido";
  const rawBody =
    typeof response.data === "string"
      ? response.data
      : JSON.stringify(response.data ?? {});
  const preview = rawBody.replace(/\s+/g, " ").trim().slice(0, 800) || "<vazio>";
  const finalUrl = getFinalResponseUrl(response.request);

  return `Resposta remota recebida: status=${response.status}; content-type=${contentType}; url=${finalUrl}; preview=${preview}`;
}

function getFinalResponseUrl(request: unknown): string {
  if (
    request &&
    typeof request === "object" &&
    "res" in request &&
    request.res &&
    typeof request.res === "object" &&
    "responseUrl" in request.res &&
    typeof request.res.responseUrl === "string" &&
    request.res.responseUrl.trim().length > 0
  ) {
    return request.res.responseUrl.trim();
  }

  return "desconhecida";
}
