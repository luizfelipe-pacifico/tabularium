import {
  DEFAULT_SYNC_INTERVAL_MINUTES,
  type AppConfig,
} from "./appConfig.js";

export const STATUS_LABELS = [
  "Em aberto",
  "Em andamento",
  "Concluída",
  "Recusada",
] as const;

export const PRIORITY_LABELS = [
  "Crítica",
  "Alta",
  "Média",
  "Baixa",
] as const;

export const CATEGORY_LABELS = [
  "Bug crítico",
  "Bug leve",
  "Melhoria",
  "Sugestão",
] as const;

export const UNASSIGNED_OPERATOR = "Não atribuída";

export type StatusLabel = (typeof STATUS_LABELS)[number];
export type PriorityLabel = (typeof PRIORITY_LABELS)[number];
export type CategoryLabel = (typeof CATEGORY_LABELS)[number];
export type SourceMode = "remote" | "cache" | "fallback";

export interface NormalizedDemanda {
  id: string;
  data: string;
  dataDaRequisicao: string | null;
  aba?: string;
  nome: string;
  email: string;
  categoria: CategoryLabel | string;
  grau: PriorityLabel | string;
  status: StatusLabel | string;
  operador: string;
  area: string;
  localExato: string;
  descricao: string;
  comoAconteceu: string;
  oQueDeveriaAcontecer: string;
  anexo: string;
  observacoesExtras: string;
  cliente?: string;
}

export interface OperatorSummary {
  nome: string;
  avatar: string;
  email: string;
  cargo: string;
  total: number;
  abertas: number;
  andamento: number;
  concluidas: number;
  recusadas: number;
  ativas: number;
}

export interface DashboardStats {
  totalDemandas: number;
  totalAtivas: number;
  totalHistorico: number;
  emAberto: number;
  emAndamento: number;
  concluidas: number;
  recusadas: number;
  porGrau: Record<PriorityLabel, number>;
  porCategoria: Record<CategoryLabel, number>;
  porOperador: Record<string, number>;
}

export interface SourceStatus {
  mode: SourceMode;
  message: string;
  error?: string | null;
}

export interface CacheDebugInfo {
  status: "not-used" | "used" | "empty";
  message: string;
  updatedAt: string | null;
}

export interface AppDataSnapshot {
  success: boolean;
  generatedAt: string | null;
  lastUpdated: string | null;
  intervalo: number;
  fonteUrl: string;
  demandas: NormalizedDemanda[];
  demandasAtivas: NormalizedDemanda[];
  demandasHistorico: NormalizedDemanda[];
  ultimasDemandas: NormalizedDemanda[];
  operadores: OperatorSummary[];
  stats: DashboardStats;
  sourceStatus: SourceStatus;
}

export interface AppDataDebugInfo {
  rawApiPayload: unknown | null;
  adaptedPayload: AppDataSnapshot | null;
  cache: CacheDebugInfo;
}

export interface AppData extends AppDataSnapshot {
  debug: AppDataDebugInfo;
}

interface DataContext {
  config: AppConfig;
  mode: SourceMode;
  message: string;
  error?: string | null;
  fetchedAt?: string;
}

interface SummarySnapshot {
  totalDemandas: number;
  totalAtivas: number;
  totalHistorico: number;
  emAberto: number;
  emAndamento: number;
  concluidas: number;
  recusadas: number;
  porCategoria: Record<CategoryLabel, number>;
  porGrau: Record<PriorityLabel, number>;
  porOperador: Record<string, number>;
}

type RawRecord = Record<string, unknown>;
type DemandCollectionKey =
  | "demandas"
  | "demandasAtivas"
  | "demandasHistorico"
  | "ultimasDemandas";

const FIELD_ALIASES = {
  id: ["id", "codigo", "codigodademanda", "codigodemanda", "iD"],
  dataDaRequisicao: [
    "data",
    "datarequisicao",
    "dataderequisicao",
    "datadarequisicao",
    "dataderequest",
    "createdat",
    "dATADEREQUISICAO",
  ],
  nome: ["nome", "solicitante", "nOME"],
  email: ["email", "emailsolicitante", "e-mail", "eMAIL"],
  categoria: ["categoria", "cATEGORIA"],
  grau: ["grau", "graudeimportancia", "prioridade", "gRAUDEIMPORTANCIA"],
  status: ["status", "statusdademanda", "sTATUSDADEMANDA"],
  operador: ["operador", "operadordademanda", "responsavel", "oPERADORDADEMANDA"],
  area: ["area", "areadosistema", "sistema", "aREADOSISTEMA"],
  localExato: ["localexato", "local", "lOCALEXATO"],
  descricao: [
    "descricao",
    "descricaodademanda",
    "descricaodaatividade",
    "descricaodachamada",
    "dESCRICAO",
  ],
  comoAconteceu: ["comoaconteceu", "cOMOACONTECEU"],
  oQueDeveriaAcontecer: ["oquedeveriaacontecer", "oQUEDEVERIAACONTECER"],
  anexo: ["anexo", "aNEXO"],
  observacoesExtras: ["observacoesextras", "observacoes", "oBSERVACOESEXTRAS"],
  cliente: ["cliente", "empresa", "cLIENTE"],
  aba: ["aba", "sheet", "sheetname", "nomedaaba"],
} as const;

export function createEmptyStats(): DashboardStats {
  return {
    totalDemandas: 0,
    totalAtivas: 0,
    totalHistorico: 0,
    emAberto: 0,
    emAndamento: 0,
    concluidas: 0,
    recusadas: 0,
    porGrau: {
      "Crítica": 0,
      "Alta": 0,
      "Média": 0,
      "Baixa": 0,
    },
    porCategoria: {
      "Bug crítico": 0,
      "Bug leve": 0,
      "Melhoria": 0,
      "Sugestão": 0,
    },
    porOperador: {
      [UNASSIGNED_OPERATOR]: 0,
    },
  };
}

export function createEmptyDebugInfo(): AppDataDebugInfo {
  return {
    rawApiPayload: null,
    adaptedPayload: null,
    cache: {
      status: "empty",
      message: "Nenhum cache local foi utilizado nesta leitura.",
      updatedAt: null,
    },
  };
}

export function toAppDataSnapshot(data: AppData | AppDataSnapshot): AppDataSnapshot {
  if ("debug" in data) {
    const { debug: _debug, ...snapshot } = data;
    return snapshot;
  }

  return { ...data };
}

export function createEmptyAppData(context: DataContext): AppData {
  return {
    success: false,
    generatedAt: null,
    lastUpdated: context.fetchedAt ?? context.config.ultimaSincronizacao ?? null,
    intervalo: context.config.intervalo ?? DEFAULT_SYNC_INTERVAL_MINUTES,
    fonteUrl: context.config.fonteUrl,
    demandas: [],
    demandasAtivas: [],
    demandasHistorico: [],
    ultimasDemandas: [],
    operadores: [],
    stats: createEmptyStats(),
    sourceStatus: {
      mode: context.mode,
      message: context.message,
      error: context.error ?? null,
    },
    debug: createEmptyDebugInfo(),
  };
}

export function adaptApiPayload(rawPayload: unknown, context: DataContext): AppData {
  if (!isRecord(rawPayload)) {
    return createEmptyAppData(context);
  }

  const summary = extractApiSummary(rawPayload);
  const demandas = uniqueDemands(adaptDemandList(rawPayload.demandas));
  const explicitDemandasAtivas = uniqueDemands(
    adaptDemandList(rawPayload.demandasAtivas),
  );
  const explicitDemandasHistorico = uniqueDemands(
    adaptDemandList(rawPayload.demandasHistorico),
  );
  const explicitRecentList = uniqueDemands(adaptDemandList(rawPayload.ultimasDemandas));
  const derivedBuckets = splitDemandsByBucket(demandas);
  const activeList =
    explicitDemandasAtivas.length > 0
      ? explicitDemandasAtivas
      : derivedBuckets.activeList;
  const historicList =
    explicitDemandasHistorico.length > 0
      ? explicitDemandasHistorico
      : derivedBuckets.historicList;
  const allDemands = uniqueDemands([
    ...demandas,
    ...activeList,
    ...historicList,
    ...explicitRecentList,
  ]);
  const recentList =
    explicitRecentList.length > 0
      ? explicitRecentList
      : buildRecentList(allDemands);
  const hasStructuredDemandData =
    demandas.length > 0 || activeList.length > 0 || historicList.length > 0;
  const stats = buildStats(activeList, historicList, summary, {
    preferSummary: hasMeaningfulSummary(summary),
    allowDerivedCounts: hasStructuredDemandData,
  });
  const operadores = buildOperatorSummaries(
    allDemands,
    rawPayload.operadores,
    stats.porOperador,
  );

  return {
    success: rawPayload.success !== false,
    generatedAt: toIsoString(rawPayload.generatedAt),
    lastUpdated:
      context.fetchedAt ?? toIsoString(rawPayload.generatedAt) ?? null,
    intervalo: context.config.intervalo ?? DEFAULT_SYNC_INTERVAL_MINUTES,
    fonteUrl: context.config.fonteUrl,
    demandas: allDemands,
    demandasAtivas: activeList,
    demandasHistorico: historicList,
    ultimasDemandas: recentList,
    operadores,
    stats,
    sourceStatus: {
      mode: context.mode,
      message: context.message,
      error: context.error ?? null,
    },
    debug: createEmptyDebugInfo(),
  };
}

export function isPartialApiPayload(rawPayload: unknown): boolean {
  if (!isRecord(rawPayload)) {
    return false;
  }

  const summary = extractApiSummary(rawPayload);
  const hasStructuredLists =
    hasDemandCollection(rawPayload, "demandas") ||
    hasDemandCollection(rawPayload, "demandasAtivas") ||
    hasDemandCollection(rawPayload, "demandasHistorico");
  const hasRecentList = hasDemandCollection(rawPayload, "ultimasDemandas");

  return hasRecentList && !hasStructuredLists && !hasMeaningfulSummary(summary);
}

export function mergeRemoteWithStoredData(
  remoteData: AppData,
  storedPayload: unknown,
): AppData {
  if (!isRecord(storedPayload)) {
    return remoteData;
  }

  const fallbackData = normalizeStoredData(storedPayload, {
    config: {
      fonteUrl: remoteData.fonteUrl,
      intervalo: remoteData.intervalo,
    },
    mode: remoteData.sourceStatus.mode,
    message: remoteData.sourceStatus.message,
    fetchedAt: remoteData.lastUpdated ?? undefined,
  });

  const mergedDemands = mergePreferredDemands(
    uniqueDemands([
      ...remoteData.demandas,
      ...remoteData.demandasAtivas,
      ...remoteData.demandasHistorico,
      ...remoteData.ultimasDemandas,
    ]),
    uniqueDemands([
      ...fallbackData.demandas,
      ...fallbackData.demandasAtivas,
      ...fallbackData.demandasHistorico,
      ...fallbackData.ultimasDemandas,
    ]),
  );
  const { activeList: demandasAtivas, historicList: demandasHistorico } =
    splitDemandsByBucket(mergedDemands);
  const stats = deriveStats(demandasAtivas, demandasHistorico);
  const operadores = buildOperatorSummaries(
    mergedDemands,
    remoteData.operadores.length > 0 ? remoteData.operadores : fallbackData.operadores,
    stats.porOperador,
  );

  return {
    ...remoteData,
    demandas: mergedDemands,
    demandasAtivas,
    demandasHistorico,
    ultimasDemandas: mergePreferredDemands(remoteData.ultimasDemandas, mergedDemands),
    operadores,
    stats,
  };
}

export function normalizeStoredData(rawPayload: unknown, context: DataContext): AppData {
  if (!isRecord(rawPayload)) {
    return createEmptyAppData(context);
  }

  const storedDemands = uniqueDemands(adaptDemandList(rawPayload.demandas));
  const storedActiveList = uniqueDemands(adaptDemandList(rawPayload.demandasAtivas));
  const storedHistoricList = uniqueDemands(
    adaptDemandList(rawPayload.demandasHistorico),
  );
  const derivedBuckets = splitDemandsByBucket(storedDemands);
  const activeList =
    storedActiveList.length > 0
      ? storedActiveList
      : derivedBuckets.activeList;
  const historicList =
    storedHistoricList.length > 0
      ? storedHistoricList
      : derivedBuckets.historicList;
  const allDemands = uniqueDemands([
    ...storedDemands,
    ...activeList,
    ...historicList,
  ]);
  const storedRecentList = uniqueDemands(adaptDemandList(rawPayload.ultimasDemandas));
  const recentList =
    storedRecentList.length > 0
      ? storedRecentList
      : buildRecentList(allDemands);
  const summary = extractStoredSummary(rawPayload);
  const hasStructuredDemandData =
    storedDemands.length > 0 || activeList.length > 0 || historicList.length > 0;
  const operadores = buildOperatorSummaries(
    allDemands,
    rawPayload.operadores,
    summary.porOperador,
  );

  return {
    success: rawPayload.success !== false,
    generatedAt: toIsoString(rawPayload.generatedAt),
    lastUpdated:
      context.fetchedAt ??
      toIsoString(rawPayload.lastUpdated) ??
      context.config.ultimaSincronizacao ??
      null,
    intervalo:
      typeof rawPayload.intervalo === "number"
        ? rawPayload.intervalo
        : context.config.intervalo ?? DEFAULT_SYNC_INTERVAL_MINUTES,
    fonteUrl:
      typeof rawPayload.fonteUrl === "string" && rawPayload.fonteUrl.trim()
        ? rawPayload.fonteUrl.trim()
        : context.config.fonteUrl,
    demandas: allDemands,
    demandasAtivas: activeList,
    demandasHistorico: historicList,
    ultimasDemandas: recentList,
    operadores,
    stats: buildStats(activeList, historicList, summary, {
      preferSummary: hasMeaningfulSummary(summary),
      allowDerivedCounts: hasStructuredDemandData,
    }),
    sourceStatus: {
      mode: context.mode,
      message: context.message,
      error: context.error ?? null,
    },
    debug: extractStoredDebug(rawPayload, context),
  };
}

function extractStoredDebug(
  rawPayload: RawRecord,
  context: DataContext,
): AppDataDebugInfo {
  const storedDebug = isRecord(rawPayload.debug) ? rawPayload.debug : {};
  const storedCache = isRecord(storedDebug.cache) ? storedDebug.cache : {};

  return {
    rawApiPayload:
      "rawApiPayload" in storedDebug ? storedDebug.rawApiPayload : null,
    adaptedPayload: isRecord(storedDebug.adaptedPayload)
      ? (storedDebug.adaptedPayload as unknown as AppDataSnapshot)
      : null,
    cache: {
      status: context.mode === "cache" ? "used" : normalizeCacheDebugStatus(storedCache.status),
      message:
        context.mode === "cache"
          ? context.message
          : cleanText(storedCache.message) || "Cache local nao utilizado nesta leitura.",
      updatedAt:
        toIsoString(storedCache.updatedAt) ??
        toIsoString(rawPayload.lastUpdated) ??
        null,
    },
  };
}

function adaptDemandList(value: unknown): NormalizedDemanda[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value
    .map((item) => mapDemand(item))
    .filter((item): item is NormalizedDemanda => item !== null);
}

function mapDemand(value: unknown): NormalizedDemanda | null {
  if (!isRecord(value)) {
    return null;
  }

  const lookup = createLookup(value);
  const rawId = readField(lookup, FIELD_ALIASES.id);
  const rawDate = readField(lookup, FIELD_ALIASES.dataDaRequisicao);
  const rawName = readField(lookup, FIELD_ALIASES.nome);
  const rawDescription = readField(lookup, FIELD_ALIASES.descricao);

  const dataDaRequisicao = toIsoString(rawDate);
  const nome = cleanText(rawName);
  const descricao = cleanText(rawDescription);
  const id = cleanText(rawId) || createDemandId({ dataDaRequisicao, nome, descricao });

  return {
    id,
    data: formatDisplayDate(dataDaRequisicao, rawDate),
    dataDaRequisicao,
    aba: normalizeDemandBucketLabel(readField(lookup, FIELD_ALIASES.aba)),
    nome,
    email: normalizeEmail(readField(lookup, FIELD_ALIASES.email)),
    categoria: normalizeCategory(readField(lookup, FIELD_ALIASES.categoria)),
    grau: normalizePriority(readField(lookup, FIELD_ALIASES.grau)),
    status: normalizeStatus(readField(lookup, FIELD_ALIASES.status)),
    operador: normalizeOperator(readField(lookup, FIELD_ALIASES.operador)),
    area: cleanText(readField(lookup, FIELD_ALIASES.area)),
    localExato: cleanText(readField(lookup, FIELD_ALIASES.localExato)),
    descricao,
    comoAconteceu: cleanText(readField(lookup, FIELD_ALIASES.comoAconteceu)),
    oQueDeveriaAcontecer: cleanText(
      readField(lookup, FIELD_ALIASES.oQueDeveriaAcontecer),
    ),
    anexo: cleanText(readField(lookup, FIELD_ALIASES.anexo)),
    observacoesExtras: cleanText(
      readField(lookup, FIELD_ALIASES.observacoesExtras),
    ),
    cliente: cleanText(readField(lookup, FIELD_ALIASES.cliente)),
  };
}

function splitDemandsByBucket(demandas: NormalizedDemanda[]): {
  activeList: NormalizedDemanda[];
  historicList: NormalizedDemanda[];
} {
  return {
    activeList: uniqueDemands(
      demandas.filter((demanda) => getDemandBucket(demanda) === "controle"),
    ),
    historicList: uniqueDemands(
      demandas.filter((demanda) => getDemandBucket(demanda) === "historico"),
    ),
  };
}

function getDemandBucket(
  demanda: Pick<NormalizedDemanda, "aba" | "status">,
): "controle" | "historico" {
  const aba = normalizeToken(demanda.aba);
  if (aba === "controle") {
    return "controle";
  }

  if (aba === "historico") {
    return "historico";
  }

  return isHistoricStatus(demanda.status) ? "historico" : "controle";
}

function normalizeDemandBucketLabel(value: unknown): string {
  const cleaned = cleanText(value);
  const token = normalizeToken(value);

  if (token === "controle") {
    return "Controle";
  }

  if (token === "historico") {
    return "Histórico";
  }

  return cleaned;
}

function buildStats(
  demandasAtivas: NormalizedDemanda[],
  demandasHistorico: NormalizedDemanda[],
  summary: SummarySnapshot,
  options: {
    preferSummary: boolean;
    allowDerivedCounts: boolean;
  },
): DashboardStats {
  const derived = options.allowDerivedCounts
    ? deriveStats(demandasAtivas, demandasHistorico)
    : createEmptyStats();

  if (options.allowDerivedCounts) {
    return derived;
  }

  if (options.preferSummary) {
    return {
      totalDemandas: summary.totalDemandas,
      totalAtivas: summary.totalAtivas,
      totalHistorico: summary.totalHistorico,
      emAberto: summary.emAberto,
      emAndamento: summary.emAndamento,
      concluidas: summary.concluidas,
      recusadas: summary.recusadas,
      porGrau: summary.porGrau,
      porCategoria: summary.porCategoria,
      porOperador: summary.porOperador,
    };
  }

  return summary;
}

function deriveStats(
  demandasAtivas: NormalizedDemanda[],
  demandasHistorico: NormalizedDemanda[],
): DashboardStats {
  const stats = createEmptyStats();
  const allDemandas = [...demandasAtivas, ...demandasHistorico];

  stats.totalHistorico = demandasHistorico.length;
  stats.totalDemandas = allDemandas.length;

  for (const demanda of allDemandas) {
    if (isPriorityLabel(demanda.grau)) {
      stats.porGrau[demanda.grau] += 1;
    }

    if (isCategoryLabel(demanda.categoria)) {
      stats.porCategoria[demanda.categoria] += 1;
    }

    const operador = demanda.operador || UNASSIGNED_OPERATOR;
    stats.porOperador[operador] = (stats.porOperador[operador] ?? 0) + 1;
  }

  for (const demanda of demandasAtivas) {
    stats.totalAtivas += 1;

    if (demanda.status === "Em aberto") {
      stats.emAberto += 1;
    } else if (demanda.status === "Em andamento") {
      stats.emAndamento += 1;
    }
  }

  for (const demanda of demandasHistorico) {
    if (demanda.status === "Concluída") {
      stats.concluidas += 1;
    } else if (demanda.status === "Recusada") {
      stats.recusadas += 1;
    }
  }

  return stats;
}

function mergePreferredDemands(
  preferred: NormalizedDemanda[],
  fallback: NormalizedDemanda[],
): NormalizedDemanda[] {
  const merged = new Map<string, NormalizedDemanda>();

  for (const demanda of preferred) {
    merged.set(buildDemandKey(demanda), demanda);
  }

  for (const demanda of fallback) {
    const key = buildDemandKey(demanda);
    if (!merged.has(key)) {
      merged.set(key, demanda);
    }
  }

  return sortDemands(Array.from(merged.values()));
}

function buildOperatorSummaries(
  demandas: NormalizedDemanda[],
  rawOperators: unknown,
  fallbackCounts: Record<string, number>,
): OperatorSummary[] {
  const metadata = extractOperatorMetadata(rawOperators);
  const hasStructuredDemandData = demandas.length > 0;
  const names = new Set<string>();

  for (const demanda of demandas) {
    if (demanda.operador && demanda.operador !== UNASSIGNED_OPERATOR) {
      names.add(demanda.operador);
    }
  }

  for (const nome of Object.keys(fallbackCounts)) {
    if (nome && nome !== UNASSIGNED_OPERATOR) {
      names.add(nome);
    }
  }

  for (const nome of metadata.keys()) {
    if (nome && nome !== UNASSIGNED_OPERATOR) {
      names.add(nome);
    }
  }

  return Array.from(names)
    .map((nome) => {
      const operatorDemands = demandas.filter((demanda) => demanda.operador === nome);
      const meta = metadata.get(nome);
      const abertas = operatorDemands.filter(
        (demanda) => demanda.status === "Em aberto",
      ).length;
      const andamento = operatorDemands.filter(
        (demanda) => demanda.status === "Em andamento",
      ).length;
      const concluidas = operatorDemands.filter(
        (demanda) => demanda.status === "Concluída",
      ).length;
      const recusadas = operatorDemands.filter(
        (demanda) => demanda.status === "Recusada",
      ).length;
      const demandBackedTotal = operatorDemands.length;
      const demandBackedAtivas = abertas + andamento;
      const total = hasStructuredDemandData
        ? demandBackedTotal
        : fallbackCounts[nome] ?? 0;
      const ativas = hasStructuredDemandData
        ? demandBackedAtivas
        : fallbackCounts[nome] ?? 0;

      return {
        nome,
        avatar: meta?.avatar || buildAvatar(nome),
        email: meta?.email || "",
        cargo: meta?.cargo || "Operador",
        total,
        abertas,
        andamento,
        concluidas,
        recusadas,
        ativas,
      };
    })
    .sort((left, right) => {
      if (right.ativas !== left.ativas) {
        return right.ativas - left.ativas;
      }

      if (right.total !== left.total) {
        return right.total - left.total;
      }

      return left.nome.localeCompare(right.nome, "pt-BR");
    });
}

function extractApiSummary(rawPayload: RawRecord): SummarySnapshot {
  const totais = isRecord(rawPayload.totais) ? rawPayload.totais : {};
  const totalAtivas = asNumber(totais.ativas, 0);
  const concluidas = asNumber(totais.concluidas, 0);
  const recusadas = asNumber(totais.recusadas, 0);
  const totalHistorico = asNumber(
    totais.historico ?? totais.totalHistorico,
    concluidas + recusadas,
  );
  const totalDemandas = asNumber(
    totais.demandas ?? totais.totalDemandas ?? totais.total,
    totalAtivas + totalHistorico,
  );

  return {
    totalDemandas,
    totalAtivas,
    totalHistorico,
    emAberto: asNumber(totais.emAberto, 0),
    emAndamento: asNumber(totais.emAndamento, 0),
    concluidas,
    recusadas,
    porCategoria: normalizeFixedCountMap(
      rawPayload.categorias,
      normalizeCategory,
      CATEGORY_LABELS,
    ),
    porGrau: normalizeFixedCountMap(
      rawPayload.graus,
      normalizePriority,
      PRIORITY_LABELS,
    ),
    porOperador: normalizeLooseCountMap(rawPayload.operadores, normalizeOperator),
  };
}

function extractStoredSummary(rawPayload: RawRecord): SummarySnapshot {
  const stats = isRecord(rawPayload.stats) ? rawPayload.stats : {};
  const totalAtivas = asNumber(stats.totalAtivas, 0);
  const concluidas = asNumber(stats.concluidas, 0);
  const recusadas = asNumber(stats.recusadas, 0);
  const totalHistorico = asNumber(
    stats.totalHistorico,
    concluidas + recusadas,
  );
  const totalDemandas = asNumber(
    stats.totalDemandas,
    totalAtivas + totalHistorico,
  );

  return {
    totalDemandas,
    totalAtivas,
    totalHistorico,
    emAberto: asNumber(stats.emAberto, 0),
    emAndamento: asNumber(stats.emAndamento, 0),
    concluidas,
    recusadas,
    porCategoria: normalizeFixedCountMap(
      stats.porCategoria,
      normalizeCategory,
      CATEGORY_LABELS,
    ),
    porGrau: normalizeFixedCountMap(
      stats.porGrau,
      normalizePriority,
      PRIORITY_LABELS,
    ),
    porOperador: normalizeLooseCountMap(stats.porOperador, normalizeOperator),
  };
}

function normalizeFixedCountMap<TLabel extends string>(
  value: unknown,
  normalizeLabel: (raw: unknown) => TLabel | string,
  labels: readonly TLabel[],
): Record<TLabel, number> {
  const result = Object.fromEntries(labels.map((label) => [label, 0])) as Record<
    TLabel,
    number
  >;

  if (!isRecord(value)) {
    return result;
  }

  for (const [key, count] of Object.entries(value)) {
    const normalizedKey = normalizeLabel(key);
    if (labels.includes(normalizedKey as TLabel)) {
      result[normalizedKey as TLabel] = asNumber(count, 0);
    }
  }

  return result;
}

function normalizeLooseCountMap(
  value: unknown,
  normalizeLabel: (raw: unknown) => string,
): Record<string, number> {
  if (!isRecord(value)) {
    return {
      [UNASSIGNED_OPERATOR]: 0,
    };
  }

  const result: Record<string, number> = {};

  for (const [key, count] of Object.entries(value)) {
    const normalizedKey = normalizeLabel(key);
    if (!normalizedKey) {
      continue;
    }

    result[normalizedKey] = asNumber(count, 0);
  }

  if (!result[UNASSIGNED_OPERATOR]) {
    result[UNASSIGNED_OPERATOR] = 0;
  }

  return result;
}

function extractOperatorMetadata(
  rawOperators: unknown,
): Map<string, Pick<OperatorSummary, "avatar" | "email" | "cargo">> {
  const metadata = new Map<
    string,
    Pick<OperatorSummary, "avatar" | "email" | "cargo">
  >();

  if (!Array.isArray(rawOperators)) {
    return metadata;
  }

  for (const item of rawOperators) {
    if (typeof item === "string") {
      const nome = normalizeOperator(item);
      if (nome && nome !== UNASSIGNED_OPERATOR) {
        metadata.set(nome, {
          avatar: buildAvatar(nome),
          email: "",
          cargo: "Operador",
        });
      }

      continue;
    }

    if (!isRecord(item)) {
      continue;
    }

    const nome =
      normalizeOperator(item.nome ?? item.name ?? item.operador ?? item.responsavel);

    if (!nome || nome === UNASSIGNED_OPERATOR) {
      continue;
    }

    metadata.set(nome, {
      avatar: cleanText(item.avatar) || buildAvatar(nome),
      email: normalizeEmail(item.email ?? item.mail),
      cargo: cleanText(item.cargo) || "Operador",
    });
  }

  return metadata;
}

function createLookup(value: RawRecord): Map<string, unknown> {
  const lookup = new Map<string, unknown>();

  for (const [key, item] of Object.entries(value)) {
    lookup.set(normalizeToken(key), item);
  }

  return lookup;
}

function readField(
  lookup: Map<string, unknown>,
  aliases: readonly string[],
): unknown {
  for (const alias of aliases) {
    const value = lookup.get(normalizeToken(alias));
    if (value !== undefined && value !== null) {
      return value;
    }
  }

  return "";
}

function cleanText(value: unknown): string {
  if (value === null || value === undefined) {
    return "";
  }

  const base = String(value)
    .replace(/[\u200d\uFE0F]/g, " ")
    .replace(/\p{Extended_Pictographic}/gu, " ")
    .replace(/\s+/g, " ")
    .trim();

  return base;
}

function normalizeToken(value: unknown): string {
  return cleanText(value)
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function normalizeCategory(value: unknown): CategoryLabel | string {
  const cleaned = cleanText(value);
  const token = normalizeToken(value);

  if (token.includes("bugcritico")) {
    return "Bug crítico";
  }

  if (token.includes("bugleve")) {
    return "Bug leve";
  }

  if (token.includes("melhoria")) {
    return "Melhoria";
  }

  if (token.includes("sugestao")) {
    return "Sugestão";
  }

  return cleaned || "Não informado";
}

function normalizePriority(value: unknown): PriorityLabel | string {
  const cleaned = cleanText(value);
  const token = normalizeToken(value);

  if (token.includes("critica")) {
    return "Crítica";
  }

  if (token.includes("alta")) {
    return "Alta";
  }

  if (token.includes("media")) {
    return "Média";
  }

  if (token.includes("baixa")) {
    return "Baixa";
  }

  return cleaned || "Não informado";
}

function normalizeStatus(value: unknown): StatusLabel | string {
  const cleaned = cleanText(value);
  const token = normalizeToken(value);

  if (token.includes("emandamento")) {
    return "Em andamento";
  }

  if (token.includes("concluida") || token.includes("finalizada")) {
    return "Concluída";
  }

  if (token.includes("recusada") || token.includes("cancelada")) {
    return "Recusada";
  }

  if (token.includes("emaberto") || token.includes("aberta")) {
    return "Em aberto";
  }

  return cleaned || "Em aberto";
}

function normalizeOperator(value: unknown): string {
  const cleaned = cleanText(value);
  const token = normalizeToken(value);

  if (
    !cleaned ||
    token === "vazia" ||
    token === "vazio" ||
    token === "naoatribuida" ||
    token === "naoatribuido" ||
    token === "semoperador" ||
    token === "semdefinicao" ||
    token === "naodefinido"
  ) {
    return UNASSIGNED_OPERATOR;
  }

  return cleaned;
}

function normalizeEmail(value: unknown): string {
  return cleanText(value).toLowerCase();
}

function buildAvatar(nome: string): string {
  return cleanText(nome).charAt(0).toUpperCase() || "?";
}

function createDemandId(input: {
  dataDaRequisicao: string | null;
  nome: string;
  descricao: string;
}): string {
  const parts = [
    normalizeToken(input.dataDaRequisicao),
    normalizeToken(input.nome),
    normalizeToken(input.descricao).slice(0, 10),
  ].filter(Boolean);

  return `SEM-ID-${parts.join("-") || "demanda"}`;
}

function uniqueDemands(demandas: NormalizedDemanda[]): NormalizedDemanda[] {
  const byKey = new Map<string, NormalizedDemanda>();

  for (const demanda of demandas) {
    const key = buildDemandKey(demanda);
    if (!byKey.has(key)) {
      byKey.set(key, demanda);
    }
  }

  return Array.from(byKey.values());
}

function sortDemands(demandas: NormalizedDemanda[]): NormalizedDemanda[] {
  return [...demandas].sort((left, right) => {
    const rightTime = toTimestamp(right.dataDaRequisicao);
    const leftTime = toTimestamp(left.dataDaRequisicao);

    if (rightTime !== leftTime) {
      return rightTime - leftTime;
    }

    return right.id.localeCompare(left.id, "pt-BR");
  });
}

function buildRecentList(demandas: NormalizedDemanda[]): NormalizedDemanda[] {
  return sortDemands(uniqueDemands(demandas)).slice(0, 10);
}

function buildDemandKey(demanda: NormalizedDemanda): string {
  if (demanda.id && !demanda.id.startsWith("SEM-ID-")) {
    return `id:${normalizeToken(demanda.id)}`;
  }

  return [
    demanda.id,
    demanda.dataDaRequisicao ?? demanda.data,
    normalizeToken(demanda.nome),
    normalizeToken(demanda.descricao),
  ].join("|");
}

function normalizeCacheDebugStatus(value: unknown): CacheDebugInfo["status"] {
  return value === "used" || value === "not-used" || value === "empty"
    ? value
    : "empty";
}

function hasDemandCollection(
  rawPayload: RawRecord,
  key: DemandCollectionKey,
): boolean {
  return Array.isArray(rawPayload[key]) && rawPayload[key].length > 0;
}

function hasMeaningfulSummary(summary: SummarySnapshot): boolean {
  return (
    summary.totalAtivas > 0 ||
    summary.emAberto > 0 ||
    summary.emAndamento > 0 ||
    summary.concluidas > 0 ||
    summary.recusadas > 0 ||
    Object.values(summary.porCategoria).some((count) => count > 0) ||
    Object.values(summary.porGrau).some((count) => count > 0) ||
    Object.entries(summary.porOperador).some(
      ([key, count]) => key !== UNASSIGNED_OPERATOR && count > 0,
    )
  );
}

function toIsoString(value: unknown): string | null {
  const raw = cleanText(value);
  if (!raw) {
    return null;
  }

  const nativeDate = new Date(raw);
  if (!Number.isNaN(nativeDate.getTime())) {
    return nativeDate.toISOString();
  }

  const brMatch = raw.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/,
  );
  if (!brMatch) {
    return null;
  }

  const [, day, month, year, hour = "0", minute = "0", second = "0"] = brMatch;
  const parsed = new Date(
    Number(year),
    Number(month) - 1,
    Number(day),
    Number(hour),
    Number(minute),
    Number(second),
  );

  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
}

function toTimestamp(value: string | null): number {
  if (!value) {
    return 0;
  }

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 0 : date.getTime();
}

function formatDisplayDate(isoValue: string | null, rawValue: unknown): string {
  if (isoValue) {
    return new Date(isoValue).toLocaleString("pt-BR");
  }

  const cleaned = cleanText(rawValue);
  return cleaned || "-";
}

function isHistoricStatus(status: string): boolean {
  return status === "Concluída" || status === "Recusada";
}

function isCategoryLabel(value: string): value is CategoryLabel {
  return CATEGORY_LABELS.includes(value as CategoryLabel);
}

function isPriorityLabel(value: string): value is PriorityLabel {
  return PRIORITY_LABELS.includes(value as PriorityLabel);
}

function asNumber(value: unknown, fallback: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function isRecord(value: unknown): value is RawRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
