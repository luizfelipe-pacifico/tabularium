import { describe, expect, it } from "vitest";
import {
  adaptApiPayload,
  isPartialApiPayload,
  mergeRemoteWithStoredData,
  normalizeStoredData,
  UNASSIGNED_OPERATOR,
} from "./dataAdapter.ts";

const baseConfig = {
  fonteUrl:
    "https://script.google.com/macros/s/AKfycbzfkXYf6mzOOLRhCbQfB8gS7DVWpPNQf-GGiSGd3gJTjOcyJS6FJ_AXCTO9iYh_UJk/exec",
  intervalo: 5,
  emailAlerta: "",
  nomeAmbiente: "ProduÃ§Ã£o",
  tema: "dark",
  ultimaSincronizacao: null,
};

describe("dataAdapter", () => {
  it("separa demandas pela aba quando a API manda uma lista unica", () => {
    const result = adaptApiPayload(
      {
        success: true,
        generatedAt: "2026-03-16T20:55:00.000Z",
        demandas: [
          {
            id: "DC-0300",
            aba: "Controle",
            dataDaRequisicao: "2026-03-16T18:00:00.000Z",
            nome: "Ana",
            email: "ana@deconta.com.br",
            categoria: "Melhoria",
            grau: "Alta",
            status: "Em aberto",
            operador: "Luiz",
            area: "Clientes",
            descricao: "Demanda ativa",
          },
          {
            id: "DC-0301",
            aba: "Histórico",
            dataDaRequisicao: "2026-03-15T18:00:00.000Z",
            nome: "Bia",
            email: "bia@deconta.com.br",
            categoria: "Bug leve",
            grau: "MÃƒÂ©dia",
            status: "Concluida",
            operador: "Will",
            area: "Contratos",
            descricao: "Demanda historica",
          },
        ],
      },
      {
        config: baseConfig,
        mode: "remote",
        message: "Contrato novo",
        fetchedAt: "2026-03-16T21:00:00.000Z",
      },
    );

    expect(result.demandas).toHaveLength(2);
    expect(result.demandasAtivas).toHaveLength(1);
    expect(result.demandasHistorico).toHaveLength(1);
    expect(result.ultimasDemandas).toHaveLength(2);
    expect(result.demandasAtivas[0].id).toBe("DC-0300");
    expect(result.demandasHistorico[0].id).toBe("DC-0301");
    expect(result.stats.totalDemandas).toBe(2);
    expect(result.stats.totalAtivas).toBe(1);
    expect(result.stats.totalHistorico).toBe(1);
    expect(result.stats.emAberto).toBe(1);
    expect(result.stats.concluidas).toBe(1);
  });

  it("normaliza o payload real do Apps Script sem inflar demandas ativas a partir de ultimas demandas", () => {
    const result = adaptApiPayload(
      {
        success: true,
        generatedAt: "2026-03-13T12:49:31.095Z",
        totais: {
          ativas: 0,
          emAberto: 0,
          emAndamento: 0,
          concluidas: 0,
          recusadas: 0,
        },
        categorias: {},
        graus: {},
        operadores: {},
        demandasAtivas: [],
        demandasHistorico: [],
        ultimasDemandas: [
          {
            iD: "DC-0001",
            dATADEREQUISICAO: "2026-03-12T19:47:13.372Z",
            nOME: "Luíz Felipe",
            eMAIL: "luiz@cnpjotas.com",
            cATEGORIA: "🛑 Bug crítico",
            gRAUDEIMPORTANCIA: "🚨 Alta",
            sTATUSDADEMANDA: "🟡 Em Aberto",
            oPERADORDADEMANDA: "⬜ Vazia",
            aREADOSISTEMA: "Login",
            lOCALEXATO: "Localhost do meu PC",
            dESCRICAODADEMANDA: "Não consigo acessar o sistema",
            cOMOACONTECEU: "Tentei acessar e não deu",
            oQUEDEVERIAACONTECER: "",
            aNEXO: "",
            oBSERVACOESEXTRAS: "",
          },
        ],
      },
      {
        config: baseConfig,
        mode: "remote",
        message: "Dados atualizados da API.",
        fetchedAt: "2026-03-13T13:00:00.000Z",
      },
    );

    expect(result.demandasAtivas).toHaveLength(0);
    expect(result.demandasHistorico).toHaveLength(0);
    expect(result.ultimasDemandas).toHaveLength(1);
    expect(result.stats.totalDemandas).toBe(0);
    expect(result.stats.totalAtivas).toBe(0);
    expect(result.stats.totalHistorico).toBe(0);
    expect(result.stats.emAberto).toBe(0);
    expect(Object.values(result.stats.porCategoria).every((count) => count === 0)).toBe(true);
    expect(Object.values(result.stats.porOperador).every((count) => count === 0)).toBe(true);
    expect(result.ultimasDemandas[0]).toMatchObject({
      id: "DC-0001",
      nome: "Luíz Felipe",
      email: "luiz@cnpjotas.com",
      categoria: "Bug crítico",
      grau: "Alta",
      status: "Em aberto",
      operador: UNASSIGNED_OPERATOR,
      area: "Login",
      localExato: "Localhost do meu PC",
    });
  });

  it("reconstroi o cache antigo e separa ativo de historico", () => {
    const result = normalizeStoredData(
      {
        demandas: [
          {
            id: "DC-0100",
            dataDaRequisicao: "2026-03-11T10:00:00.000Z",
            nome: "Teste",
            email: "teste@deconta.com.br",
            categoria: "Melhoria",
            grau: "MÃ©dia",
            status: "Em andamento",
            operador: "Luiz",
            area: "Clientes",
            descricao: "Demanda ativa",
          },
          {
            id: "DC-0101",
            dataDaRequisicao: "2026-03-10T10:00:00.000Z",
            nome: "Teste 2",
            email: "teste2@deconta.com.br",
            categoria: "SugestÃ£o",
            grau: "Baixa",
            status: "Recusada",
            operador: "Will",
            area: "Clientes",
            descricao: "Demanda historica",
          },
        ],
        stats: {},
        lastUpdated: "2026-03-13T12:00:00.000Z",
      },
      {
        config: baseConfig,
        mode: "cache",
        message: "Exibindo cache.",
      },
    );

    expect(result.demandasAtivas).toHaveLength(1);
    expect(result.demandasHistorico).toHaveLength(1);
    expect(result.stats.totalDemandas).toBe(2);
    expect(result.stats.totalAtivas).toBe(1);
    expect(result.stats.totalHistorico).toBe(1);
    expect(result.stats.recusadas).toBe(1);
    expect(result.operadores[0]?.nome).toBe("Luiz");
    expect(result.sourceStatus.mode).toBe("cache");
  });

  it("mantem a ordem e o total da lista remota de ultimas demandas", () => {
    const result = adaptApiPayload(
      {
        success: true,
        generatedAt: "2026-03-13T17:33:06.308Z",
        totais: {
          ativas: 0,
          emAberto: 0,
          emAndamento: 0,
          concluidas: 0,
          recusadas: 0,
        },
        categorias: {},
        graus: {},
        operadores: {},
        demandasAtivas: [],
        demandasHistorico: [],
        ultimasDemandas: [
          {
            iD: "DC-0001",
            dATADEREQUISICAO: "2026-03-12T10:00:00.000Z",
            nOME: "Ana",
            cATEGORIA: "Melhoria",
            gRAUDEIMPORTANCIA: "Alta",
            sTATUSDADEMANDA: "Em Aberto",
            oPERADORDADEMANDA: "Will",
            dESCRICAODADEMANDA: "Primeira",
          },
          {
            iD: "DC-0002",
            dATADEREQUISICAO: "2026-03-13T10:00:00.000Z",
            nOME: "Bia",
            cATEGORIA: "SugestÃ£o",
            gRAUDEIMPORTANCIA: "Baixa",
            sTATUSDADEMANDA: "Em Aberto",
            oPERADORDADEMANDA: "Vazia",
            dESCRICAODADEMANDA: "Segunda",
          },
          {
            iD: "DC-0003",
            dATADEREQUISICAO: "2026-03-14T10:00:00.000Z",
            nOME: "Caio",
            cATEGORIA: "Bug leve",
            gRAUDEIMPORTANCIA: "MÃ©dia",
            sTATUSDADEMANDA: "Em Andamento",
            oPERADORDADEMANDA: "Luiz",
            dESCRICAODADEMANDA: "Terceira",
          },
        ],
      },
      {
        config: baseConfig,
        mode: "remote",
        message: "API parcial",
        fetchedAt: "2026-03-13T17:34:00.000Z",
      },
    );

    expect(result.ultimasDemandas.map((item) => item.id)).toEqual([
      "DC-0001",
      "DC-0002",
      "DC-0003",
    ]);
    expect(result.ultimasDemandas).toHaveLength(3);
    expect(result.stats.totalDemandas).toBe(0);
    expect(result.demandasAtivas).toHaveLength(0);
    expect(result.stats.totalHistorico).toBe(0);
    expect(result.stats.totalAtivas).toBe(0);
  });

  it("usa o fetchedAt mais recente ao reexibir cache local", () => {
    const result = normalizeStoredData(
      {
        success: true,
        generatedAt: "2026-03-13T17:33:06.308Z",
        lastUpdated: "2026-03-13T17:34:00.000Z",
        debug: {
          cache: {
            status: "not-used",
            message: "Cache local pronto para fallback.",
            updatedAt: "2026-03-13T17:34:00.000Z",
          },
        },
        stats: {},
      },
      {
        config: baseConfig,
        mode: "cache",
        message: "Exibindo cache.",
        fetchedAt: "2026-03-13T18:00:00.000Z",
      },
    );

    expect(result.lastUpdated).toBe("2026-03-13T18:00:00.000Z");
    expect(result.debug.cache.status).toBe("used");
    expect(result.debug.cache.message).toBe("Exibindo cache.");
  });

  it("deduplica a mesma demanda pelo id quando ela reaparece no cache legado", () => {
    const result = normalizeStoredData(
      {
        generatedAt: "2026-03-13T17:33:06.308Z",
        demandas: [
          {
            id: "DC-0010",
            dataDaRequisicao: "2026-03-13T13:45:05.847Z",
            nome: "Luiz",
            categoria: "SugestÃ£o",
            grau: "CrÃ­tica",
            status: "Em aberto",
            operador: "NÃ£o atribuÃ­da",
            descricao: "Demanda atual",
          },
        ],
        ultimasDemandas: [
          {
            iD: "DC-0010",
            dATADEREQUISICAO: "2026-03-13T13:45:05.847Z",
            nOME: "Luiz",
            cATEGORIA: "SugestÃ£o",
            gRAUDEIMPORTANCIA: "CrÃ­tica",
            sTATUSDADEMANDA: "Em Aberto",
            oPERADORDADEMANDA: "Vazia",
            dESCRICAODADEMANDA: "Demanda atual",
          },
        ],
        stats: {},
      },
      {
        config: baseConfig,
        mode: "cache",
        message: "Cache legado",
      },
    );

    expect(result.demandasAtivas).toHaveLength(1);
    expect(result.demandasAtivas[0].id).toBe("DC-0010");
  });

  it("detecta payload parcial quando so a lista de ultimas demandas vem preenchida", () => {
    const partialPayload = {
      success: true,
      generatedAt: "2026-03-13T17:33:06.308Z",
      totais: {
        ativas: 0,
        emAberto: 0,
        emAndamento: 0,
        concluidas: 0,
        recusadas: 0,
      },
      categorias: {},
      graus: {},
      operadores: {},
      demandasAtivas: [],
      demandasHistorico: [],
      ultimasDemandas: [
        {
          iD: "DC-0009",
          dATADEREQUISICAO: "2026-03-13T13:43:55.425Z",
          nOME: "Luiz",
          eMAIL: "luiz@deconta.com.br",
          cATEGORIA: "SugestÃ£o",
          gRAUDEIMPORTANCIA: "CrÃ­tica",
          sTATUSDADEMANDA: "Em Aberto",
          oPERADORDADEMANDA: "Vazia",
          aREADOSISTEMA: "Clientes",
          dESCRICAODADEMANDA: "Demanda recente",
        },
      ],
    };

    expect(isPartialApiPayload(partialPayload)).toBe(true);
  });

  it("reaproveita o cache quando a API so devolve ultimas demandas", () => {
    const remote = adaptApiPayload(
      {
        success: true,
        generatedAt: "2026-03-16T19:01:24.841Z",
        totais: {
          ativas: 0,
          emAberto: 0,
          emAndamento: 0,
          concluidas: 0,
          recusadas: 0,
        },
        categorias: {},
        graus: {},
        operadores: {},
        demandasAtivas: [],
        demandasHistorico: [],
        ultimasDemandas: [
          {
            iD: "DC-0002",
            dATADEREQUISICAO: "2026-03-12T19:54:24.982Z",
            nOME: "Luiz Felipe",
            eMAIL: "luiz@cnpjotas.com",
            cATEGORIA: "Bug critico",
            gRAUDEIMPORTANCIA: "Alta",
            sTATUSDADEMANDA: "Em Aberto",
            oPERADORDADEMANDA: "Vazia",
            aREADOSISTEMA: "Clientes",
            dESCRICAODADEMANDA: "nao carrega, da erro",
          },
        ],
      },
      {
        config: baseConfig,
        mode: "remote",
        message: "API parcial",
        fetchedAt: "2026-03-16T19:01:23.103Z",
      },
    );

    const merged = mergeRemoteWithStoredData(remote, {
      success: true,
      generatedAt: "2026-03-16T18:59:06.699Z",
      lastUpdated: "2026-03-16T18:59:06.699Z",
      demandas: [
        {
          id: "DC-0002",
          dataDaRequisicao: "2026-03-12T19:54:24.982Z",
          nome: "Luiz Felipe",
          email: "luiz@cnpjotas.com",
          categoria: "Bug critico",
          grau: "Alta",
          status: "Em aberto",
          operador: "Nao atribuida",
          area: "Clientes",
          descricao: "nao carrega, da erro",
        },
      ],
      ultimasDemandas: [
        {
          id: "DC-0002",
          dataDaRequisicao: "2026-03-12T19:54:24.982Z",
          nome: "Luiz Felipe",
          email: "luiz@cnpjotas.com",
          categoria: "Bug critico",
          grau: "Alta",
          status: "Em aberto",
          operador: "Nao atribuida",
          area: "Clientes",
          descricao: "nao carrega, da erro",
        },
      ],
      stats: {},
    });

    expect(remote.demandasAtivas).toHaveLength(0);
    expect(merged.stats.totalDemandas).toBe(1);
    expect(merged.demandasAtivas).toHaveLength(1);
    expect(merged.stats.totalAtivas).toBe(1);
    expect(merged.stats.totalHistorico).toBe(0);
    expect(merged.stats.emAberto).toBe(1);
  });

  it("prefere estatisticas derivadas das listas quando a API manda resumo inconsistente", () => {
    const result = adaptApiPayload(
      {
        success: true,
        generatedAt: "2026-03-16T19:01:24.841Z",
        totais: {
          ativas: 99,
          emAberto: 99,
          emAndamento: 0,
          concluidas: 77,
          recusadas: 55,
        },
        categorias: {
          "Bug leve": 99,
        },
        graus: {
          Baixa: 99,
        },
        operadores: {
          Will: 99,
        },
        demandasAtivas: [
          {
            iD: "DC-0200",
            dATADEREQUISICAO: "2026-03-16T18:00:00.000Z",
            nOME: "Ana",
            cATEGORIA: "Melhoria",
            gRAUDEIMPORTANCIA: "Alta",
            sTATUSDADEMANDA: "Em Aberto",
            oPERADORDADEMANDA: "Luiz",
            dESCRICAODADEMANDA: "Demanda ativa",
          },
        ],
        demandasHistorico: [
          {
            iD: "DC-0201",
            dATADEREQUISICAO: "2026-03-15T18:00:00.000Z",
            nOME: "Bia",
            cATEGORIA: "Sugestao",
            gRAUDEIMPORTANCIA: "Baixa",
            sTATUSDADEMANDA: "Recusada",
            oPERADORDADEMANDA: "Will",
            dESCRICAODADEMANDA: "Demanda historica",
          },
        ],
      },
      {
        config: baseConfig,
        mode: "remote",
        message: "API inconsistente",
        fetchedAt: "2026-03-16T19:01:23.103Z",
      },
    );

    expect(result.stats.totalAtivas).toBe(1);
    expect(result.stats.totalDemandas).toBe(2);
    expect(result.stats.totalHistorico).toBe(1);
    expect(result.stats.emAberto).toBe(1);
    expect(result.stats.recusadas).toBe(1);
    expect(result.stats.porCategoria.Melhoria).toBe(1);
    expect(result.stats.porCategoria["Sugestão"]).toBe(1);
    expect(result.stats.porGrau.Alta).toBe(1);
    expect(result.stats.porGrau.Baixa).toBe(1);
    expect(result.stats.porOperador.Luiz).toBe(1);
    expect(result.stats.porOperador.Will).toBe(1);

    const luiz = result.operadores.find((operator) => operator.nome === "Luiz");
    const will = result.operadores.find((operator) => operator.nome === "Will");

    expect(luiz?.total).toBe(1);
    expect(luiz?.ativas).toBe(1);
    expect(will?.total).toBe(1);
    expect(will?.ativas).toBe(0);
  });
});
