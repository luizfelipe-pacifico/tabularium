import { describe, expect, it } from "vitest";
import {
  DEFAULT_SOURCE_URL,
  resolveBundledDistributionState,
} from "./appConfig.ts";

const storedConfig = {
  fonteUrl: DEFAULT_SOURCE_URL,
  intervalo: 5,
  emailAlerta: "",
  nomeAmbiente: "Producao",
  tema: "dark",
  ultimaSincronizacao: "2026-03-16T12:00:00.000Z",
  zoomLevel: 110,
  sidebarCollapsed: true,
  devProfiles: [],
};

const bundledConfig = {
  fonteUrl: "https://script.google.com/macros/s/example/exec",
  intervalo: 1,
  emailAlerta: "luiz@cnpjotas.com",
  nomeAmbiente: "Producao",
  devProfiles: [
    {
      nome: "Luiz",
      email: "luiz@cnpjotas.com",
      fotoUrl: "",
      cargo: "Desenvolvedor",
    },
  ],
};

const bundledLastData = {
  demandas: [{ id: "DC-0001" }],
  demandasAtivas: [{ id: "DC-0001" }],
  demandasHistorico: [],
  ultimasDemandas: [{ id: "DC-0001" }],
  stats: {
    totalDemandas: 1,
    totalAtivas: 1,
    totalHistorico: 0,
    emAberto: 1,
    emAndamento: 0,
    concluidas: 0,
    recusadas: 0,
  },
};

describe("resolveBundledDistributionState", () => {
  it("semeia configuracao e snapshot no primeiro uso", () => {
    const plan = resolveBundledDistributionState({
      storedConfig: null,
      storedRevision: null,
      storedLastData: null,
      bundledConfig,
      bundledRevision: "rev-1",
      bundledLastData,
    });

    expect(plan.shouldWriteConfig).toBe(true);
    expect(plan.shouldWriteCache).toBe(true);
    expect(plan.shouldWriteRevision).toBe(true);
    expect(plan.nextConfig.fonteUrl).toBe(bundledConfig.fonteUrl);
    expect(plan.nextConfig.intervalo).toBe(1);
  });

  it("preserva dados locais quando a revisao distribuida nao mudou", () => {
    const plan = resolveBundledDistributionState({
      storedConfig,
      storedRevision: "rev-1",
      storedLastData: bundledLastData,
      bundledConfig,
      bundledRevision: "rev-1",
      bundledLastData,
    });

    expect(plan.shouldWriteConfig).toBe(false);
    expect(plan.shouldWriteCache).toBe(false);
    expect(plan.shouldWriteRevision).toBe(false);
    expect(plan.nextConfig.fonteUrl).toBe(DEFAULT_SOURCE_URL);
    expect(plan.nextConfig.zoomLevel).toBe(110);
    expect(plan.nextConfig.sidebarCollapsed).toBe(true);
  });

  it("atualiza configuracao compartilhada e snapshot quando o build muda", () => {
    const plan = resolveBundledDistributionState({
      storedConfig,
      storedRevision: "rev-antiga",
      storedLastData: { demandas: [{ id: "DC-OLD" }] },
      bundledConfig,
      bundledRevision: "rev-nova",
      bundledLastData,
    });

    expect(plan.shouldWriteConfig).toBe(true);
    expect(plan.shouldWriteCache).toBe(true);
    expect(plan.shouldWriteRevision).toBe(true);
    expect(plan.nextConfig.fonteUrl).toBe(bundledConfig.fonteUrl);
    expect(plan.nextConfig.zoomLevel).toBe(110);
    expect(plan.nextConfig.sidebarCollapsed).toBe(true);
  });

  it("semeia o snapshot se o cache local estiver vazio mesmo com a mesma revisao", () => {
    const plan = resolveBundledDistributionState({
      storedConfig,
      storedRevision: "rev-1",
      storedLastData: null,
      bundledConfig,
      bundledRevision: "rev-1",
      bundledLastData,
    });

    expect(plan.shouldWriteConfig).toBe(false);
    expect(plan.shouldWriteCache).toBe(true);
    expect(plan.shouldWriteRevision).toBe(false);
  });
});
