import fs from "fs/promises";
import path from "path";
import { getCache, getConfig, setCache, setConfig } from "./db.js";

const DISTRIBUTION_CONFIG_PATH = path.join(__dirname, "distribution-config.json");
const SHARED_CONFIG_REVISION_KEY = "appSharedRevision";
const LAST_DATA_CACHE_KEY = "lastData";

export const DEFAULT_SOURCE_URL =
  "https://script.google.com/macros/s/AKfycbzfkXYf6mzOOLRhCbQfB8gS7DVWpPNQf-GGiSGd3gJTjOcyJS6FJ_AXCTO9iYh_UJk/exec";

export const DEFAULT_SYNC_INTERVAL_MINUTES = 5;
export const DEFAULT_ZOOM_LEVEL = 100;
export const DEFAULT_THEME = "dark";

export function normalizeSourceUrl(input: unknown): string {
  if (typeof input !== "string") {
    return DEFAULT_SOURCE_URL;
  }

  const trimmed = input.trim();
  if (!trimmed) {
    return DEFAULT_SOURCE_URL;
  }

  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      return DEFAULT_SOURCE_URL;
    }

    return parsed.toString();
  } catch {
    return DEFAULT_SOURCE_URL;
  }
}

export interface DevProfile {
  nome: string;
  email: string;
  fotoUrl?: string;
  cargo?: string;
}

export interface AppConfig {
  fonteUrl: string;
  intervalo: number;
  emailAlerta?: string;
  nomeAmbiente?: string;
  tema?: string;
  ultimaSincronizacao?: string | null;
  zoomLevel?: number;
  sidebarCollapsed?: boolean;
  devProfiles?: DevProfile[];
}

interface DistributionConfigPayload {
  revision?: string;
  config?: Partial<AppConfig> | null;
  lastData?: unknown;
}

interface BundledDistributionStateInput {
  storedConfig: Partial<AppConfig> | null | undefined;
  storedRevision: string | null;
  storedLastData: unknown;
  bundledConfig: Partial<AppConfig> | null | undefined;
  bundledRevision: string | null;
  bundledLastData: unknown;
}

interface BundledDistributionStatePlan {
  nextConfig: AppConfig;
  shouldWriteConfig: boolean;
  shouldWriteCache: boolean;
  shouldWriteRevision: boolean;
}

function normalizeDevProfiles(input: unknown): DevProfile[] {
  if (!Array.isArray(input)) {
    return [];
  }

  const normalized: DevProfile[] = [];

  for (const item of input) {
    if (!item || typeof item !== "object") {
      continue;
    }

    const raw = item as Record<string, unknown>;
    const nome =
      typeof raw.nome === "string" && raw.nome.trim().length > 0
        ? raw.nome.trim()
        : "";
    const email =
      typeof raw.email === "string" && raw.email.trim().length > 0
        ? raw.email.trim()
        : "";

    if (!nome) {
      continue;
    }

    normalized.push({
      nome,
      email,
      fotoUrl:
        typeof raw.fotoUrl === "string" && raw.fotoUrl.trim().length > 0
          ? raw.fotoUrl.trim()
          : "",
      cargo:
        typeof raw.cargo === "string" && raw.cargo.trim().length > 0
          ? raw.cargo.trim()
          : "Desenvolvedor",
    });
  }

  return normalized;
}

function pickLocalPreferences(
  input: Partial<AppConfig> | null | undefined,
): Partial<AppConfig> {
  if (!input || typeof input !== "object") {
    return {};
  }

  return {
    ultimaSincronizacao:
      typeof input.ultimaSincronizacao === "string"
        ? input.ultimaSincronizacao
        : null,
    zoomLevel:
      typeof input.zoomLevel === "number" ? Math.round(input.zoomLevel) : undefined,
    sidebarCollapsed: Boolean(input.sidebarCollapsed),
    tema: typeof input.tema === "string" ? input.tema : DEFAULT_THEME,
  };
}

function mergeBundledConfig(
  stored: Partial<AppConfig> | null | undefined,
  bundled: Partial<AppConfig> | null | undefined,
): AppConfig {
  return normalizeAppConfig({
    ...stored,
    ...bundled,
    ...pickLocalPreferences(stored),
  });
}

async function loadDistributionConfig(): Promise<DistributionConfigPayload> {
  try {
    const raw = await fs.readFile(DISTRIBUTION_CONFIG_PATH, "utf8");
    const parsed = JSON.parse(raw) as DistributionConfigPayload;

    return {
      revision:
        typeof parsed.revision === "string" && parsed.revision.trim().length > 0
          ? parsed.revision.trim()
          : undefined,
      config:
        parsed.config && typeof parsed.config === "object" ? parsed.config : null,
      lastData: "lastData" in parsed ? parsed.lastData : null,
    };
  } catch {
    return {};
  }
}

export function normalizeAppConfig(
  input: Partial<AppConfig> | null | undefined,
): AppConfig {
  const raw = input ?? {};
  const fonteUrl = normalizeSourceUrl(raw.fonteUrl);

  const intervaloValue =
    typeof raw.intervalo === "number"
      ? raw.intervalo
      : Number(raw.intervalo ?? DEFAULT_SYNC_INTERVAL_MINUTES);

  const intervalo = Number.isFinite(intervaloValue) && intervaloValue > 0
    ? intervaloValue
    : DEFAULT_SYNC_INTERVAL_MINUTES;
  const zoomValue =
    typeof raw.zoomLevel === "number"
      ? raw.zoomLevel
      : Number(raw.zoomLevel ?? DEFAULT_ZOOM_LEVEL);
  const zoomLevel =
    Number.isFinite(zoomValue) && zoomValue >= 70 && zoomValue <= 130
      ? Math.round(zoomValue)
      : DEFAULT_ZOOM_LEVEL;

  return {
    fonteUrl,
    intervalo,
    emailAlerta: typeof raw.emailAlerta === "string" ? raw.emailAlerta : "",
    nomeAmbiente:
      typeof raw.nomeAmbiente === "string" && raw.nomeAmbiente.trim().length > 0
        ? raw.nomeAmbiente.trim()
        : "Produção",
    tema: DEFAULT_THEME,
    ultimaSincronizacao:
      typeof raw.ultimaSincronizacao === "string"
        ? raw.ultimaSincronizacao
        : null,
    zoomLevel,
    sidebarCollapsed: Boolean(raw.sidebarCollapsed),
    devProfiles: normalizeDevProfiles(raw.devProfiles),
  };
}

export function resolveBundledDistributionState(
  input: BundledDistributionStateInput,
): BundledDistributionStatePlan {
  const storedConfig = input.storedConfig ? normalizeAppConfig(input.storedConfig) : null;
  const hasBundledConfig = Boolean(input.bundledConfig && typeof input.bundledConfig === "object");
  const bundledRevision =
    typeof input.bundledRevision === "string" && input.bundledRevision.length > 0
      ? input.bundledRevision
      : null;
  const shouldRefreshSharedState = Boolean(
    bundledRevision && bundledRevision !== input.storedRevision,
  );
  const shouldWriteConfig =
    !storedConfig || (hasBundledConfig && shouldRefreshSharedState);
  const nextConfig = !storedConfig
    ? normalizeAppConfig(input.bundledConfig)
    : hasBundledConfig && shouldRefreshSharedState
      ? mergeBundledConfig(storedConfig, input.bundledConfig)
      : storedConfig;
  const hasBundledLastData =
    input.bundledLastData !== null && input.bundledLastData !== undefined;
  const hasStoredLastData =
    input.storedLastData !== null && input.storedLastData !== undefined;
  const shouldWriteCache = hasBundledLastData && (!hasStoredLastData || shouldRefreshSharedState);

  return {
    nextConfig,
    shouldWriteConfig,
    shouldWriteCache,
    shouldWriteRevision: Boolean(bundledRevision && bundledRevision !== input.storedRevision),
  };
}

export async function loadAppConfig(): Promise<AppConfig> {
  const [stored, importedRevision, storedLastData, distributionConfig] = await Promise.all([
    getConfig("app"),
    getConfig(SHARED_CONFIG_REVISION_KEY),
    getCache(LAST_DATA_CACHE_KEY),
    loadDistributionConfig(),
  ]);

  const bundledRevision =
    typeof distributionConfig.revision === "string"
      ? distributionConfig.revision
      : null;
  const bundledConfig = distributionConfig.config;
  const bundledLastData =
    "lastData" in distributionConfig ? distributionConfig.lastData : null;
  const storedRevision =
    typeof importedRevision === "string" ? importedRevision : null;
  const plan = resolveBundledDistributionState({
    storedConfig: stored,
    storedRevision,
    storedLastData,
    bundledConfig,
    bundledRevision,
    bundledLastData,
  });

  if (plan.shouldWriteConfig) {
    await setConfig("app", plan.nextConfig);
  }

  if (plan.shouldWriteCache && bundledLastData) {
    await setCache(LAST_DATA_CACHE_KEY, bundledLastData);
  }

  if (plan.shouldWriteRevision && bundledRevision) {
    await setConfig(SHARED_CONFIG_REVISION_KEY, bundledRevision);
  }

  return plan.nextConfig;
}

export async function saveAppConfig(
  nextConfig: Partial<AppConfig>,
): Promise<AppConfig> {
  const current = await loadAppConfig();
  const normalized = normalizeAppConfig({
    ...current,
    ...nextConfig,
  });

  await setConfig("app", normalized);
  return normalized;
}
