import { describe, expect, it } from "vitest";
import {
  buildVersionedOutputPath,
  resolveAvailableOutputPath,
} from "./reportOutput.ts";

describe("report output naming", () => {
  it("gera nomes versionados sem empilhar sufixos", () => {
    expect(buildVersionedOutputPath("C:\\temp\\relatorio.pdf", 2)).toBe(
      "C:\\temp\\relatorio (2).pdf",
    );
    expect(buildVersionedOutputPath("C:\\temp\\relatorio (2).pdf", 3)).toBe(
      "C:\\temp\\relatorio (3).pdf",
    );
  });

  it("usa o proximo nome disponivel quando o arquivo ja existe", async () => {
    const existing = new Set([
      "C:\\temp\\relatorio.pdf",
      "C:\\temp\\relatorio (2).pdf",
    ]);

    const result = await resolveAvailableOutputPath("C:\\temp\\relatorio.pdf", async (candidate) =>
      existing.has(candidate),
    );

    expect(result).toBe("C:\\temp\\relatorio (3).pdf");
  });
});
