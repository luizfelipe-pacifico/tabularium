import {
  BarChart3,
  BookOpenCheck,
  ChevronUp,
  Columns3,
  History,
  KanbanSquare,
  LifeBuoy,
  LayoutDashboard,
  PlugZap,
  Settings,
  StickyNote,
  Users,
} from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import decontaLogo from "@/assets/deconta-logo.png";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAppPreferences } from "@/contexts/app-preferences";

const menuItems = [
  { title: "Dashboard", path: "/", icon: LayoutDashboard },
  { title: "Atendimento", path: "/demandas", icon: KanbanSquare },
  { title: "Minhas atividades", path: "/kanban-dev", icon: Columns3 },
  { title: "Notas", path: "/notas", icon: StickyNote },
];

export function AppSidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { config } = useAppPreferences();
  const collapsed = Boolean(config.sidebarCollapsed);

  if (collapsed) {
    return (
      <aside className="hidden" />
    );
  }

  return (
    <aside className="relative flex h-full min-h-0 w-[var(--app-sidebar-width)] min-w-[var(--app-sidebar-width)] flex-col overflow-hidden border-r border-sidebar-border bg-sidebar/96 transition-all duration-300">
      <div className="drag-region flex h-[var(--app-header-height)] min-h-[var(--app-header-height)] items-center border-b border-sidebar-border px-[var(--app-sidebar-pad-x)]">
        <div className="min-w-0">
          <img
            src={decontaLogo}
            alt="DeConta"
            className="brand-logo-white h-11 w-40 object-contain object-left"
          />
          <p className="font-mono-ui mt-1.5 text-[10px] uppercase tracking-[0.34em] text-muted-foreground">
            Placar
          </p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-2.5 py-5 scrollbar-thin">
        {menuItems.map((item) => {
          const active = location.pathname === item.path;

          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`group flex w-full items-center gap-3 rounded-lg border px-3 py-3 text-[15px] font-semibold transition-all duration-200 ${
                active
                  ? "border-primary/25 bg-primary/12 text-primary shadow-[inset_4px_0_0_hsl(var(--primary))]"
                  : "border-transparent text-sidebar-foreground/72 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              }`}
            >
              <item.icon className="h-[18px] w-[18px] shrink-0" />
              <span className="truncate">{item.title}</span>
            </button>
          );
        })}
      </nav>

      <div className="border-t border-sidebar-border p-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="no-drag flex w-full items-center gap-3 rounded-xl px-3 py-2.5 transition-colors hover:bg-sidebar-accent">
              <span className="grid h-8 w-8 place-items-center rounded-xl border border-primary/20 bg-primary/15 text-primary">
                <Settings className="h-4 w-4" />
              </span>

              <div className="min-w-0 flex-1 text-left">
                <p className="truncate text-[13px] font-medium text-foreground">
                  Menu do sistema
                </p>
                <p className="font-mono-ui truncate text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  Placar
                </p>
              </div>
              <ChevronUp className="h-4 w-4 text-muted-foreground" />
            </button>
          </DropdownMenuTrigger>

          <DropdownMenuContent side="top" align="start" className="w-[260px]">
            <DropdownMenuLabel className="px-3 py-2">
              <p className="text-sm font-semibold text-foreground">Menu do sistema</p>
              <p className="font-mono-ui mt-0.5 truncate text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                Placar DêConta
              </p>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/suporte")}>
              <LifeBuoy className="mr-2 h-4 w-4" /> Suporte e SLA
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/integracoes")}>
              <PlugZap className="mr-2 h-4 w-4" /> Integrações
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate("/manual")}>
              <BookOpenCheck className="mr-2 h-4 w-4" /> Manual de uso
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/historico")}>
              <History className="mr-2 h-4 w-4" /> Histórico
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/relatorios")}>
              <BarChart3 className="mr-2 h-4 w-4" /> Relatórios
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/operadores")}>
              <Users className="mr-2 h-4 w-4" /> Operadores
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/configuracoes")}>
              <Settings className="mr-2 h-4 w-4" /> Configurações
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </aside>
  );
}
