import {
  AlertTriangle,
  CheckCircle2,
  Maximize2,
  Minus,
  PanelLeft,
  RefreshCw,
  Settings2,
  SquarePlus,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useAppPreferences } from "@/contexts/app-preferences";
import { useRemoteData } from "@/hooks/use-data";
import { toast } from "@/hooks/use-toast";
import { getConnectionLabel, getConnectionState } from "@/lib/app-data";
import { syncNow } from "@/services/dataService";

export function AppHeader() {
  const navigate = useNavigate();
  const location = useLocation();
  const [syncing, setSyncing] = useState(false);
  const [lastSync, setLastSync] = useState("-");
  const { data, isFetching } = useRemoteData();
  const { config, savePreferences } = useAppPreferences();
  const connectionState = getConnectionState(data.sourceStatus);
  const connectionLabel = getConnectionLabel(data.sourceStatus);

  useEffect(() => {
    const referenceDate = data?.lastUpdated || data?.generatedAt;
    if (referenceDate) {
      const parsedDate = new Date(referenceDate);
      setLastSync(
        Number.isNaN(parsedDate.getTime())
          ? String(referenceDate)
          : parsedDate.toLocaleString("pt-BR"),
      );
      return;
    }

    setLastSync("-");
  }, [data?.generatedAt, data?.lastUpdated]);

  const handleSync = async () => {
    setSyncing(true);

    try {
      const result = await syncNow();
      const resultState = getConnectionState(result.sourceStatus);

      toast({
        title:
          resultState === "connected"
            ? "Sincronização concluída"
            : resultState === "cache"
              ? "Usando cache local"
              : "Erro de conexão",
        description: result.sourceStatus.message,
        variant: resultState === "error" ? "destructive" : "default",
      });
    } catch (error) {
      toast({
        title: "Erro na sincronização",
        description: error instanceof Error ? error.message : String(error),
        variant: "destructive",
      });
    } finally {
      setSyncing(false);
      window.setTimeout(() => {
        if (window.electronAPI?.reloadApp) {
          void window.electronAPI.reloadApp();
          return;
        }

        window.location.reload();
      }, 250);
    }
  };

  const handleZoom = async (delta: number) => {
    const currentZoom = config.zoomLevel ?? 100;
    const nextZoom = Math.max(70, Math.min(130, currentZoom + delta));

    if (nextZoom === currentZoom) {
      return;
    }

    await savePreferences({ zoomLevel: nextZoom });
  };

  const statusLabel =
    syncing || isFetching
      ? "Sincronizando"
      : connectionState === "connected"
        ? "Conectado"
        : connectionState === "cache"
          ? "Usando cache"
          : "Erro de conexão";
  const statusToneClass =
    connectionState === "connected"
      ? "text-success"
      : connectionState === "cache"
        ? "text-warning"
        : "text-destructive";
  const pageTitle = getHeaderTitle(location.pathname);

  return (
    <header className="drag-region flex h-[var(--app-header-height)] min-h-[var(--app-header-height)] shrink-0 items-center justify-between gap-3 border-b border-border/80 bg-background/90 px-[var(--app-page-pad)] backdrop-blur-xl">
      <div className="min-w-0">
        <div className="flex min-w-0 items-center gap-2.5">
          <h1 className="truncate font-display text-[20px] font-extrabold tracking-tight text-foreground">
            {pageTitle}
          </h1>
          <div className="hidden items-center gap-2 rounded-md border border-primary/20 bg-primary/8 px-2.5 py-1 sm:flex">
            <span className="h-2 w-2 rounded-full bg-success shadow-[0_0_16px_hsl(var(--success)/0.5)]" />
            <span className="font-mono-ui text-[10px] uppercase tracking-[0.24em] text-primary">
              Online
            </span>
          </div>
        </div>
        <p className="font-mono-ui mt-0.5 text-[9px] uppercase tracking-[0.28em] text-muted-foreground">
          Operação · localhost
        </p>
      </div>

      <div className="no-drag flex items-center gap-1.5">
        <div className="hidden h-[var(--app-control-height)] items-center gap-2 rounded-lg border border-border/80 bg-card/55 px-3 text-xs text-muted-foreground xl:flex">
          {connectionState === "connected" ? (
            <CheckCircle2 className="h-3.5 w-3.5 text-success" />
          ) : (
            <AlertTriangle className={`h-3.5 w-3.5 ${statusToneClass}`} />
          )}
          <span>
            {statusLabel} | {lastSync}
          </span>
        </div>

        <Popover>
          <PopoverTrigger asChild>
            <button
              aria-label="Abrir ajustes"
              className="inline-flex h-[var(--app-control-height)] w-[var(--app-control-height)] items-center justify-center rounded-lg border border-border/80 bg-card/55 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              <Settings2 className="h-4 w-4" />
            </button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-[300px] border-border bg-card p-0">
            <div className="border-b border-border px-4 py-3">
              <p className="text-sm font-semibold text-foreground">Ajustes visuais</p>
              <p className="text-xs text-muted-foreground">
                Controles discretos para zoom e barra lateral.
              </p>
            </div>

            <div className="space-y-3 p-4">
              <ActionRow
                label="Tema"
                value="Escuro fixo"
                action={<StaticBadge label="Padrão" />}
              />

              <ActionRow
                label="Zoom"
                value={`${config.zoomLevel ?? 100}%`}
                action={
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleZoom(-5)}
                      className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-secondary text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                    >
                      <ZoomOut className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleZoom(5)}
                      className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-secondary text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                    >
                      <ZoomIn className="h-4 w-4" />
                    </button>
                  </div>
                }
              />

              <ActionRow
                label="Sidebar"
                value={config.sidebarCollapsed ? "Recolhida" : "Expandida"}
                action={
                  <button
                    onClick={() =>
                      savePreferences({
                        sidebarCollapsed: !config.sidebarCollapsed,
                      })
                    }
                    className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-secondary text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                  >
                    <PanelLeft className="h-4 w-4" />
                  </button>
                }
              />

              <ActionRow
                label="Apps Script"
                value={connectionLabel}
                action={<StaticBadge label={statusLabel} />}
              />

              <button
                onClick={() => navigate("/configuracoes")}
                className="w-full rounded-xl border border-border/80 bg-secondary/50 px-4 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-accent"
              >
                Abrir configurações completas
              </button>
            </div>
          </PopoverContent>
        </Popover>

        <button
          onClick={handleSync}
          className="inline-flex h-[var(--app-control-height)] items-center gap-2 rounded-lg border border-border/80 bg-card/55 px-3 text-xs font-semibold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
        >
          <RefreshCw
            className={`h-3.5 w-3.5 ${syncing || isFetching ? "animate-spin" : ""}`}
          />
          Atualizar
        </button>

        <button
          onClick={() => navigate("/demandas")}
          className="inline-flex h-[var(--app-control-height)] items-center gap-2 rounded-lg bg-primary px-3.5 text-sm font-extrabold text-primary-foreground shadow-[0_0_30px_hsl(var(--primary)/0.16)] transition-transform hover:scale-[1.02]"
        >
          <SquarePlus className="h-4 w-4" />
          Nova Demanda
        </button>

        <div className="ml-1 hidden items-center overflow-hidden rounded-lg border border-border/70 bg-card/35 lg:flex">
          <button
            type="button"
            aria-label="Minimizar"
            onClick={() => window.electronAPI?.minimizeWindow?.()}
            className="grid h-[var(--app-control-height)] w-[var(--app-control-height)] place-items-center text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <Minus className="h-4 w-4" />
          </button>
          <button
            type="button"
            aria-label="Maximizar"
            onClick={() => window.electronAPI?.toggleMaximizeWindow?.()}
            className="grid h-[var(--app-control-height)] w-[var(--app-control-height)] place-items-center text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <Maximize2 className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            aria-label="Fechar"
            onClick={() => window.electronAPI?.quit?.()}
            className="grid h-[var(--app-control-height)] w-[var(--app-control-height)] place-items-center text-muted-foreground transition-colors hover:bg-destructive hover:text-destructive-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </header>
  );
}

function getHeaderTitle(pathname: string) {
  if (pathname.startsWith("/demandas")) return "Kanban Atendimento / CRM";
  if (pathname.startsWith("/kanban-dev")) return "Kanban Atividade Dev";
  if (pathname.startsWith("/suporte")) return "Central de Suporte";
  if (pathname.startsWith("/roadmap-board")) return "Avanço do Roadmap";
  if (pathname.startsWith("/roadmap")) return "Roadmap";
  if (pathname.startsWith("/notas")) return "Notas Rápidas";
  if (pathname.startsWith("/integracoes")) return "Integrações";
  if (pathname.startsWith("/manual")) return "Manual de Uso";
  if (pathname.startsWith("/historico")) return "Histórico";
  if (pathname.startsWith("/relatorios")) return "Relatórios";
  if (pathname.startsWith("/operadores")) return "Operadores";
  if (pathname.startsWith("/configuracoes")) return "Configurações";
  if (pathname.startsWith("/perfil")) return "Perfil";
  return "Dashboard operacional";
}

function ActionRow({
  label,
  value,
  action,
}: {
  label: string;
  value: string;
  action: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-xl border border-border bg-secondary/35 px-3 py-2.5">
      <div>
        <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className="text-sm font-medium text-foreground">{value}</p>
      </div>
      {action}
    </div>
  );
}

function StaticBadge({ label }: { label: string }) {
  return (
    <span className="rounded-lg bg-secondary px-3 py-2 text-xs font-semibold text-muted-foreground">
      {label}
    </span>
  );
}
