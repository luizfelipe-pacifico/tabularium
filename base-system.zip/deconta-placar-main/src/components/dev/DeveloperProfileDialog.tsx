import { useEffect, useState } from "react";
import { Save, UserPlus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { DevProfile } from "@/lib/app-data";

const EMPTY_PROFILE: DevProfile = {
  nome: "",
  email: "",
  fotoUrl: "",
  cargo: "Desenvolvedor",
};

interface DeveloperProfileDialogProps {
  open: boolean;
  title: string;
  description: string;
  profile?: DevProfile | null;
  onOpenChange: (open: boolean) => void;
  onSave: (profile: DevProfile) => Promise<void> | void;
}

export function DeveloperProfileDialog({
  open,
  title,
  description,
  profile,
  onOpenChange,
  onSave,
}: DeveloperProfileDialogProps) {
  const [draft, setDraft] = useState<DevProfile>(EMPTY_PROFILE);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setDraft(profile ? { ...EMPTY_PROFILE, ...profile } : EMPTY_PROFILE);
    }
  }, [open, profile]);

  const handleSave = async () => {
    if (!draft.nome.trim()) {
      return;
    }

    setSaving(true);

    try {
      await onSave({
        nome: draft.nome.trim(),
        email: draft.email.trim(),
        fotoUrl: draft.fotoUrl?.trim() || "",
        cargo: "Desenvolvedor",
      });
      onOpenChange(false);
    } finally {
      setSaving(false);
    }
  };

  const ButtonIcon = profile ? Save : UserPlus;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-border bg-card sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs uppercase tracking-wide text-muted-foreground">
              Nome
            </label>
            <input
              value={draft.nome}
              onChange={(event) =>
                setDraft((previous) => ({ ...previous, nome: event.target.value }))
              }
              placeholder="Nome do dev"
              className="w-full rounded-lg border border-border bg-secondary px-3 py-2.5 text-sm text-foreground outline-none transition-colors focus:ring-1 focus:ring-primary/50"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs uppercase tracking-wide text-muted-foreground">
              E-mail
            </label>
            <input
              type="email"
              value={draft.email}
              onChange={(event) =>
                setDraft((previous) => ({ ...previous, email: event.target.value }))
              }
              placeholder="dev@deconta.com.br"
              className="w-full rounded-lg border border-border bg-secondary px-3 py-2.5 text-sm text-foreground outline-none transition-colors focus:ring-1 focus:ring-primary/50"
            />
          </div>

          <div>
            <label className="mb-1.5 block text-xs uppercase tracking-wide text-muted-foreground">
              Foto
            </label>
            <input
              value={draft.fotoUrl}
              onChange={(event) =>
                setDraft((previous) => ({ ...previous, fotoUrl: event.target.value }))
              }
              placeholder="https://..."
              className="w-full rounded-lg border border-border bg-secondary px-3 py-2.5 text-sm text-foreground outline-none transition-colors focus:ring-1 focus:ring-primary/50"
            />
          </div>
        </div>

        <DialogFooter>
          <button
            onClick={handleSave}
            disabled={saving || !draft.nome.trim()}
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <ButtonIcon className="h-4 w-4" />
            {saving ? "Salvando..." : profile ? "Salvar perfil" : "Adicionar dev"}
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
