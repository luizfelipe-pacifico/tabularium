import { cn } from "@/lib/utils";

const statusStyles: Record<string, string> = {
  "Em aberto": "bg-status-open/15 text-status-open border-status-open/20",
  "Em andamento":
    "bg-status-progress/15 text-status-progress border-status-progress/20",
  "Concluída": "bg-status-done/15 text-status-done border-status-done/20",
  "Recusada": "bg-status-refused/15 text-status-refused border-status-refused/20",
};

const grauStyles: Record<string, string> = {
  Crítica:
    "bg-priority-critical/15 text-priority-critical border-priority-critical/20",
  Alta: "bg-priority-high/15 text-priority-high border-priority-high/20",
  Média: "bg-priority-medium/15 text-priority-medium border-priority-medium/20",
  Baixa: "bg-priority-low/15 text-priority-low border-priority-low/20",
};

const categoriaStyles: Record<string, string> = {
  "Bug crítico":
    "bg-priority-critical/15 text-priority-critical border-priority-critical/20",
  "Bug leve": "bg-priority-high/15 text-priority-high border-priority-high/20",
  Melhoria: "bg-info/15 text-info border-info/20",
  Sugestão: "bg-primary/15 text-primary border-primary/20",
};

interface BadgeProps {
  type: "status" | "grau" | "categoria";
  value: string;
  className?: string;
}

export function StatusBadge({ type, value, className }: BadgeProps) {
  const styles =
    type === "status"
      ? statusStyles
      : type === "grau"
        ? grauStyles
        : categoriaStyles;

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold leading-none tracking-[0.01em]",
        styles[value] || "bg-muted text-muted-foreground",
        className,
      )}
    >
      {value}
    </span>
  );
}
