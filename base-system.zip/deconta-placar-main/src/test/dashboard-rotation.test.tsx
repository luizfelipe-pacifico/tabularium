import { act, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { useRemoteData } from "@/hooks/use-data";
import {
  UNASSIGNED_OPERATOR,
  createEmptyAppData,
  type NormalizedDemanda,
} from "@/lib/app-data";
import DashboardPage from "@/pages/DashboardPage";

vi.mock("@/hooks/use-data", () => ({
  useRemoteData: vi.fn(),
}));

const mockedUseRemoteData = vi.mocked(useRemoteData);

function createDemanda(overrides: Partial<NormalizedDemanda>): NormalizedDemanda {
  return {
    id: "DC-0000",
    data: "2026-04-01",
    dataDaRequisicao: "2026-04-01",
    nome: "Cliente",
    email: "cliente@deconta.com.br",
    categoria: "Sugestão",
    grau: "Baixa",
    status: "Em aberto",
    operador: UNASSIGNED_OPERATOR,
    area: "Clientes",
    localExato: "",
    descricao: "Demanda padrão",
    comoAconteceu: "",
    oQueDeveriaAcontecer: "",
    anexo: "",
    observacoesExtras: "",
    ...overrides,
  };
}

describe("DashboardPage demand rotator", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    mockedUseRemoteData.mockReset();
  });

  afterEach(() => {
    act(() => {
      vi.clearAllTimers();
    });
    vi.useRealTimers();
  });

  it("alterna automaticamente entre as demandas mais importantes", () => {
    mockedUseRemoteData.mockReturnValue({
      data: createEmptyAppData({
        demandasAtivas: [
          createDemanda({
            id: "DC-9001",
            data: "2026-03-01",
            dataDaRequisicao: "2026-03-01",
            categoria: "Bug crítico",
            grau: "Crítica",
            descricao: "Falha total no painel",
          }),
          createDemanda({
            id: "DC-9002",
            data: "2026-03-20",
            dataDaRequisicao: "2026-03-20",
            categoria: "Bug leve",
            grau: "Alta",
            operador: "Luiz",
            descricao: "Atualização parcial travando",
          }),
        ],
        sourceStatus: {
          mode: "remote",
          message: "Dados sincronizados.",
          error: null,
        },
      }),
      isFetching: false,
    } as ReturnType<typeof useRemoteData>);

    render(<DashboardPage />);

    expect(screen.getAllByText("DC-9001").length).toBeGreaterThan(0);
    expect(screen.getByText("1/2")).toBeInTheDocument();

    act(() => {
      vi.advanceTimersByTime(4500);
    });

    expect(screen.getAllByText("DC-9002").length).toBeGreaterThan(0);
    expect(screen.getByText("2/2")).toBeInTheDocument();
    expect(screen.queryByText("1/2")).not.toBeInTheDocument();
  });
});
