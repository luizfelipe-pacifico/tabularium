import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  createEmptyAppData,
  pickNewestAppData,
  type AppConfig,
} from "@/lib/app-data";
import * as configService from "@/services/configService";
import * as dataService from "@/services/dataService";

beforeEach(() => {
  global.window = {} as Window & typeof globalThis;
});

describe("renderer services", () => {
  it("retorna config local quando electronAPI nao existe", async () => {
    const config = await configService.loadConfig();

    expect(config).toMatchObject<AppConfig>({
      fonteUrl:
        "https://script.google.com/macros/s/AKfycbzfkXYf6mzOOLRhCbQfB8gS7DVWpPNQf-GGiSGd3gJTjOcyJS6FJ_AXCTO9iYh_UJk/exec",
      intervalo: 5,
      tema: "dark",
    });
  });

  it("retorna fallback zerado quando electronAPI nao existe", async () => {
    const data = await dataService.fetchData();

    expect(data).toEqual(
      createEmptyAppData({
        sourceStatus: {
          mode: "fallback",
          message: "Integração com o Electron indisponível. Exibindo estrutura zerada.",
          error: null,
        },
      }),
    );
  });

  it("usa o payload vindo do Electron no sync manual", async () => {
    const remoteData = createEmptyAppData({
      success: true,
      intervalo: 5,
      fonteUrl: "https://example.com",
      sourceStatus: {
        mode: "remote",
        message: "Dados atualizados da API.",
        error: null,
      },
    });

    Object.defineProperty(global.window, "electronAPI", {
      value: {
        syncNow: vi.fn().mockResolvedValue(remoteData),
      },
      configurable: true,
      writable: true,
    });

    const result = await dataService.syncNow();

    expect(result).toBe(remoteData);
  });

  it("mantem no estado o payload mais novo recebido pela UI", () => {
    const current = createEmptyAppData({
      success: true,
      generatedAt: "2026-03-16T14:50:43.008Z",
      lastUpdated: "2026-03-16T14:50:45.000Z",
      sourceStatus: {
        mode: "remote",
        message: "Payload online mais novo.",
        error: null,
      },
    });
    const older = createEmptyAppData({
      success: true,
      generatedAt: "2026-03-16T14:49:43.008Z",
      lastUpdated: "2026-03-16T14:49:45.000Z",
      sourceStatus: {
        mode: "cache",
        message: "Payload antigo do cache.",
        error: null,
      },
    });

    expect(pickNewestAppData(current, older)).toBe(current);
  });
});
