import { describe, expect, it } from "vitest";
import { createEmptyAppData, UNASSIGNED_OPERATOR, type NormalizedDemanda } from "@/lib/app-data";
import { buildPerformanceReport } from "@/lib/reporting";

function makeDemanda(overrides: Partial<NormalizedDemanda>): NormalizedDemanda {
  return {
    id: "DC-0000",
    data: "10/03/2026, 10:00:00",
    dataDaRequisicao: "2026-03-10T13:00:00.000Z",
    nome: "Teste",
    email: "teste@deconta.com.br",
    categoria: "Melhoria",
    grau: "Média",
    status: "Em aberto",
    operador: UNASSIGNED_OPERATOR,
    area: "Clientes",
    localExato: "Tela principal",
    descricao: "Descrição",
    comoAconteceu: "",
    oQueDeveriaAcontecer: "",
    anexo: "",
    observacoesExtras: "",
    ...overrides,
  };
}

describe("buildPerformanceReport", () => {
  it("compares the selected period against the previous one and highlights hotspots", () => {
    const demandas = [
      makeDemanda({
        id: "DC-0001",
        data: "05/03/2026, 10:00:00",
        dataDaRequisicao: "2026-03-05T13:00:00.000Z",
        categoria: "Melhoria",
        grau: "Baixa",
        status: "Concluída",
        operador: "Ana",
        area: "Clientes",
        localExato: "Cadastro do cliente",
      }),
      makeDemanda({
        id: "DC-0002",
        data: "07/03/2026, 09:00:00",
        dataDaRequisicao: "2026-03-07T12:00:00.000Z",
        categoria: "Sugestão",
        grau: "Baixa",
        status: "Em aberto",
        operador: UNASSIGNED_OPERATOR,
        area: "Clientes",
        localExato: "Fila de cadastro",
      }),
      makeDemanda({
        id: "DC-0003",
        data: "11/03/2026, 11:00:00",
        dataDaRequisicao: "2026-03-11T14:00:00.000Z",
        categoria: "Bug crítico",
        grau: "Alta",
        status: "Concluída",
        operador: "Ana",
        area: "Autenticação",
        localExato: "Login",
      }),
      makeDemanda({
        id: "DC-0004",
        data: "12/03/2026, 14:00:00",
        dataDaRequisicao: "2026-03-12T17:00:00.000Z",
        categoria: "Bug crítico",
        grau: "Crítica",
        status: "Em andamento",
        operador: "Beto",
        area: "Autenticação",
        localExato: "Login",
      }),
      makeDemanda({
        id: "DC-0005",
        data: "13/03/2026, 16:00:00",
        dataDaRequisicao: "2026-03-13T19:00:00.000Z",
        categoria: "Melhoria",
        grau: "Média",
        status: "Em aberto",
        operador: UNASSIGNED_OPERATOR,
        area: "Clientes",
        localExato: "Cadastro do cliente",
      }),
    ];

    const data = createEmptyAppData({
      success: true,
      demandas,
      demandasAtivas: demandas.filter((demanda) => demanda.status !== "Concluída"),
      demandasHistorico: demandas.filter((demanda) => demanda.status === "Concluída"),
    });

    const report = buildPerformanceReport(data, {
      startDate: "2026-03-10",
      endDate: "2026-03-16",
      operators: [],
    });

    expect(report.current.totalDemandas).toBe(3);
    expect(report.previous.totalDemandas).toBe(2);
    expect(report.deltas.totalDemandas.absolute).toBe(1);
    expect(report.deltas.totalDemandas.percentage).toBe(50);
    expect(report.hotspotRows[0]?.label).toBe("Login");
    expect(report.reasons[0]?.description).toContain("Bug crítico");
    expect(report.operatorRows[0]?.nome).toBe("Ana");
    expect(report.kpis[0]?.detail).toBe("Ab. 1 | And. 1\nConcl. 1 | Rec. 0");
    const andamentoRow = report.pressureRows.find((row) => row.status === "Em andamento");
    expect(andamentoRow?.total).toBe(1);
    expect(andamentoRow?.cells.reduce((sum, cell) => sum + cell.total, 0)).toBe(1);
  });

  it("applies the operator filter before calculating the comparison", () => {
    const demandas = [
      makeDemanda({
        id: "DC-0101",
        dataDaRequisicao: "2026-03-05T13:00:00.000Z",
        status: "Concluída",
        operador: "Ana",
      }),
      makeDemanda({
        id: "DC-0102",
        dataDaRequisicao: "2026-03-11T13:00:00.000Z",
        status: "Em andamento",
        operador: "Beto",
      }),
      makeDemanda({
        id: "DC-0103",
        dataDaRequisicao: "2026-03-12T13:00:00.000Z",
        status: "Concluída",
        operador: "Ana",
      }),
    ];

    const data = createEmptyAppData({
      success: true,
      demandas,
      demandasAtivas: demandas.filter((demanda) => demanda.status === "Em andamento"),
      demandasHistorico: demandas.filter((demanda) => demanda.status === "Concluída"),
    });

    const report = buildPerformanceReport(data, {
      startDate: "2026-03-10",
      endDate: "2026-03-16",
      operators: ["Ana"],
    });

    expect(report.current.totalDemandas).toBe(1);
    expect(report.previous.totalDemandas).toBe(1);
    expect(report.operatorRows).toHaveLength(1);
    expect(report.operatorRows[0]?.nome).toBe("Ana");
    expect(report.operatorRows[0]?.concluidas).toBe(1);
  });
});
