import { describe, expect, it } from "vitest";
import { getTopPriorityDemandas } from "@/lib/demand-priority";
import { mergeOperatorSummaries } from "@/lib/dev-profiles";
import { UNASSIGNED_OPERATOR, type NormalizedDemanda, type OperatorSummary } from "@/lib/app-data";

describe("dashboard priority", () => {
  it("prioritizes critical and unassigned demands ahead of low priority items", () => {
    const demandas: NormalizedDemanda[] = [
      {
        id: "DC-100",
        data: "2026-03-10",
        dataDaRequisicao: "2026-03-10",
        nome: "Teste",
        email: "teste@deconta.com.br",
        categoria: "Bug crítico",
        grau: "Alta",
        status: "Em aberto",
        operador: UNASSIGNED_OPERATOR,
        area: "Login",
        localExato: "",
        descricao: "Erro fatal no login",
        comoAconteceu: "",
        oQueDeveriaAcontecer: "",
        anexo: "",
        observacoesExtras: "",
      },
      {
        id: "DC-200",
        data: "2026-03-13",
        dataDaRequisicao: "2026-03-13",
        nome: "Teste",
        email: "teste@deconta.com.br",
        categoria: "Sugestão",
        grau: "Baixa",
        status: "Em andamento",
        operador: "Dev A",
        area: "Menu",
        localExato: "",
        descricao: "Pequena melhoria visual",
        comoAconteceu: "",
        oQueDeveriaAcontecer: "",
        anexo: "",
        observacoesExtras: "",
      },
    ];

    const [first] = getTopPriorityDemandas(demandas, 2);
    expect(first.demanda.id).toBe("DC-100");
    expect(first.score).toBeGreaterThan(200);
  });
});

describe("operator profile merge", () => {
  it("enriches operators with local profile data and appends local-only devs", () => {
    const operators: OperatorSummary[] = [
      {
        nome: "Dev A",
        avatar: "DA",
        email: "",
        cargo: "Operador",
        fotoUrl: "",
        total: 3,
        abertas: 1,
        andamento: 1,
        concluidas: 1,
        recusadas: 0,
        ativas: 2,
      },
    ];

    const merged = mergeOperatorSummaries(operators, [
      {
        nome: "Dev A",
        email: "deva@deconta.com.br",
        fotoUrl: "https://example.com/deva.png",
        cargo: "Desenvolvedor",
      },
      {
        nome: "Dev B",
        email: "devb@deconta.com.br",
        fotoUrl: "",
        cargo: "Desenvolvedor",
      },
    ]);

    expect(merged).toHaveLength(2);
    expect(merged[0].email).toBe("deva@deconta.com.br");
    expect(merged[0].fotoUrl).toBe("https://example.com/deva.png");
    expect(merged[1].nome).toBe("Dev B");
    expect(merged[1].total).toBe(0);
  });
});
