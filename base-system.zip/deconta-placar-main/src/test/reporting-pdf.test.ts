import { describe, expect, it } from "vitest";
import {
  createEmptyAppData,
  UNASSIGNED_OPERATOR,
  type NormalizedDemanda,
} from "@/lib/app-data";
import { buildPerformanceReport } from "@/lib/reporting";
import {
  buildPerformanceReportHtml,
  getReportDownloadRequest,
  getReportPdfRequest,
} from "@/lib/reporting-pdf";

function makeDemanda(overrides: Partial<NormalizedDemanda>): NormalizedDemanda {
  return {
    id: "DC-1000",
    data: "10/03/2026, 10:00:00",
    dataDaRequisicao: "2026-03-10T13:00:00.000Z",
    nome: "Teste",
    email: "teste@deconta.com.br",
    categoria: "Melhoria",
    grau: "Media",
    status: "Em aberto",
    operador: UNASSIGNED_OPERATOR,
    area: "Clientes",
    localExato: "Tela principal",
    descricao: "Descricao da demanda",
    comoAconteceu: "",
    oQueDeveriaAcontecer: "",
    anexo: "",
    observacoesExtras: "",
    ...overrides,
  };
}

function makeReport() {
  const demandas = [
    makeDemanda({
      id: "DC-1001",
      dataDaRequisicao: "2026-03-10T12:00:00.000Z",
      status: "Concluída",
      operador: "Ana",
      localExato: "Login",
      area: "Autenticacao",
      categoria: "Bug crítico",
      grau: "Alta",
    }),
    makeDemanda({
      id: "DC-1002",
      dataDaRequisicao: "2026-03-11T12:00:00.000Z",
      status: "Em andamento",
      operador: "Beto",
      localExato: "Login",
      area: "Autenticacao",
      categoria: "Bug crítico",
      grau: "Crítica",
    }),
    makeDemanda({
      id: "DC-1003",
      dataDaRequisicao: "2026-03-12T12:00:00.000Z",
      status: "Recusada",
      operador: "Ana",
      localExato: "Cadastro",
      area: "Clientes",
      categoria: "Sugestão",
      grau: "Baixa",
    }),
  ];

  const data = createEmptyAppData({
    success: true,
    demandas,
    demandasAtivas: demandas.filter(
      (item) => item.status !== "Concluída" && item.status !== "Recusada",
    ),
    demandasHistorico: demandas.filter(
      (item) => item.status === "Concluída" || item.status === "Recusada",
    ),
  });

  return buildPerformanceReport(data, {
    startDate: "2026-03-10",
    endDate: "2026-03-16",
    operators: [],
  });
}

describe("reporting pdf templates", () => {
  it("gera o relatorio executivo A4 com linha, pizza e barras", () => {
    const report = makeReport();
    const html = buildPerformanceReportHtml({
      report,
      sourceMessage: "Dados atualizados.",
      generatedAt: "2026-03-16T12:00:00.000Z",
      operatorScopeLabel: "Todos os operadores",
      mode: "report",
    });
    const request = getReportPdfRequest(report.filters, "report");

    expect(html).toContain("PLACAR DECONTA - RELATORIO DE PERFORMANCE");
    expect(html).toContain("Pressao operacional");
    expect(html).toContain("Pizza");
    expect(html).toContain("Ranking");
    expect(html).toContain("Maior bloco");
    expect(html).toContain("Ab. 0 | And. 1");
    expect(html).toContain("Concl. 1 | Rec. 1");
    expect(html).not.toContain("Encerradas");
    expect(request.fileName).toContain("relatorio-performance");
    expect(request.outputFormat).toBe("pdf");
  });

  it("gera a apresentacao em widescreen com download em PPTX ou JPEG", () => {
    const report = makeReport();
    const html = buildPerformanceReportHtml({
      report,
      sourceMessage: "Dados atualizados.",
      generatedAt: "2026-03-16T12:00:00.000Z",
      operatorScopeLabel: "Todos os operadores",
      mode: "presentation",
    });
    const pptxRequest = getReportDownloadRequest(report.filters, "presentation", "pptx");
    const jpegRequest = getReportDownloadRequest(report.filters, "presentation", "jpeg");

    expect(html).toContain("PLACAR DECONTA - APRESENTACAO EXECUTIVA");
    expect(html).toContain("size:1920px 1080px");
    expect(pptxRequest.fileName).toContain(".pptx");
    expect(pptxRequest.outputFormat).toBe("pptx");
    expect(pptxRequest.captureOptions).toEqual({ width: 1920, height: 1080 });
    expect(jpegRequest.fileName).toContain(".jpeg");
    expect(jpegRequest.outputFormat).toBe("jpeg");
  });
});
