import { describe, expect, it } from "vitest";
import {
  calculateDashboardFitScale,
  getDashboardFitWidth,
} from "@/lib/dashboard-fit";

describe("dashboard auto fit", () => {
  it("mantem escala 1 quando o conteudo cabe na area disponivel", () => {
    expect(
      calculateDashboardFitScale({
        availableWidth: 1280,
        availableHeight: 900,
        contentWidth: 1200,
        contentHeight: 820,
      }),
    ).toBe(1);
  });

  it("reduz a escala quando a altura disponivel e menor que o conteudo", () => {
    expect(
      calculateDashboardFitScale({
        availableWidth: 1280,
        availableHeight: 720,
        contentWidth: 1280,
        contentHeight: 960,
      }),
    ).toBeCloseTo(0.75, 2);
  });

  it("usa a largura compensada apenas quando ha reducao de escala", () => {
    expect(getDashboardFitWidth(1)).toBe("100%");
    expect(getDashboardFitWidth(0.8)).toBe("125%");
  });

  it("respeita o limite minimo para evitar escala invalida", () => {
    expect(
      calculateDashboardFitScale({
        availableWidth: 400,
        availableHeight: 200,
        contentWidth: 1600,
        contentHeight: 1200,
      }),
    ).toBeCloseTo(0.4, 2);
  });
});
