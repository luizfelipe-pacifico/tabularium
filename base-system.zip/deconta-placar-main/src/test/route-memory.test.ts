import { describe, expect, it } from "vitest";
import {
  getStoredLaunchRoute,
  normalizeRoutePath,
} from "@/lib/route-memory";

describe("route memory", () => {
  it("normaliza rotas validas", () => {
    expect(normalizeRoutePath("/relatorios/")).toBe("/relatorios");
    expect(normalizeRoutePath("/")).toBe("/");
    expect(normalizeRoutePath("relatorios")).toBeNull();
  });

  it("restaura a ultima rota apenas ao abrir na raiz", () => {
    expect(getStoredLaunchRoute("/", "/relatorios")).toBe("/relatorios");
    expect(getStoredLaunchRoute("/demandas", "/relatorios")).toBeNull();
    expect(getStoredLaunchRoute("/", "/")).toBeNull();
  });
});
