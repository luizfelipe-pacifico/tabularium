import {
  BookOpenCheck,
  Columns3,
  GitBranch,
  Headphones,
  KanbanSquare,
  MailPlus,
  Milestone,
  ShieldCheck,
  TableProperties,
} from "lucide-react";

const manualSections = [
  {
    title: "Atendimento / CRM",
    icon: KanbanSquare,
    items: [
      "Sem contato: demanda entrou, mas ainda não houve retorno para o cliente.",
      "Com contato: cliente recebeu retorno inicial e existe contexto mínimo.",
      "Identificação: classificar o caso como N1, N2 ou N3 antes de executar.",
      "Envio de resposta: registrar solução, orientação, prazo ou encaminhamento.",
      "Concluído: finalizar com histórico suficiente para auditoria e aprendizado.",
    ],
  },
  {
    title: "Níveis N1 / N2 / N3",
    icon: Headphones,
    items: [
      "N1 é Help Desk: configuração, acesso ao sistema, dúvida e orientação de uso.",
      "N2 é Service Desk: bugs e erros simples que precisam subir direto para a main.",
      "N3 é Change: caso mais complexo que exige ajustar roadmap ou reservar período de desenvolvimento.",
      "N2 é RUN: bugs imprevistos e manutenção. N3 é Change: evolução, projeto novo e roadmap.",
    ],
  },
  {
    title: "Atividade dev",
    icon: Columns3,
    items: [
      "O kanban dev separa correção direta, manutenção RUN e evolução Change.",
      "A decisão técnica deve registrar impacto, risco, responsável e previsão.",
      "Mudanças recorrentes ou grandes saem do fluxo de atendimento e entram no roadmap.",
    ],
  },
  {
    title: "Avanço do roadmap",
    icon: Milestone,
    items: [
      "O roadmap usa visão de tabuleiro: cada casa representa uma etapa de desenvolvimento.",
      "Entrada, escopo, planejamento, desenvolvimento, validação e entrega precisam ficar visíveis.",
      "Cada item de roadmap deve nascer de uma demanda real, nota ou decisão estratégica registrada.",
    ],
  },
  {
    title: "Prioridade de desenvolvimento",
    icon: GitBranch,
    items: [
      "1º Funcionalidade: primeiro garantir que o recurso entrega valor.",
      "2º Performance: depois garantir resposta adequada para o uso diário.",
      "3º UX: reduzir esforço, dúvida e atrito no fluxo.",
      "4º UI: polir apresentação visual depois da lógica e experiência estarem corretas.",
    ],
  },
  {
    title: "Integrações",
    icon: MailPlus,
    items: [
      "Após login, a conexão do workspace abre o navegador para consentimento.",
      "A conta autorizada será usada para e-mail, agenda, tarefas e arquivos.",
      "Até a migração final, Sheets e Neon trabalham em paralelo como fontes rastreáveis.",
    ],
  },
];

export default function ManualPage() {
  return (
    <div className="app-scroll">
      <div className="app-container animate-fade-in">
        <header className="app-panel p-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="max-w-3xl">
              <p className="section-label">Documento operacional</p>
              <h1 className="page-heading mt-2 tracking-tight">
                Manual de uso do Placar DêConta
              </h1>
              <p className="page-lead mt-2">
                Referência rápida para operar suporte, roadmap, integrações e a transição entre Google Sheets e Neon sem perder histórico.
              </p>
            </div>
            <span className="grid h-12 w-12 place-items-center rounded-2xl border border-primary/20 bg-primary/10 text-primary">
              <BookOpenCheck className="h-6 w-6" />
            </span>
          </div>
        </header>

        <section className="grid gap-4 lg:grid-cols-2">
          {manualSections.map((section) => (
            <article key={section.title} className="app-panel p-5">
              <div className="mb-4 flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl border border-primary/20 bg-primary/10 text-primary">
                  <section.icon className="h-5 w-5" />
                </span>
                <div>
                  <p className="section-label">Manual</p>
                  <h2 className="font-display text-lg font-extrabold text-foreground">
                    {section.title}
                  </h2>
                </div>
              </div>
              <div className="space-y-3">
                {section.items.map((item) => (
                  <div
                    key={item}
                    className="rounded-xl border border-border bg-background/35 px-4 py-3 text-sm leading-6 text-muted-foreground"
                  >
                    {item}
                  </div>
                ))}
              </div>
            </article>
          ))}
        </section>

        <section className="grid gap-4 lg:grid-cols-[0.95fr_1.05fr]">
          <article className="app-panel p-5">
            <div className="mb-4 flex items-center gap-3">
              <TableProperties className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-extrabold text-foreground">
                Dados e sincronização
              </h2>
            </div>
            <p className="text-sm leading-6 text-muted-foreground">
              O Apps Script continua alimentando o snapshot usado pela interface. O Neon recebe o espelho estruturado para acompanhamento, histórico, auditoria e futura migração completa do backend.
            </p>
            <div className="mt-4 grid gap-3">
              <InfoRow label="Fonte atual" value="Google Sheets via Apps Script" />
              <InfoRow label="Banco paralelo" value="Neon Postgres" />
              <InfoRow label="Carga esperada" value="Demandas, operadores, snapshots e execuções de sync" />
            </div>
          </article>

          <article className="app-panel p-5">
            <div className="mb-4 flex items-center gap-3">
              <ShieldCheck className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-extrabold text-foreground">
                Acesso e permissões
              </h2>
            </div>
            <div className="space-y-3 text-sm leading-6 text-muted-foreground">
              <p>
                O login local serve para desenvolvimento e homologação. Em produção, o acesso administrador deve ser tratado pelo provedor de autenticação e não por senha exposta no frontend.
              </p>
              <p>
                A autorização do workspace deve solicitar apenas os escopos necessários para criar e-mails, agendas, tarefas e arquivos conforme a ação executada.
              </p>
            </div>
          </article>
        </section>
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border bg-background/35 px-4 py-3">
      <span className="text-xs uppercase tracking-[0.2em] text-muted-foreground">{label}</span>
      <span className="text-sm font-bold text-foreground">{value}</span>
    </div>
  );
}
