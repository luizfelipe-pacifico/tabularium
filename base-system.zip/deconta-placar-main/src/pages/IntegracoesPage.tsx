import { Bot, Database, Mail, PlugZap, ShieldCheck } from "lucide-react";

const integrations = [
  {
    name: "Google Workspace",
    description: "OAuth para e-mail, agenda, tarefas e arquivos.",
    status: "planejado",
    icon: Mail,
  },
  {
    name: "OpenAI",
    description: "Resumos, respostas, classificacao e e-mails HTML.",
    status: "planejado",
    icon: Bot,
  },
  {
    name: "Sheets + Neon",
    description: "Operacao em paralelo ate migrar 100% para Postgres.",
    status: "em transicao",
    icon: Database,
  },
  {
    name: "RBAC",
    description: "Admin, operador e visualizador com permissoes separadas.",
    status: "planejado",
    icon: ShieldCheck,
  },
];

export default function IntegracoesPage() {
  return (
    <div className="app-scroll">
      <div className="app-container animate-fade-in">
        <header>
          <p className="section-label">Integrações · automação · acesso</p>
          <h1 className="page-heading mt-2">
            Centro de integrações
          </h1>
          <p className="page-lead mt-2">
            Base para conectar Google, OpenAI, Neon, Sheets e permissoes. Esta
            tela vira o painel de configuracao operacional do ecossistema.
          </p>
        </header>

        <section className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {integrations.map((integration) => (
            <article key={integration.name} className="app-panel p-5">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary/12 text-primary">
                <integration.icon className="h-5 w-5" />
              </span>
              <h2 className="font-display mt-5 text-lg font-extrabold">
                {integration.name}
              </h2>
              <p className="mt-3 min-h-[72px] text-sm leading-6 text-muted-foreground">
                {integration.description}
              </p>
              <span className="font-mono-ui mt-4 inline-flex rounded-md border border-border bg-background/35 px-2 py-1 text-[10px] uppercase tracking-[0.2em] text-primary">
                {integration.status}
              </span>
            </article>
          ))}
        </section>

        <section className="app-panel p-5">
          <div className="flex items-center gap-3">
            <PlugZap className="h-5 w-5 text-primary" />
            <h2 className="font-display text-lg font-extrabold">Fluxo alvo</h2>
          </div>
          <div className="mt-5 grid gap-3 md:grid-cols-4">
            {["Login", "Consentimento", "Sincronização", "Automação"].map((step, index) => (
              <div
                key={step}
                className="rounded-2xl border border-border bg-background/35 p-4"
              >
                <p className="font-mono-ui text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                  etapa {index + 1}
                </p>
                <p className="font-display mt-2 text-lg font-extrabold">{step}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
