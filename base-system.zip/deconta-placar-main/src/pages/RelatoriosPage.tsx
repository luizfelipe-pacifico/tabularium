import {
  CalendarRange,
  Download,
  FileImage,
  FileText,
  Filter,
  MonitorPlay,
  RefreshCw,
  Users,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useRemoteData } from "@/hooks/use-data";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LAST_ROUTE_STORAGE_KEY } from "@/lib/route-memory";
import {
  buildPerformanceReport,
  getAvailableReportOperators,
  getSuggestedReportRange,
  type ReportPreset,
} from "@/lib/reporting";
import {
  buildPerformanceReportHtml,
  getReportDownloadRequest,
  type PresentationDownloadFormat,
  type ReportDocumentMode,
} from "@/lib/reporting-pdf";

const presetOptions: Array<{ id: ReportPreset; label: string }> = [
  { id: "last7", label: "Ultimos 7 dias" },
  { id: "last14", label: "Ultimos 14 dias" },
  { id: "month", label: "Mes atual" },
];

export default function RelatoriosPage() {
  const { data, isFetching } = useRemoteData();
  const fallbackRange = useMemo(() => getSuggestedReportRange([], "last7"), []);
  const [startDate, setStartDate] = useState(fallbackRange.startDate);
  const [endDate, setEndDate] = useState(fallbackRange.endDate);
  const [selectedOperators, setSelectedOperators] = useState<string[]>([]);
  const [documentMode, setDocumentMode] = useState<ReportDocumentMode>("report");
  const [presentationFormat, setPresentationFormat] =
    useState<PresentationDownloadFormat>("pptx");
  const [activeTab, setActiveTab] = useState("download");
  const [rangeInitialized, setRangeInitialized] = useState(false);
  const [exporting, setExporting] = useState(false);

  const availableOperators = useMemo(() => getAvailableReportOperators(data), [data]);

  useEffect(() => {
    if (rangeInitialized || data.demandas.length === 0) {
      return;
    }

    const suggestedRange = getSuggestedReportRange(data.demandas, "last7");
    setStartDate(suggestedRange.startDate);
    setEndDate(suggestedRange.endDate);
    setRangeInitialized(true);
  }, [data.demandas, rangeInitialized]);

  const report = useMemo(
    () =>
      buildPerformanceReport(data, {
        startDate,
        endDate,
        operators: selectedOperators,
      }),
    [data, endDate, selectedOperators, startDate],
  );

  const selectedOperatorLabel =
    selectedOperators.length === 0
      ? "Todos os operadores"
      : `${selectedOperators.length} operador(es) selecionado(s)`;

  const outputLabel =
    documentMode === "report"
      ? "PDF A4 retrato"
      : presentationFormat === "pptx"
        ? "PPTX 16:9"
        : "JPEG 16:9";

  const handlePreset = (preset: ReportPreset) => {
    const suggestedRange = getSuggestedReportRange(data.demandas, preset);
    setStartDate(suggestedRange.startDate);
    setEndDate(suggestedRange.endDate);
    setRangeInitialized(true);
  };

  const toggleOperator = (name: string) => {
    setSelectedOperators((current) =>
      current.includes(name)
        ? current.filter((item) => item !== name)
        : [...current, name].sort((left, right) => left.localeCompare(right, "pt-BR")),
    );
  };

  const handleExport = async () => {
    if (!window.electronAPI?.saveReportDocument) {
      toast({
        title: "Exportacao indisponivel",
        description: "O modulo de exportacao nao esta disponivel nesta execucao do app.",
        variant: "destructive",
      });
      return;
    }

    setExporting(true);

    try {
      const currentReport = buildPerformanceReport(data, {
        startDate,
        endDate,
        operators: selectedOperators,
      });
      const generatedAt = data.lastUpdated || data.generatedAt || new Date().toISOString();
      const exportRequest = getReportDownloadRequest(
        currentReport.filters,
        documentMode,
        presentationFormat,
      );
      const html = buildPerformanceReportHtml({
        report: currentReport,
        sourceMessage: data.sourceStatus.message,
        generatedAt,
        operatorScopeLabel: selectedOperatorLabel,
        mode: documentMode,
      });

      const result = await window.electronAPI.saveReportDocument({
        html,
        fileName: exportRequest.fileName,
        outputFormat: exportRequest.outputFormat,
        pdfOptions: exportRequest.pdfOptions,
        captureOptions: exportRequest.captureOptions,
      });

      if (result.canceled) {
        toast({
          title: "Exportacao cancelada",
          description: "Nenhum arquivo foi salvo.",
        });
        return;
      }

      if (typeof window !== "undefined") {
        window.localStorage.setItem(LAST_ROUTE_STORAGE_KEY, "/relatorios");
      }

      toast({
        title: documentMode === "report" ? "Relatorio gerado" : "Apresentacao gerada",
        description: result.filePath
          ? `Arquivo salvo em ${result.filePath}.`
          : "Documento exportado com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao exportar",
        description: error instanceof Error ? error.message : String(error),
        variant: "destructive",
      });
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="app-scroll">
      <div className="app-container animate-fade-in">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="section-label">Performance por periodo</p>
            <h1 className="page-heading mt-2 tracking-tight">
              Relatorios e apresentacao
            </h1>
            <p className="page-lead mt-2">
              Saida visual em pagina unica. Relatorio em PDF. Apresentacao em PPTX
              ou JPEG.
            </p>
          </div>

          {(isFetching || exporting) && (
            <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary">
              <RefreshCw className="h-3.5 w-3.5 animate-spin" />
              {exporting ? "Gerando arquivo" : "Atualizando dados"}
            </div>
          )}
        </div>

        <section className="rounded-[28px] border border-primary/15 bg-card p-5 card-glow">
          <div className="grid gap-5 xl:grid-cols-[minmax(0,1.1fr),minmax(0,0.9fr)]">
            <div>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
                <TabsList className="h-auto rounded-2xl bg-secondary/25 p-1">
                  <TabsTrigger value="download" className="rounded-xl px-4 py-2 text-sm">
                    Download
                  </TabsTrigger>
                  <TabsTrigger value="filtros" className="rounded-xl px-4 py-2 text-sm">
                    Filtros
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="download" className="mt-0 space-y-5">
                  <div className="rounded-2xl border border-border bg-secondary/20 p-4">
                    <div className="mb-3 flex items-center gap-2">
                      {documentMode === "report" ? (
                        <FileText className="h-4 w-4 text-primary" />
                      ) : (
                        <MonitorPlay className="h-4 w-4 text-primary" />
                      )}
                      <p className="text-sm font-semibold text-foreground">Download</p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <ToggleChip
                        active={documentMode === "report"}
                        onClick={() => setDocumentMode("report")}
                      >
                        Relatorio A4
                      </ToggleChip>
                      <ToggleChip
                        active={documentMode === "presentation"}
                        onClick={() => setDocumentMode("presentation")}
                      >
                        Apresentacao 16:9
                      </ToggleChip>
                    </div>

                    {documentMode === "presentation" && (
                      <div className="mt-4">
                        <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                          Formato de download
                        </p>
                        <div className="flex flex-wrap gap-2">
                          <ToggleChip
                            active={presentationFormat === "pptx"}
                            onClick={() => setPresentationFormat("pptx")}
                          >
                            PPTX
                          </ToggleChip>
                          <ToggleChip
                            active={presentationFormat === "jpeg"}
                            onClick={() => setPresentationFormat("jpeg")}
                          >
                            JPEG
                          </ToggleChip>
                        </div>
                      </div>
                    )}

                    <div className="mt-4 rounded-2xl border border-border/80 bg-background/35 p-4">
                      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary/65">
                        Saida pronta
                      </p>
                      <p className="mt-2 text-sm text-foreground">{outputLabel}</p>
                      <p className="mt-1 text-sm text-muted-foreground">
                        A janela de salvar abre direto na pasta Downloads do PC.
                      </p>
                    </div>

                    <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-border/80 pt-5">
                      <div>
                        <p className="text-sm font-semibold text-foreground">
                          Relatorios tambem incluem PPTX e JPEG.
                        </p>
                        <p className="mt-1 text-sm text-muted-foreground">
                          O arquivo sai em pagina unica no formato escolhido.
                        </p>
                      </div>

                      <button
                        onClick={handleExport}
                        disabled={exporting}
                        className="inline-flex items-center gap-2 rounded-xl border border-primary/15 bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-60"
                      >
                        {exporting ? (
                          <RefreshCw className="h-4 w-4 animate-spin" />
                        ) : (
                          <Download className="h-4 w-4" />
                        )}
                        {exporting
                          ? "Gerando..."
                          : documentMode === "report"
                            ? "Baixar relatorio"
                            : `Baixar ${presentationFormat.toUpperCase()}`}
                      </button>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="filtros" className="mt-0 space-y-5">
                  <div className="rounded-2xl border border-border bg-secondary/20 p-4">
                    <div className="mb-3 flex items-center gap-2">
                      <CalendarRange className="h-4 w-4 text-primary" />
                      <p className="text-sm font-semibold text-foreground">Periodo</p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {presetOptions.map((preset) => (
                        <button
                          key={preset.id}
                          onClick={() => handlePreset(preset.id)}
                          className="rounded-full border border-border/80 bg-background/40 px-3 py-1.5 text-xs font-medium text-foreground transition-colors hover:bg-accent"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>

                    <div className="mt-4 grid gap-3 md:grid-cols-2">
                      <Field label="Data inicial">
                        <input
                          type="date"
                          value={startDate}
                          onChange={(event) => {
                            setStartDate(event.target.value);
                            setRangeInitialized(true);
                          }}
                          className="field-input w-full px-3 py-2.5 text-sm"
                        />
                      </Field>

                      <Field label="Data final">
                        <input
                          type="date"
                          value={endDate}
                          onChange={(event) => {
                            setEndDate(event.target.value);
                            setRangeInitialized(true);
                          }}
                          className="field-input w-full px-3 py-2.5 text-sm"
                        />
                      </Field>
                    </div>
                  </div>

                  <div className="rounded-2xl border border-border bg-secondary/20 p-4">
                    <div className="mb-3 flex items-center gap-2">
                      <Filter className="h-4 w-4 text-primary" />
                      <p className="text-sm font-semibold text-foreground">Operadores</p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <ToggleChip
                        active={selectedOperators.length === 0}
                        onClick={() => setSelectedOperators([])}
                      >
                        Todos
                      </ToggleChip>
                      {availableOperators.map((operator) => (
                        <ToggleChip
                          key={operator}
                          active={selectedOperators.includes(operator)}
                          onClick={() => toggleOperator(operator)}
                        >
                          {operator}
                        </ToggleChip>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            <div className="space-y-4">
              <InfoCard
                icon={documentMode === "report" ? FileText : MonitorPlay}
                title="Modelo"
                description={
                  documentMode === "report"
                    ? "Pagina unica A4 com KPIs, linha, pizza, barras e rankings."
                    : "Slide unico 16:9 com visual mais forte e pouco texto."
                }
              />

              <InfoCard
                icon={documentMode === "report" ? FileText : FileImage}
                title="Saida"
                description={outputLabel}
              />

              <InfoCard
                icon={Users}
                title="Escopo atual"
                description={`${selectedOperatorLabel}. Comparativo com ${report.previousLabel}.`}
              />

              <InfoCard
                icon={CalendarRange}
                title="Periodo selecionado"
                description={`${report.currentLabel}. ${report.periodDays} dia(s) no recorte.`}
              />

              <InfoCard
                icon={Download}
                title="Destino inicial"
                description="A janela de salvar abre direto em Downloads para PDF, PPTX e JPEG."
              />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-xs font-medium uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      {children}
    </label>
  );
}

function ToggleChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
        active
          ? "border-primary/20 bg-primary/12 text-primary"
          : "border-border bg-background/40 text-foreground hover:bg-accent"
      }`}
    >
      {children}
    </button>
  );
}

function InfoCard({
  icon: Icon,
  title,
  description,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
}) {
  return (
    <div className="rounded-2xl border border-border bg-background/35 p-4">
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-2xl border border-primary/15 bg-primary/10">
          <Icon className="h-4.5 w-4.5 text-primary" />
        </span>
        <div>
          <p className="text-sm font-semibold text-foreground">{title}</p>
          <p className="mt-1 text-sm leading-6 text-muted-foreground">{description}</p>
        </div>
      </div>
    </div>
  );
}
