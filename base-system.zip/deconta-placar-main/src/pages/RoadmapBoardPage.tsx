import { CheckCircle2, CircleDot, Flag, GitCommitHorizontal, Milestone } from "lucide-react";

const houses = [
  ["Entrada", "Demanda validada como Change"],
  ["Escopo", "Impacto, regra e prioridade definidos"],
  ["Planejamento", "Janela e responsável organizados"],
  ["Desenvolvimento", "Implementação em execução"],
  ["Validação", "Teste, revisão e aceite"],
  ["Entrega", "Publicação e comunicação"],
];

const priorityRules = [
  ["1º", "Funcionalidade", "Sem função principal, o produto não entrega valor."],
  ["2º", "Performance", "Depois de funcionar, precisa responder bem no uso diário."],
  ["3º", "UX", "Fluxo, clareza e esforço operacional vêm antes do polimento visual."],
  ["4º", "UI", "Acabamento visual fecha a experiência depois do fluxo estar correto."],
];

export default function RoadmapBoardPage() {
  return (
    <div className="app-scroll">
      <div className="app-container app-container-wide animate-fade-in">
        <header>
          <p className="section-label">Roadmap · tabuleiro</p>
          <h1 className="page-heading mt-2">Processo de avanço do roadmap</h1>
          <p className="page-lead mt-2">
            Visão em casas para acompanhar cada ponto de desenvolvimento do roadmap, da entrada até a entrega.
          </p>
        </header>

        <section className="app-panel p-5">
          <div className="mb-5 flex items-center gap-3">
            <Milestone className="h-5 w-5 text-primary" />
            <h2 className="font-display text-lg font-extrabold text-foreground">
              Tabuleiro de avanço
            </h2>
          </div>
          <div className="grid gap-3 md:grid-cols-3 xl:grid-cols-6">
            {houses.map(([title, description], index) => (
              <article key={title} className="rounded-2xl border border-border bg-background/35 p-4">
                <div className="mb-4 flex items-center justify-between">
                  <span className="grid h-9 w-9 place-items-center rounded-xl border border-primary/20 bg-primary/10 text-primary">
                    {index === houses.length - 1 ? (
                      <Flag className="h-4 w-4" />
                    ) : (
                      <CircleDot className="h-4 w-4" />
                    )}
                  </span>
                  <span className="font-mono-ui text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                    Casa {index + 1}
                  </span>
                </div>
                <h3 className="font-display text-base font-extrabold text-foreground">{title}</h3>
                <p className="mt-2 text-xs leading-5 text-muted-foreground">{description}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="grid gap-4 lg:grid-cols-[0.92fr_1.08fr]">
          <article className="app-panel p-5">
            <div className="mb-4 flex items-center gap-3">
              <GitCommitHorizontal className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-extrabold text-foreground">
                Critério RUN x Change
              </h2>
            </div>
            <div className="space-y-3">
              <Rule title="RUN" text="Bugs imprevistos, correções simples e manutenção que não exigem replanejamento do produto." />
              <Rule title="Change" text="Evoluções, novos projetos, mudanças complexas e itens que precisam entrar no roadmap." />
            </div>
          </article>

          <article className="app-panel p-5">
            <div className="mb-4 flex items-center gap-3">
              <CheckCircle2 className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-extrabold text-foreground">
                Ordem de prioridade
              </h2>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {priorityRules.map(([order, title, text]) => (
                <div key={title} className="rounded-xl border border-border bg-background/35 p-4">
                  <p className="section-label">{order}</p>
                  <h3 className="mt-1 font-display text-base font-extrabold text-foreground">{title}</h3>
                  <p className="mt-2 text-xs leading-5 text-muted-foreground">{text}</p>
                </div>
              ))}
            </div>
          </article>
        </section>
      </div>
    </div>
  );
}

function Rule({ title, text }: { title: string; text: string }) {
  return (
    <div className="rounded-xl border border-border bg-background/35 p-4">
      <p className="font-mono-ui text-[10px] uppercase tracking-[0.24em] text-primary">{title}</p>
      <p className="mt-2 text-sm leading-6 text-muted-foreground">{text}</p>
    </div>
  );
}
