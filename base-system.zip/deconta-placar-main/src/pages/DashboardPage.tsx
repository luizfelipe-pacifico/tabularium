import {
  Activity,
  BookOpenCheck,
  CalendarClock,
  CheckCircle2,
  CircleAlert,
  GitBranch,
  Headphones,
  ListChecks,
  Map,
  ShieldAlert,
  TimerReset,
  Users,
} from "lucide-react";
import { useEffect, useMemo, useState, type ComponentType, type ReactNode } from "react";
import { useRemoteData } from "@/hooks/use-data";
import {
  CATEGORY_LABELS,
  PRIORITY_LABELS,
  UNASSIGNED_OPERATOR,
  getMaxValue,
  getSortedEntries,
  type NormalizedDemanda,
} from "@/lib/app-data";
import {
  getTopPriorityDemandas,
  type PrioritizedDemanda,
} from "@/lib/demand-priority";

const IMPORTANT_DEMAND_ROTATION_MS = 4500;

type DashboardTab = "suporte" | "roadmap";

const supportLevels = [
  {
    level: "N1",
    label: "Atendimento",
    sla: "15-30 min",
    rule: "Dúvida, cadastro, permissões e orientação de uso.",
  },
  {
    level: "N2",
    label: "Operação",
    sla: "2h-1 dia",
    rule: "Ajuste técnico, inconsistência e validação de processo.",
  },
  {
    level: "N3",
    label: "Produto",
    sla: "Prioridade dinâmica",
    rule: "Bug crítico, refatoração e mudança estrutural no DêConta.",
  },
];

const roadmapTracks = [
  {
    title: "Suporte e SLA",
    horizon: "Curto prazo",
    progress: 36,
    summary: "Triagem N1/N2/N3, tempo de ação e retorno para cada fila.",
  },
  {
    title: "Roadmap do produto",
    horizon: "Médio prazo",
    progress: 22,
    summary: "Demandas recorrentes viram trilhas, tarefas e previsão de entrega.",
  },
  {
    title: "Integrações e IA",
    horizon: "Longo prazo",
    progress: 10,
    summary: "Google Workspace, e-mail HTML, arquivos, tarefas e ChatGPT.",
  },
];

export default function DashboardPage() {
  const { data, isFetching } = useRemoteData();
  const [activeTab, setActiveTab] = useState<DashboardTab>("suporte");

  const importantDemandas = useMemo(
    () => getTopPriorityDemandas(data.demandasAtivas, 8),
    [data.demandasAtivas],
  );

  const supportQueues = useMemo(() => groupSupportQueues(data.demandasAtivas), [data.demandasAtivas]);
  const roadmapCandidates = useMemo(
    () =>
      data.demandasAtivas
        .filter((demanda) => demanda.categoria === "Melhoria" || demanda.categoria === "Sugestão")
        .slice(0, 8),
    [data.demandasAtivas],
  );

  return (
    <div className="app-scroll">
      <div className="app-container app-container-wide animate-fade-in">
        <header className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="section-label">Operação</p>
            <h1 className="page-heading mt-1 tracking-tight">
              Dashboard de gestão
            </h1>
            <p className="page-lead mt-2">
              Visão separada entre suporte operacional e roadmap de produto para decidir o que atender, executar e planejar.
            </p>
          </div>

          <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs text-muted-foreground">
            <Activity className={`h-4 w-4 text-primary ${isFetching ? "animate-pulse" : ""}`} />
            <span>{isFetching ? "Atualizando dados" : "Dados sincronizados"}</span>
          </div>
        </header>

        <section className="grid gap-3 lg:grid-cols-4">
          <MetricCard title="Demandas ativas" value={data.stats.totalAtivas} icon={ListChecks} tone="text-primary" />
          <MetricCard title="Em aberto" value={data.stats.emAberto} icon={TimerReset} tone="text-warning" />
          <MetricCard title="Em andamento" value={data.stats.emAndamento} icon={Activity} tone="text-info" />
          <MetricCard title="Concluídas" value={data.stats.concluidas} icon={CheckCircle2} tone="text-success" />
        </section>

        <section className="grid gap-4 xl:grid-cols-[1fr_0.58fr]">
          <div className="app-panel overflow-hidden p-0">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
              <div>
                <p className="section-label">Frentes</p>
                <h2 className="font-display text-lg font-extrabold">Suporte e Roadmap</h2>
              </div>
              <div className="inline-flex rounded-xl border border-border bg-background/45 p-1">
                <TabButton active={activeTab === "suporte"} onClick={() => setActiveTab("suporte")} icon={Headphones}>
                  Suporte
                </TabButton>
                <TabButton active={activeTab === "roadmap"} onClick={() => setActiveTab("roadmap")} icon={Map}>
                  Roadmap
                </TabButton>
              </div>
            </div>

            <div className="p-4">
              {activeTab === "suporte" ? (
                <SupportDashboard queues={supportQueues} stats={data.stats} />
              ) : (
                <RoadmapDashboard candidates={roadmapCandidates} />
              )}
            </div>
          </div>

          <aside className="grid gap-4">
            <ImportantDemandRotator items={importantDemandas} />
            <DistributionPanel title="Por importância" values={data.stats.porGrau} labels={[...PRIORITY_LABELS]} />
            <DistributionPanel title="Por categoria" values={data.stats.porCategoria} labels={[...CATEGORY_LABELS]} />
          </aside>
        </section>
      </div>
    </div>
  );
}

function SupportDashboard({
  queues,
  stats,
}: {
  queues: Record<string, NormalizedDemanda[]>;
  stats: { porOperador: Record<string, number> };
}) {
  const maxOperator = getMaxValue(Object.values(stats.porOperador));

  return (
    <div className="grid gap-4 xl:grid-cols-[0.8fr_1.2fr]">
      <section className="grid gap-3">
        {supportLevels.map((item) => (
          <article key={item.level} className="rounded-2xl border border-border bg-background/35 p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-display text-3xl font-extrabold text-primary">{item.level}</p>
                <h3 className="mt-1 text-sm font-extrabold text-foreground">{item.label}</h3>
              </div>
              <span className="rounded-lg border border-primary/20 bg-primary/10 px-2.5 py-1 text-[11px] font-bold text-primary">
                {item.sla}
              </span>
            </div>
            <p className="mt-3 text-xs leading-5 text-muted-foreground">{item.rule}</p>
          </article>
        ))}

        <article className="rounded-2xl border border-border bg-background/35 p-4">
          <div className="mb-3 flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            <h3 className="text-sm font-extrabold text-foreground">Distribuição por operador</h3>
          </div>
          <div className="space-y-2">
            {getSortedEntries(stats.porOperador).slice(0, 5).map(([label, value]) => (
              <BarRow key={label} label={label} value={value} max={maxOperator} color="bg-primary" />
            ))}
          </div>
        </article>
      </section>

      <section className="grid gap-3 lg:grid-cols-3">
        {Object.entries(queues).map(([level, items]) => (
          <article key={level} className="flex min-h-[360px] flex-col rounded-2xl border border-border bg-background/35">
            <div className="flex items-center justify-between border-b border-border px-4 py-3">
              <div>
                <p className="font-mono-ui text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                  Fila {level}
                </p>
                <h3 className="text-sm font-extrabold text-foreground">{getQueueTitle(level)}</h3>
              </div>
              <span className="rounded-md bg-secondary px-2 py-1 text-xs font-bold text-muted-foreground">
                {items.length}
              </span>
            </div>
            <div className="min-h-0 flex-1 space-y-2 overflow-auto p-3 scrollbar-thin">
              {items.slice(0, 8).map((demanda) => (
                <DemandMiniCard key={demanda.id} demanda={demanda} />
              ))}
              {items.length === 0 && (
                <EmptyState icon={CheckCircle2} text="Nenhuma demanda nesta fila agora." />
              )}
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}

function RoadmapDashboard({ candidates }: { candidates: NormalizedDemanda[] }) {
  return (
    <div className="grid gap-4 xl:grid-cols-[0.86fr_1.14fr]">
      <section className="grid gap-3">
        {roadmapTracks.map((track) => (
          <article key={track.title} className="rounded-2xl border border-border bg-background/35 p-4">
            <div className="flex items-start gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-xl border border-primary/20 bg-primary/10 text-primary">
                <GitBranch className="h-4 w-4" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="font-mono-ui text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                  {track.horizon}
                </p>
                <h3 className="text-sm font-extrabold text-foreground">{track.title}</h3>
                <p className="mt-2 text-xs leading-5 text-muted-foreground">{track.summary}</p>
              </div>
            </div>
            <div className="mt-4 flex items-center gap-3">
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted/35">
                <div className="h-full rounded-full bg-primary" style={{ width: `${track.progress}%` }} />
              </div>
              <span className="font-mono-ui text-xs text-muted-foreground">{track.progress}%</span>
            </div>
          </article>
        ))}
      </section>

      <section className="rounded-2xl border border-border bg-background/35">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div>
            <p className="section-label">Backlog</p>
            <h3 className="text-sm font-extrabold text-foreground">Demandas que podem virar trilha</h3>
          </div>
          <BookOpenCheck className="h-4 w-4 text-primary" />
        </div>
        <div className="grid gap-2 p-3">
          {candidates.map((demanda) => (
            <DemandMiniCard key={demanda.id} demanda={demanda} compact />
          ))}
          {candidates.length === 0 && (
            <EmptyState icon={GitBranch} text="Sem melhorias ou sugestões abertas para roadmap." />
          )}
        </div>
      </section>
    </div>
  );
}

function ImportantDemandRotator({ items }: { items: PrioritizedDemanda[] }) {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    if (items.length === 0) {
      setActiveIndex(0);
      return;
    }

    if (activeIndex >= items.length) {
      setActiveIndex(items.length - 1);
    }

    const timer = window.setInterval(() => {
      setActiveIndex((current) => (current + 1) % items.length);
    }, IMPORTANT_DEMAND_ROTATION_MS);

    return () => window.clearInterval(timer);
  }, [activeIndex, items.length]);

  const active = items[activeIndex];

  return (
    <section className="app-panel p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-xl border border-primary/20 bg-primary/10 text-primary">
            <CircleAlert className="h-4 w-4" />
          </span>
          <div>
            <p className="section-label">Atenção</p>
            <h2 className="text-sm font-extrabold">Demanda mais importante</h2>
          </div>
        </div>
        <span className="font-mono-ui text-xs text-muted-foreground">
          {items.length > 0 ? `${activeIndex + 1}/${items.length}` : "0/0"}
        </span>
      </div>

      {active ? (
        <div className="mt-4 rounded-2xl border border-border bg-background/35 p-4">
          <p className="font-display text-3xl font-extrabold text-foreground">{active.demanda.id}</p>
          <p className="mt-2 text-sm font-bold leading-5 text-foreground">
            {active.demanda.descricao || active.demanda.localExato || active.demanda.area}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">{active.demanda.nome}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Badge>{active.demanda.categoria}</Badge>
            <Badge tone="warning">{active.demanda.grau}</Badge>
            <Badge>{active.ageInDays} dias</Badge>
          </div>
        </div>
      ) : (
        <EmptyState icon={ShieldAlert} text="Nenhuma demanda ativa sincronizada." />
      )}
    </section>
  );
}

function DistributionPanel({
  title,
  values,
  labels,
}: {
  title: string;
  values: Record<string, number>;
  labels: string[];
}) {
  const max = getMaxValue(Object.values(values));

  return (
    <section className="app-panel p-4">
      <p className="section-label">Distribuição</p>
      <h2 className="mt-1 text-sm font-extrabold text-foreground">{title}</h2>
      <div className="mt-4 space-y-2.5">
        {labels.map((label) => (
          <BarRow
            key={label}
            label={label}
            value={values[label] ?? 0}
            max={max}
            color={label.includes("Cr") ? "bg-rose-500" : label.includes("Alta") ? "bg-orange-400" : "bg-primary"}
          />
        ))}
      </div>
    </section>
  );
}

function MetricCard({
  title,
  value,
  icon: Icon,
  tone,
}: {
  title: string;
  value: number;
  icon: ComponentType<{ className?: string }>;
  tone: string;
}) {
  return (
    <article className="app-panel p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="section-label">{title}</p>
          <p className={`mt-2 font-display text-3xl font-extrabold ${tone}`}>{value}</p>
        </div>
        <span className="grid h-9 w-9 place-items-center rounded-xl border border-border bg-background/45">
          <Icon className={`h-4 w-4 ${tone}`} />
        </span>
      </div>
    </article>
  );
}

function TabButton({
  active,
  onClick,
  icon: Icon,
  children,
}: {
  active: boolean;
  onClick: () => void;
  icon: ComponentType<{ className?: string }>;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex h-9 items-center gap-2 rounded-lg px-3 text-sm font-extrabold transition-colors ${
        active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
      }`}
    >
      <Icon className="h-4 w-4" />
      {children}
    </button>
  );
}

function DemandMiniCard({ demanda, compact = false }: { demanda: NormalizedDemanda; compact?: boolean }) {
  return (
    <div className="rounded-xl border border-border bg-card/50 p-3">
      <div className="flex items-center gap-2">
        <span className="font-mono-ui text-[11px] font-extrabold text-primary">{demanda.id}</span>
        <Badge>{demanda.categoria}</Badge>
        <span className="ml-auto text-[11px] text-muted-foreground">{demanda.status}</span>
      </div>
      <p className={`mt-2 font-bold leading-5 text-foreground ${compact ? "text-xs" : "text-sm"}`}>
        {demanda.descricao || demanda.localExato || demanda.area || "Demanda sem descrição"}
      </p>
      <div className="mt-2 flex items-center justify-between gap-3 text-[11px] text-muted-foreground">
        <span className="truncate">{demanda.nome || demanda.cliente || "Cliente não informado"}</span>
        <span>{demanda.operador || UNASSIGNED_OPERATOR}</span>
      </div>
    </div>
  );
}

function BarRow({
  label,
  value,
  max,
  color,
}: {
  label: string;
  value: number;
  max: number;
  color: string;
}) {
  const pct = max > 0 ? Math.max(5, (value / max) * 100) : 0;

  return (
    <div className="grid grid-cols-[86px_1fr_28px] items-center gap-2">
      <span className="truncate text-xs text-muted-foreground">{label}</span>
      <div className="h-2 overflow-hidden rounded-full bg-muted/30">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="text-right text-xs font-extrabold text-foreground">{value}</span>
    </div>
  );
}

function Badge({ children, tone = "primary" }: { children: ReactNode; tone?: "primary" | "warning" }) {
  return (
    <span
      className={`rounded-md border px-2 py-0.5 text-[10px] font-bold ${
        tone === "warning"
          ? "border-warning/25 bg-warning/12 text-warning"
          : "border-primary/25 bg-primary/10 text-primary"
      }`}
    >
      {children}
    </span>
  );
}

function EmptyState({
  icon: Icon,
  text,
}: {
  icon: ComponentType<{ className?: string }>;
  text: string;
}) {
  return (
    <div className="grid min-h-[112px] place-items-center rounded-xl border border-dashed border-border bg-background/25 p-4 text-center text-sm text-muted-foreground">
      <div>
        <Icon className="mx-auto mb-2 h-5 w-5 text-muted-foreground" />
        {text}
      </div>
    </div>
  );
}

function groupSupportQueues(demandas: NormalizedDemanda[]) {
  const queues: Record<string, NormalizedDemanda[]> = {
    N1: [],
    N2: [],
    N3: [],
  };

  demandas.forEach((demanda) => {
    if (demanda.grau === "Crítica" || demanda.categoria === "Bug crítico") {
      queues.N3.push(demanda);
      return;
    }

    if (demanda.grau === "Alta" || demanda.categoria === "Bug leve") {
      queues.N2.push(demanda);
      return;
    }

    queues.N1.push(demanda);
  });

  return queues;
}

function getQueueTitle(level: string) {
  if (level === "N3") return "Produto e crítico";
  if (level === "N2") return "Técnico e ajuste";
  return "Atendimento inicial";
}
