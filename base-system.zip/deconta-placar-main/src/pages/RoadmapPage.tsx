import { CalendarClock, GitBranch, Milestone, Target } from "lucide-react";
import { useRemoteData } from "@/hooks/use-data";

const roadmapTracks = [
  {
    title: "Suporte e SLA",
    horizon: "curto prazo",
    status: "Fase 1",
    description: "Triagem N1/N2/N3, tempo fixo por tipo de atendimento e previsao de acao.",
    progress: 34,
  },
  {
    title: "Roadmap do produto",
    horizon: "medio prazo",
    status: "Fase 2",
    description: "Trilhas estrategicas, tarefas derivadas de suporte e linha do tempo.",
    progress: 18,
  },
  {
    title: "Inteligencia e integracoes",
    horizon: "longo prazo",
    status: "Fase 3",
    description: "OpenAI, e-mail HTML, Google Workspace, automacoes e RBAC.",
    progress: 8,
  },
];

export default function RoadmapPage() {
  const { data } = useRemoteData();

  return (
    <div className="app-scroll">
      <div className="app-container animate-fade-in">
        <header>
          <p className="section-label">Roadmap · trilhas estrategicas</p>
          <h1 className="page-heading mt-2 tracking-tight">
            Roadmap operacional do DêConta
          </h1>
          <p className="page-lead mt-2">
            A antiga jornada vira planejamento: suporte, demandas e desenvolvimento
            passam a alimentar trilhas de produto com previsao e prioridade.
          </p>
        </header>

        <section className="grid gap-5 lg:grid-cols-3">
          {roadmapTracks.map((track) => (
            <article key={track.title} className="app-panel p-5">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-primary/12 text-primary">
                  <GitBranch className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-mono-ui text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                    {track.horizon}
                  </p>
                  <h2 className="font-display text-lg font-extrabold">{track.title}</h2>
                </div>
              </div>
              <p className="mt-4 min-h-[72px] text-sm leading-6 text-muted-foreground">
                {track.description}
              </p>
              <div className="mt-5 flex items-center justify-between text-xs">
                <span className="rounded-md border border-primary/20 bg-primary/10 px-2 py-1 font-bold text-primary">
                  {track.status}
                </span>
                <span className="font-mono-ui text-muted-foreground">{track.progress}%</span>
              </div>
              <div className="mt-3 h-1.5 rounded-full bg-background/80">
                <div
                  className="h-full rounded-full bg-primary"
                  style={{ width: `${track.progress}%` }}
                />
              </div>
            </article>
          ))}
        </section>

        <section className="grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
          <div className="app-panel p-5">
            <div className="mb-5 flex items-center gap-3">
              <Milestone className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-extrabold">Fila que vira roadmap</h2>
            </div>
            <div className="grid gap-3">
              {data.demandasAtivas.slice(0, 5).map((demanda) => (
                <div
                  key={demanda.id}
                  className="rounded-2xl border border-border bg-background/35 p-4"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono-ui text-xs font-extrabold text-primary">
                      {demanda.id}
                    </span>
                    <span className="rounded-md bg-muted px-2 py-1 text-[10px] text-muted-foreground">
                      {demanda.grau}
                    </span>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {demanda.status}
                    </span>
                  </div>
                  <p className="mt-3 text-sm font-bold leading-6">
                    {demanda.descricao || demanda.localExato || demanda.area}
                  </p>
                </div>
              ))}
              {data.demandasAtivas.length === 0 && (
                <div className="rounded-2xl border border-dashed border-border bg-background/35 p-8 text-center text-sm text-muted-foreground">
                  Nenhuma demanda ativa sincronizada para converter em trilha.
                </div>
              )}
            </div>
          </div>

          <aside className="app-panel p-5">
            <div className="mb-5 flex items-center gap-3">
              <Target className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-extrabold">Regras novas</h2>
            </div>
            <div className="space-y-3 text-sm text-muted-foreground">
              <RoadmapRule icon={CalendarClock} text="Toda demanda pode gerar uma tarefa." />
              <RoadmapRule icon={CalendarClock} text="Suporte N1/N2/N3 tem SLA proprio." />
              <RoadmapRule icon={CalendarClock} text="Roadmap mede impacto, urgencia e previsao." />
              <RoadmapRule icon={CalendarClock} text="E-mail, notas e Google entram como fontes." />
            </div>
          </aside>
        </section>
      </div>
    </div>
  );
}

function RoadmapRule({
  icon: Icon,
  text,
}: {
  icon: typeof CalendarClock;
  text: string;
}) {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-border bg-background/35 px-4 py-3">
      <Icon className="h-4 w-4 text-primary" />
      <span>{text}</span>
    </div>
  );
}
