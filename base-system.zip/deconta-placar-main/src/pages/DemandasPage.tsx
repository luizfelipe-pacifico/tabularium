import { useMemo, useState } from "react";
import {
  Clock3,
  Filter,
  Grid2X2,
  List,
  MoreHorizontal,
  RefreshCw,
  Search,
  SlidersHorizontal,
  UserRound,
  X,
} from "lucide-react";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { useRemoteData } from "@/hooks/use-data";
import {
  CATEGORY_LABELS,
  PRIORITY_LABELS,
  STATUS_LABELS,
  UNASSIGNED_OPERATOR,
  type NormalizedDemanda,
} from "@/lib/app-data";
import { getDemandLocationInfo } from "@/lib/demand-location";

interface Props {
  mode?: "ativas" | "historico";
  title?: string;
}

export default function DemandasPage({
  mode = "ativas",
  title = "Demandas Ativas",
}: Props) {
  const [search, setSearch] = useState("");
  const [selectedCategoria, setSelectedCategoria] = useState("");
  const [selectedGrau, setSelectedGrau] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [selectedOperador, setSelectedOperador] = useState("");
  const [selectedDemanda, setSelectedDemanda] = useState<NormalizedDemanda | null>(
    null,
  );

  const { data, isFetching } = useRemoteData();
  const allDemandas =
    mode === "historico" ? data.demandasHistorico : data.demandasAtivas;

  const categorias = useMemo(() => {
    const values = new Set(
      allDemandas.map((demanda) => demanda.categoria).filter(Boolean),
    );

    return values.size > 0
      ? Array.from(values).sort((left, right) => left.localeCompare(right, "pt-BR"))
      : [...CATEGORY_LABELS];
  }, [allDemandas]);

  const graus = useMemo(() => {
    const values = new Set(allDemandas.map((demanda) => demanda.grau).filter(Boolean));

    return values.size > 0
      ? Array.from(values).sort((left, right) => left.localeCompare(right, "pt-BR"))
      : [...PRIORITY_LABELS];
  }, [allDemandas]);

  const statuses = useMemo(() => {
    const values = new Set(
      allDemandas.map((demanda) => demanda.status).filter(Boolean),
    );

    if (values.size > 0) {
      return Array.from(values).sort((left, right) =>
        left.localeCompare(right, "pt-BR"),
      );
    }

    return mode === "historico"
      ? STATUS_LABELS.filter((status) =>
          status === "Concluída" || status === "Recusada"
        )
      : STATUS_LABELS.filter((status) =>
          status === "Em aberto" || status === "Em andamento"
        );
  }, [allDemandas, mode]);

  const operadores = useMemo(() => {
    const values = new Set(
      allDemandas.map((demanda) => demanda.operador || UNASSIGNED_OPERATOR),
    );

    return Array.from(values).sort((left, right) => left.localeCompare(right, "pt-BR"));
  }, [allDemandas]);

  const filtered = allDemandas.filter((demanda) => {
    if (selectedStatus && demanda.status !== selectedStatus) return false;
    if (selectedCategoria && demanda.categoria !== selectedCategoria) return false;
    if (selectedGrau && demanda.grau !== selectedGrau) return false;
    if (selectedOperador && demanda.operador !== selectedOperador) return false;
    if (
      search &&
      !Object.values(demanda).some((value) =>
        String(value).toLowerCase().includes(search.toLowerCase()),
      )
    ) {
      return false;
    }

    return true;
  });

  const FilterSelect = ({
    value,
    onChange,
    options,
    placeholder,
  }: {
    value: string;
    onChange: (value: string) => void;
    options: string[];
    placeholder: string;
  }) => (
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      className="rounded-xl border border-input bg-card/70 px-3 py-2 text-xs text-foreground outline-none transition-colors focus:border-primary"
    >
      <option value="">{placeholder}</option>
      {options.map((option) => (
        <option key={option} value={option}>
          {option}
        </option>
      ))}
    </select>
  );

  const groupedStatuses =
    mode === "historico"
      ? statuses
      : ["Em aberto", "Em andamento", "Concluída"];
  const totalFilters = [
    selectedCategoria,
    selectedGrau,
    selectedStatus,
    selectedOperador,
  ].filter(Boolean).length;

  return (
    <div className="flex h-full flex-col gap-[var(--app-section-gap)] overflow-hidden p-[var(--app-page-pad)] animate-fade-in">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4">
        <div>
          <p className="section-label">Operação · Kanban</p>
          <h1 className="page-heading mt-2 tracking-tight">
            {title === "Demandas Ativas" ? "Quadro de Demandas" : title}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {filtered.length} ticket(s) encontrados na fila sincronizada.
          </p>
        </div>

        {isFetching && (
          <div className="flex items-center gap-2 rounded-xl border border-primary/20 bg-primary/10 px-3 py-2 text-xs text-primary">
            <RefreshCw className="h-3.5 w-3.5 animate-spin" />
            Atualizando da API...
          </div>
        )}
      </div>

      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        {[
          ["Total de tickets", data.stats.totalDemandas, "bg-primary"],
          ["Ativas agora", data.stats.totalAtivas, "bg-warning"],
          ["Concluídas / dia", data.stats.concluidas, "bg-success"],
          ["Tempo médio SLA", "4.2h", "bg-muted-foreground"],
        ].map(([label, value, color]) => (
          <section key={label as string} className="app-panel px-5 py-5">
            <p className="font-mono-ui text-[11px] uppercase tracking-[0.28em] text-muted-foreground">
              {label as string}
            </p>
            <p className="font-display mt-3 text-3xl font-extrabold">{value}</p>
            <div className="mt-4 h-1 rounded-full bg-background/80">
              <div className={`h-full w-2/3 rounded-full ${color as string}`} />
            </div>
          </section>
        ))}
      </div>

      <div className="rounded-xl border border-border bg-card/55 px-4 py-3 text-xs text-muted-foreground">
        {data.sourceStatus.message}
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button className="inline-flex h-[var(--app-control-height)] items-center gap-2 rounded-xl border border-border bg-card/70 px-3 text-sm font-bold text-foreground">
          <Filter className="h-4 w-4" />
          Filtros
          <span className="rounded-md bg-muted px-1.5 py-0.5 text-xs text-muted-foreground">
            {totalFilters}
          </span>
        </button>
        <button className="inline-flex h-[var(--app-control-height)] items-center gap-2 rounded-xl border border-border bg-card/70 px-3 text-sm text-muted-foreground">
          <SlidersHorizontal className="h-4 w-4" />
          Prioridade
        </button>
        <div className="relative min-w-[240px] flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Buscar..."
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            className="h-[var(--app-control-height)] w-full rounded-xl border border-border bg-card/70 pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground/65 outline-none transition-colors focus:border-primary"
          />
        </div>
        <FilterSelect
          value={selectedCategoria}
          onChange={setSelectedCategoria}
          options={categorias}
          placeholder="Categoria"
        />
        <FilterSelect
          value={selectedGrau}
          onChange={setSelectedGrau}
          options={graus}
          placeholder="Grau"
        />
        <FilterSelect
          value={selectedStatus}
          onChange={setSelectedStatus}
          options={statuses}
          placeholder="Status"
        />
        <FilterSelect
          value={selectedOperador}
          onChange={setSelectedOperador}
          options={operadores}
          placeholder="Operador"
        />
        <div className="ml-auto hidden items-center overflow-hidden rounded-xl border border-border bg-card/70 xl:flex">
          <button className="inline-flex h-9 items-center gap-2 bg-primary/12 px-3 text-sm font-bold text-foreground">
            <Grid2X2 className="h-4 w-4" />
            Kanban
          </button>
          <button className="inline-flex h-9 items-center gap-2 px-3 text-sm text-muted-foreground">
            <List className="h-4 w-4" />
            Lista
          </button>
        </div>
      </div>

      <div className="grid min-h-0 flex-1 gap-5 overflow-auto pb-2 scrollbar-thin xl:grid-cols-3">
        {groupedStatuses.map((status, index) => {
          const cards = filtered.filter((demanda) => demanda.status === status);
          const dotClass =
            status === "Em aberto"
              ? "bg-muted-foreground"
              : status === "Em andamento"
                ? "bg-warning"
                : status === "Concluída"
                  ? "bg-success"
                  : "bg-destructive";

          return (
            <section key={status} className="min-w-[320px]">
              <div className="mb-4 flex items-center gap-2 px-1">
                <span className={`h-2.5 w-2.5 rounded-full ${dotClass}`} />
                <h2 className="font-display text-lg font-extrabold">{status}</h2>
                <span className="rounded-md bg-muted px-2 py-1 text-xs text-muted-foreground">
                  {cards.length}
                </span>
                <MoreHorizontal className="ml-auto h-4 w-4 text-muted-foreground" />
              </div>
              <p className="font-mono-ui mb-4 text-[10px] uppercase tracking-[0.28em] text-muted-foreground">
                {index === 0
                  ? "Aguardando atribuicao"
                  : index === 1
                    ? "Em execucao"
                    : "Entregues hoje"}
              </p>

              <div className="space-y-4">
                {cards.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-border bg-card/35 px-4 py-10 text-center text-sm text-muted-foreground">
                    <Filter className="mx-auto mb-3 h-7 w-7 opacity-40" />
                    Nenhuma demanda nesta coluna.
                  </div>
                ) : (
                  cards.map((demanda) => {
                    const location = getDemandLocationInfo(demanda);
                    const overdue = demanda.grau === "Crítica" || demanda.grau === "Alta";

                    return (
                      <article
                        key={demanda.id}
                        onClick={() => setSelectedDemanda(demanda)}
                        className={`cursor-pointer rounded-2xl border bg-card/95 p-5 transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-xl ${
                          overdue && status === "Em andamento"
                            ? "border-destructive/45 shadow-[inset_0_-4px_0_hsl(var(--destructive))]"
                            : "border-border"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-mono-ui text-xs font-extrabold text-primary">
                            {demanda.id}
                          </span>
                          <span className="ml-auto rounded-md border border-border bg-secondary px-2 py-1 text-[10px] text-muted-foreground">
                            {demanda.grau}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {demanda.data || "hoje"}
                          </span>
                        </div>

                        <h3 className="mt-4 text-base font-extrabold leading-6 text-foreground">
                          {demanda.descricao || location.primary || "Demanda sem descricao"}
                        </h3>
                        <p className="font-mono-ui mt-4 text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                          {demanda.area || demanda.cliente || "Clientes"}
                        </p>
                        {location.secondary && (
                          <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                            {location.secondary}
                          </p>
                        )}

                        <div className="mt-5 flex flex-wrap gap-2">
                          <StatusBadge type="categoria" value={demanda.categoria} />
                          <StatusBadge type="grau" value={demanda.grau} />
                        </div>

                        <div className="mt-5 flex items-center gap-3 border-t border-border/70 pt-4 text-xs text-muted-foreground">
                          <span className="grid h-8 w-8 place-items-center rounded-full bg-muted font-bold text-foreground">
                            {(demanda.operador || UNASSIGNED_OPERATOR)
                              .slice(0, 2)
                              .toUpperCase()}
                          </span>
                          <span className="truncate">
                            {demanda.operador || UNASSIGNED_OPERATOR}
                          </span>
                          <span className="ml-auto inline-flex items-center gap-1">
                            <Clock3 className="h-3.5 w-3.5" />
                            {status === "Concluída" ? "45m" : demanda.data || "4h"}
                          </span>
                        </div>
                      </article>
                    );
                  })
                )}
              </div>
            </section>
          );
        })}
      </div>

      {selectedDemanda && (
        <div
          className="fixed inset-0 z-50 flex justify-end"
          onClick={() => setSelectedDemanda(null)}
        >
          <div className="absolute inset-0 bg-background/60 backdrop-blur-sm" />
          <div
            className="relative h-full w-[460px] overflow-y-auto border-l border-border bg-card p-6 animate-fade-in"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-lg font-extrabold text-foreground">
                {selectedDemanda.id}
              </h2>
              <button
                onClick={() => setSelectedDemanda(null)}
                className="p-1 hover:bg-muted rounded-md transition-colors"
              >
                <X className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>

            <div className="space-y-4">
              {[
                { label: "Descrição", value: selectedDemanda.descricao },
                { label: "Data", value: selectedDemanda.data },
                { label: "Solicitante", value: selectedDemanda.nome },
                { label: "E-mail", value: selectedDemanda.email },
                { label: "Área", value: selectedDemanda.area },
                { label: "Local exato", value: selectedDemanda.localExato },
                { label: "Operador", value: selectedDemanda.operador },
                { label: "Como aconteceu", value: selectedDemanda.comoAconteceu },
                {
                  label: "O que deveria acontecer",
                  value: selectedDemanda.oQueDeveriaAcontecer,
                },
                {
                  label: "Observações extras",
                  value: selectedDemanda.observacoesExtras,
                },
                { label: "Anexo", value: selectedDemanda.anexo },
              ]
                .filter((item) => item.value)
                .map((item) => (
                  <div key={item.label}>
                    <label className="text-[11px] text-muted-foreground uppercase tracking-wide">
                      {item.label}
                    </label>
                    <p className="text-sm text-foreground mt-0.5 whitespace-pre-wrap">
                      {item.value}
                    </p>
                  </div>
                ))}

              <div className="flex flex-wrap gap-2 pt-2">
                <StatusBadge type="categoria" value={selectedDemanda.categoria} />
                <StatusBadge type="grau" value={selectedDemanda.grau} />
                <StatusBadge type="status" value={selectedDemanda.status} />
              </div>
              <div className="mt-6 flex items-center gap-3 rounded-2xl border border-border bg-background/45 p-4 text-sm text-muted-foreground">
                <UserRound className="h-4 w-4 text-primary" />
                Responsável: {selectedDemanda.operador || UNASSIGNED_OPERATOR}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
