import { useMemo, useState } from "react";
import {
  CheckCircle2,
  Clock,
  PencilLine,
  RefreshCw,
  User,
  Users,
  Zap,
} from "lucide-react";
import { DeveloperProfileDialog } from "@/components/dev/DeveloperProfileDialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAppPreferences } from "@/contexts/app-preferences";
import { useRemoteData } from "@/hooks/use-data";
import { toast } from "@/hooks/use-toast";
import type { DevProfile } from "@/lib/app-data";
import { UNASSIGNED_OPERATOR } from "@/lib/app-data";
import { getAvatarLabel, mergeOperatorSummaries } from "@/lib/dev-profiles";

export default function OperadoresPage() {
  const { data, isFetching } = useRemoteData();
  const { config, savePreferences } = useAppPreferences();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingOperator, setEditingOperator] = useState<{
    profile: DevProfile;
    index: number | null;
  } | null>(null);

  const operadores = useMemo(
    () => mergeOperatorSummaries(data.operadores, config.devProfiles),
    [config.devProfiles, data.operadores],
  );
  const unassignedCount = data.demandasAtivas.filter(
    (demanda) => demanda.operador === UNASSIGNED_OPERATOR,
  ).length;

  const startEdit = (nome: string, email: string, fotoUrl?: string) => {
    const profileIndex = (config.devProfiles ?? []).findIndex(
      (profile) => profile.email === email || profile.nome === nome,
    );
    const profile =
      profileIndex >= 0
        ? config.devProfiles?.[profileIndex]
        : {
            nome,
            email,
            fotoUrl: fotoUrl || "",
            cargo: "Desenvolvedor",
          };

    setEditingOperator({
      profile: profile ?? {
        nome,
        email,
        fotoUrl: fotoUrl || "",
        cargo: "Desenvolvedor",
      },
      index: profileIndex >= 0 ? profileIndex : null,
    });
    setDialogOpen(true);
  };

  const handleSaveProfile = async (profile: DevProfile) => {
    const nextProfiles = [...(config.devProfiles ?? [])];

    if (editingOperator?.index === null || editingOperator?.index === undefined) {
      nextProfiles.push(profile);
    } else {
      nextProfiles[editingOperator.index] = profile;
    }

    await savePreferences({ devProfiles: nextProfiles });
    toast({
      title: "Informações do operador salvas",
      description: "A edição ficou registrada apenas dentro do placar.",
    });
  };

  return (
    <div className="app-scroll">
      <div className="flex flex-col gap-[var(--app-section-gap)] animate-fade-in">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="page-heading">Operadores</h1>
            <p className="page-lead mt-2">
              Os dados de volume vêm da API; foto e e-mail podem ser ajustados localmente.
            </p>
          </div>

          {isFetching && (
            <div className="flex items-center gap-2 text-xs text-primary">
              <RefreshCw className="h-3.5 w-3.5 animate-spin" />
              Atualizando da API...
            </div>
          )}
        </div>

        <div className="rounded-xl border border-border bg-card px-4 py-3 text-xs text-muted-foreground">
          {data.sourceStatus.message}
        </div>

        {operadores.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card p-8 text-center">
            <p className="text-sm font-semibold text-foreground">
              Nenhum operador ou dev cadastrado no momento.
            </p>
            <p className="mt-2 text-xs text-muted-foreground">
              Assim que a API retornar atribuições ou você cadastrar perfis, os cards
              aparecem aqui automaticamente.
            </p>
          </div>
        ) : (
          <div className="grid gap-5 xl:grid-cols-2">
            {operadores.map((operador) => (
              <div
                key={`${operador.nome}-${operador.email}`}
                className="rounded-2xl border border-border bg-card p-6 card-glow transition-all duration-300 hover:card-glow-hover"
              >
                <div className="mb-5 flex items-start justify-between gap-4">
                  <div className="flex min-w-0 items-center gap-4">
                    <Avatar className="h-12 w-12 border border-primary/20">
                      <AvatarImage src={operador.fotoUrl || ""} alt={operador.nome} />
                      <AvatarFallback className="bg-primary/15 text-sm font-bold text-primary">
                        {operador.avatar || getAvatarLabel(operador.nome)}
                      </AvatarFallback>
                    </Avatar>

                    <div className="min-w-0">
                      <h3 className="truncate font-semibold text-foreground">
                        {operador.nome}
                      </h3>
                      <p className="text-xs text-muted-foreground">
                        {operador.cargo || "Desenvolvedor"}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">
                        {operador.email || "Sem e-mail informado"}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() =>
                      startEdit(operador.nome, operador.email, operador.fotoUrl)
                    }
                    className="inline-flex items-center gap-2 rounded-lg bg-secondary px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:bg-accent"
                  >
                    <PencilLine className="h-3.5 w-3.5" />
                    Editar
                  </button>
                </div>

                <div className="grid grid-cols-4 gap-3">
                  {[
                    {
                      label: "Total",
                      value: operador.total,
                      icon: User,
                      color: "text-foreground",
                    },
                    {
                      label: "Em aberto",
                      value: operador.abertas,
                      icon: Clock,
                      color: "text-status-open",
                    },
                    {
                      label: "Andamento",
                      value: operador.andamento,
                      icon: Zap,
                      color: "text-status-progress",
                    },
                    {
                      label: "Concluídas",
                      value: operador.concluidas,
                      icon: CheckCircle2,
                      color: "text-status-done",
                    },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="rounded-lg bg-secondary/50 p-3 text-center"
                    >
                      <item.icon className={`mx-auto mb-1 h-4 w-4 ${item.color}`} />
                      <p className={`text-xl font-bold ${item.color}`}>{item.value}</p>
                      <span className="text-[10px] text-muted-foreground">
                        {item.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="rounded-2xl border border-border bg-card p-6 card-glow">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-muted text-muted-foreground">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Não atribuídas</h3>
              <p className="text-xs text-muted-foreground">
                Demandas ativas sem dev definido na API.
              </p>
            </div>
          </div>

          <div className="rounded-xl bg-secondary/50 p-4 text-center">
            <p className="text-3xl font-bold text-warning">{unassignedCount}</p>
            <span className="text-xs text-muted-foreground">demandas ativas</span>
          </div>
        </div>
      </div>

      <DeveloperProfileDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title="Editar informações do operador"
        description="Essas informações são locais ao placar e não alteram a planilha de origem."
        profile={editingOperator?.profile}
        onSave={handleSaveProfile}
      />
    </div>
  );
}
