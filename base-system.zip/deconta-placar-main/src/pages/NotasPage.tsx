import { FileText, Lightbulb, StickyNote } from "lucide-react";
import { useState } from "react";

const initialNotes = [
  {
    title: "E-mail de atualização",
    text: "Criar modelo HTML para comunicar mudanças do sistema.",
  },
  {
    title: "Triagem rapida",
    text: "Transformar insight em demanda, tarefa ou item de roadmap.",
  },
];

export default function NotasPage() {
  const [draft, setDraft] = useState("");
  const [notes, setNotes] = useState(initialNotes);

  const addNote = () => {
    const text = draft.trim();
    if (!text) return;
    setNotes([{ title: "Nota rapida", text }, ...notes]);
    setDraft("");
  };

  return (
    <div className="app-scroll">
      <div className="app-container animate-fade-in">
        <header>
          <p className="section-label">Notas · insights · conversao</p>
          <h1 className="page-heading mt-2">Notas rápidas</h1>
          <p className="page-lead mt-2">
            Captura leve no estilo Notes/Notion para transformar ideias em demanda,
            suporte ou trilha de roadmap.
          </p>
        </header>

        <section className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="app-panel p-5">
            <div className="mb-4 flex items-center gap-3">
              <StickyNote className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-extrabold">Nova nota</h2>
            </div>
            <textarea
              value={draft}
              onChange={(event) => setDraft(event.target.value)}
              placeholder="Escreva um insight, resposta, tarefa ou ideia..."
              className="field-input min-h-[220px] w-full resize-none rounded-2xl p-4 text-sm"
            />
            <button
              onClick={addNote}
              className="mt-4 h-[var(--app-control-height)] w-full rounded-xl bg-primary font-extrabold text-primary-foreground"
            >
              Salvar nota
            </button>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {notes.map((note, index) => (
              <article key={`${note.title}-${index}`} className="app-panel p-5">
                <Lightbulb className="h-5 w-5 text-primary" />
                <h2 className="font-display mt-4 text-lg font-extrabold">{note.title}</h2>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">{note.text}</p>
                <div className="mt-5 flex items-center gap-2 rounded-xl border border-border bg-background/35 px-3 py-2 text-xs text-muted-foreground">
                  <FileText className="h-4 w-4 text-primary" />
                  Pode virar demanda, tarefa ou e-mail.
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
