import { useMemo, useState, type ComponentType } from "react";
import { Mail, PencilLine, Plus, Trash2, Users } from "lucide-react";
import { DeveloperProfileDialog } from "@/components/dev/DeveloperProfileDialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAppPreferences } from "@/contexts/app-preferences";
import { toast } from "@/hooks/use-toast";
import type { DevProfile } from "@/lib/app-data";
import { getAvatarLabel } from "@/lib/dev-profiles";

export default function PerfilPage() {
  const { config, savePreferences } = useAppPreferences();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const profiles = useMemo(() => config.devProfiles ?? [], [config.devProfiles]);
  const editingProfile =
    editingIndex === null ? null : (profiles[editingIndex] ?? null);

  const handleAdd = () => {
    setEditingIndex(null);
    setDialogOpen(true);
  };

  const handleEdit = (index: number) => {
    setEditingIndex(index);
    setDialogOpen(true);
  };

  const handleDelete = async (index: number) => {
    const nextProfiles = profiles.filter((_, currentIndex) => currentIndex !== index);
    await savePreferences({ devProfiles: nextProfiles });
    toast({
      title: "Perfil removido",
      description: "O dev foi removido apenas do placar local.",
    });
  };

  const handleSave = async (profile: DevProfile) => {
    const nextProfiles = [...profiles];

    if (editingIndex === null) {
      nextProfiles.push(profile);
    } else {
      nextProfiles[editingIndex] = profile;
    }

    await savePreferences({ devProfiles: nextProfiles });
    toast({
      title: editingIndex === null ? "Dev adicionado" : "Perfil atualizado",
      description: "As informações foram salvas localmente no placar.",
    });
  };

  return (
    <div className="app-scroll">
      <div className="app-container animate-fade-in">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="page-heading">Perfis dos devs</h1>
            <p className="page-lead mt-2">
              Este espaço concentra as informações internas do time de desenvolvimento
              usadas pelo placar, incluindo foto e e-mail de cada pessoa.
            </p>
          </div>

          <button
            onClick={handleAdd}
            className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
          >
            <Plus className="h-4 w-4" />
            Adicionar dev
          </button>
        </div>

        <div className="rounded-2xl border border-border bg-card p-5 card-glow">
          <div className="grid gap-4 md:grid-cols-3">
            <SummaryCard
              icon={Users}
              label="Perfis cadastrados"
              value={String(profiles.length)}
              detail="Usados no placar e em Operadores"
            />
            <SummaryCard
              icon={Mail}
              label="Perfis com e-mail"
              value={String(profiles.filter((profile) => profile.email).length)}
              detail="Contato interno rápido"
            />
            <SummaryCard
              icon={PencilLine}
              label="Edição local"
              value="100%"
              detail="Sem depender da API para dados do time"
            />
          </div>
        </div>

        {profiles.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card px-6 py-12 text-center">
            <p className="text-base font-semibold text-foreground">
              Nenhum dev cadastrado ainda.
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Adicione os perfis aqui para preencher foto e e-mail do time no placar.
            </p>
          </div>
        ) : (
          <div className="grid gap-4 lg:grid-cols-2 xl:grid-cols-3">
            {profiles.map((profile, index) => (
              <article
                key={`${profile.nome}-${profile.email || index}`}
                className="rounded-2xl border border-border bg-card p-5 card-glow transition-all hover:card-glow-hover"
              >
                <div className="flex items-start gap-4">
                  <Avatar className="h-16 w-16 border border-primary/20">
                    <AvatarImage src={profile.fotoUrl || ""} alt={profile.nome} />
                    <AvatarFallback className="bg-primary/15 text-base font-bold text-primary">
                      {getAvatarLabel(profile.nome)}
                    </AvatarFallback>
                  </Avatar>

                  <div className="min-w-0 flex-1">
                    <h2 className="truncate text-base font-semibold text-foreground">
                      {profile.nome}
                    </h2>
                    <p className="text-sm text-muted-foreground">Desenvolvedor</p>
                    <p className="mt-2 truncate text-sm text-foreground">
                      {profile.email || "Sem e-mail informado"}
                    </p>
                  </div>
                </div>

                <div className="mt-5 flex gap-2">
                  <button
                    onClick={() => handleEdit(index)}
                    className="inline-flex flex-1 items-center justify-center gap-2 rounded-lg bg-secondary px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:bg-accent"
                  >
                    <PencilLine className="h-3.5 w-3.5" />
                    Editar
                  </button>
                  <button
                    onClick={() => handleDelete(index)}
                    className="inline-flex items-center justify-center gap-2 rounded-lg bg-destructive/10 px-3 py-2 text-xs font-semibold text-destructive transition-colors hover:bg-destructive/15"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Remover
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>

      <DeveloperProfileDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title={editingIndex === null ? "Adicionar dev" : "Editar perfil"}
        description="Esses dados ficam salvos localmente no app e alimentam as áreas de perfis e operadores."
        profile={editingProfile}
        onSave={handleSave}
      />
    </div>
  );
}

function SummaryCard({
  icon: Icon,
  label,
  value,
  detail,
}: {
  icon: ComponentType<{ className?: string }>;
  label: string;
  value: string;
  detail: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-secondary/45 p-4">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wide text-muted-foreground">
          {label}
        </span>
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <p className="mt-3 text-3xl font-black tracking-tight text-foreground">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{detail}</p>
    </div>
  );
}
