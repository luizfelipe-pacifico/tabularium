import DemandasPage from "./DemandasPage";

export default function HistoricoPage() {
  return <DemandasPage mode="historico" title="Histórico" />;
}
