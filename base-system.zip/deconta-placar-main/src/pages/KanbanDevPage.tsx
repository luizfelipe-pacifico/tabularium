import { Code2, GitBranch, ShieldAlert, TimerReset } from "lucide-react";
import { useMemo } from "react";
import { useRemoteData } from "@/hooks/use-data";
import type { NormalizedDemanda } from "@/lib/app-data";

const devColumns = [
  {
    title: "RUN",
    subtitle: "Bugs imprevistos e manutenção",
    icon: TimerReset,
    match: (demanda: NormalizedDemanda) =>
      demanda.categoria === "Bug crítico" || demanda.categoria === "Bug leve",
  },
  {
    title: "Correção direta",
    subtitle: "N2 sobe para main sem virar projeto",
    icon: ShieldAlert,
    match: (demanda: NormalizedDemanda) =>
      demanda.grau === "Alta" && demanda.categoria !== "Melhoria",
  },
  {
    title: "Change",
    subtitle: "Evoluções, projetos e roadmap",
    icon: GitBranch,
    match: (demanda: NormalizedDemanda) =>
      demanda.categoria === "Melhoria" || demanda.categoria === "Sugestão",
  },
];

const priorityOrder = ["Funcionalidade", "Performance", "UX", "UI"];

export default function KanbanDevPage() {
  const { data } = useRemoteData();

  const columns = useMemo(
    () =>
      devColumns.map((column) => ({
        ...column,
        items: data.demandasAtivas.filter(column.match).slice(0, 8),
      })),
    [data.demandasAtivas],
  );

  return (
    <div className="app-scroll">
      <div className="app-container app-container-wide animate-fade-in">
        <header>
          <p className="section-label">Kanban · desenvolvimento</p>
          <h1 className="page-heading mt-2">Atividade de desenvolvedor</h1>
          <p className="page-lead mt-2">
            Separação operacional entre RUN e Change para evitar misturar manutenção urgente com evolução planejada.
          </p>
        </header>

        <section className="grid gap-4 lg:grid-cols-4">
          {priorityOrder.map((item, index) => (
            <article key={item} className="app-panel p-4">
              <p className="section-label">{index + 1}º prioridade</p>
              <h2 className="mt-2 font-display text-lg font-extrabold text-foreground">
                {item}
              </h2>
            </article>
          ))}
        </section>

        <section className="grid gap-4 xl:grid-cols-3">
          {columns.map((column) => (
            <article key={column.title} className="app-panel flex min-h-[520px] flex-col p-0">
              <div className="flex items-start gap-3 border-b border-border p-4">
                <span className="grid h-10 w-10 place-items-center rounded-xl border border-primary/20 bg-primary/10 text-primary">
                  <column.icon className="h-5 w-5" />
                </span>
                <div>
                  <p className="section-label">{column.title}</p>
                  <h2 className="font-display text-lg font-extrabold text-foreground">
                    {column.subtitle}
                  </h2>
                </div>
              </div>
              <div className="flex-1 space-y-3 overflow-auto p-4 scrollbar-thin">
                {column.items.map((demanda) => (
                  <DevCard key={`${column.title}-${demanda.id}`} demanda={demanda} />
                ))}
                {column.items.length === 0 && (
                  <div className="grid min-h-[180px] place-items-center rounded-xl border border-dashed border-border bg-background/30 p-5 text-center text-sm text-muted-foreground">
                    Nenhuma atividade nesta etapa.
                  </div>
                )}
              </div>
            </article>
          ))}
        </section>
      </div>
    </div>
  );
}

function DevCard({ demanda }: { demanda: NormalizedDemanda }) {
  return (
    <div className="rounded-xl border border-border bg-background/35 p-4">
      <div className="flex items-center gap-2">
        <span className="font-mono-ui text-xs font-extrabold text-primary">{demanda.id}</span>
        <span className="rounded-md border border-primary/20 bg-primary/10 px-2 py-0.5 text-[10px] font-bold text-primary">
          {demanda.grau}
        </span>
      </div>
      <p className="mt-3 text-sm font-bold leading-5 text-foreground">
        {demanda.descricao || demanda.localExato || demanda.area}
      </p>
      <div className="mt-3 flex items-center justify-between gap-3 text-xs text-muted-foreground">
        <span>{demanda.categoria}</span>
        <span className="inline-flex items-center gap-1">
          <Code2 className="h-3.5 w-3.5" />
          {demanda.operador}
        </span>
      </div>
    </div>
  );
}
