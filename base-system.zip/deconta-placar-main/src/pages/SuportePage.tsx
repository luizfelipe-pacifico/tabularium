import { Clock, Headphones, ShieldAlert, TimerReset } from "lucide-react";
import { useRemoteData } from "@/hooks/use-data";

const supportLevels = [
  ["N1", "Atendimento e duvida", "15m a 30m"],
  ["N2", "Ajuste tecnico", "2h a 1 dia"],
  ["N3", "Bug critico / desenvolvimento", "prioridade dinamica"],
];

export default function SuportePage() {
  const { data } = useRemoteData();

  return (
    <div className="app-scroll">
      <div className="app-container animate-fade-in">
        <header>
          <p className="section-label">Suporte · SLA · atendimento</p>
          <h1 className="page-heading mt-2">Central de suporte</h1>
          <p className="page-lead mt-2">
            Separacao operacional entre atendimento e desenvolvimento, mesmo quando
            o executor e o mesmo. O objetivo e controlar SLA, impacto e previsao.
          </p>
        </header>

        <section className="grid gap-5 lg:grid-cols-3">
          {supportLevels.map(([level, title, sla]) => (
            <article key={level} className="app-panel p-5">
              <div className="flex items-center justify-between">
                <span className="font-display text-3xl font-extrabold text-primary">
                  {level}
                </span>
                <Headphones className="h-5 w-5 text-muted-foreground" />
              </div>
              <h2 className="mt-4 font-display text-lg font-extrabold">{title}</h2>
              <p className="font-mono-ui mt-3 text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                SLA sugerido · {sla}
              </p>
            </article>
          ))}
        </section>

        <section className="grid gap-5 lg:grid-cols-[0.95fr_1.05fr]">
          <div className="app-panel p-5">
            <div className="mb-5 flex items-center gap-3">
              <TimerReset className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-extrabold">SLA em aberto</h2>
            </div>
            <div className="grid gap-3">
              {[
                ["Demandas abertas", data.stats.emAberto],
                ["Em andamento", data.stats.emAndamento],
                ["Críticas", data.stats.porGrau.Crítica],
                ["Alta prioridade", data.stats.porGrau.Alta],
              ].map(([label, value]) => (
                <div
                  key={label as string}
                  className="flex items-center justify-between rounded-xl border border-border bg-background/35 px-4 py-3"
                >
                  <span className="text-sm text-muted-foreground">{label as string}</span>
                  <span className="font-display text-xl font-extrabold">{value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="app-panel p-5">
            <div className="mb-5 flex items-center gap-3">
              <ShieldAlert className="h-5 w-5 text-primary" />
              <h2 className="font-display text-lg font-extrabold">Fila de atendimento</h2>
            </div>
            <div className="space-y-3">
              {data.demandasAtivas.slice(0, 6).map((demanda) => (
                <div
                  key={demanda.id}
                  className="grid gap-3 rounded-2xl border border-border bg-background/35 p-4 md:grid-cols-[auto_1fr_auto]"
                >
                  <span className="font-mono-ui text-xs font-extrabold text-primary">
                    {demanda.id}
                  </span>
                  <span className="text-sm font-bold">
                    {demanda.descricao || demanda.localExato || demanda.area}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3.5 w-3.5" />
                    {demanda.grau}
                  </span>
                </div>
              ))}
              {data.demandasAtivas.length === 0 && (
                <div className="rounded-2xl border border-dashed border-border bg-background/35 p-8 text-center text-sm text-muted-foreground">
                  Sem tickets de suporte sincronizados agora.
                </div>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
