import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  CheckCircle2,
  LayoutPanelLeft,
  MonitorCog,
  RefreshCw,
  Save,
  Wifi,
  ZoomIn,
} from "lucide-react";
import { Slider } from "@/components/ui/slider";
import { useAppPreferences } from "@/contexts/app-preferences";
import { useRemoteData } from "@/hooks/use-data";
import { toast } from "@/hooks/use-toast";
import {
  getConnectionLabel,
  getConnectionState,
  toAppDataSnapshot,
  type AppConfig,
} from "@/lib/app-data";
import { syncNow } from "@/services/dataService";
import { testConnection, type SourceConnectionResult } from "@/services/configService";
import { rodarDiagnosticoPlacarApi } from "@/services/runPlacarApiDiagnostic";

function PageIntro({
  onSave,
  saved,
}: {
  onSave: () => void;
  saved: boolean;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-2">
      <div className="min-w-0">
        <p className="text-[10px] font-semibold uppercase tracking-[0.26em] text-primary/65">
          Preferências
        </p>
        <h1 className="mt-0.5 text-[20px] font-semibold tracking-tight text-foreground">
          Configurações
        </h1>
        <p className="mt-0.5 text-[11px] text-muted-foreground">
          Ambiente, conexão e visual concentrados sem desperdício de espaço.
        </p>
      </div>

      <button
        onClick={onSave}
        className="inline-flex items-center gap-2 rounded-xl border border-primary/15 bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground transition-all hover:brightness-110"
      >
        {saved ? <CheckCircle2 className="h-4 w-4" /> : <Save className="h-4 w-4" />}
        {saved ? "Salvo" : "Salvar"}
      </button>
    </div>
  );
}

function SectionCard({
  eyebrow,
  title,
  description,
  icon: Icon,
  children,
  className = "",
  bodyClassName = "",
}: {
  eyebrow: string;
  title: string;
  description: string;
  icon: typeof Wifi;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
}) {
  return (
    <section
      className={`surface-motion flex min-h-0 min-w-0 flex-col overflow-hidden rounded-2xl border border-border bg-card p-3 card-glow ${className}`}
    >
      <div className="flex items-start gap-2.5">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl border border-primary/15 bg-primary/10">
          <Icon className="h-4 w-4 text-primary" />
        </span>
        <div className="min-w-0">
          <p className="text-[10px] font-semibold uppercase tracking-[0.24em] text-primary/60">
            {eyebrow}
          </p>
          <h2 className="mt-0.5 text-sm font-semibold text-foreground">{title}</h2>
          <p className="mt-0.5 text-[11px] text-muted-foreground">{description}</p>
        </div>
      </div>

      <div className={`mt-3 flex min-h-0 flex-col gap-2.5 ${bodyClassName}`}>{children}</div>
    </section>
  );
}

function SummaryTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border/80 bg-background/35 px-3 py-2">
      <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-muted-foreground/70">
        {label}
      </p>
      <p className="mt-0.5 text-sm font-semibold text-foreground">{value}</p>
    </div>
  );
}

export default function ConfiguracoesPage() {
  const { config: persistedConfig, savePreferences } = useAppPreferences();
  const { data } = useRemoteData();
  const [config, setConfig] = useState<AppConfig>(persistedConfig);
  const [saved, setSaved] = useState(false);
  const [testing, setTesting] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const renderedPayload = useMemo(() => toAppDataSnapshot(data), [data]);

  useEffect(() => {
    setConfig(persistedConfig);
  }, [persistedConfig]);

  const handleSave = async () => {
    const savedConfig = await savePreferences(config);
    setConfig(savedConfig);
    setSaved(true);
    toast({
      title: "Configurações salvas",
      description: "Preferências locais e fonte de dados foram atualizadas.",
    });
    window.setTimeout(() => setSaved(false), 2000);
  };

  const handleTest = async () => {
    setTesting(true);

    try {
      const result = await testConnection(config.fonteUrl);
      showConnectionToast(result);
    } finally {
      setTesting(false);
    }
  };

  const handleSync = async () => {
    setSyncing(true);

    try {
      const savedConfig = await savePreferences(config);
      setConfig(savedConfig);
      const result = await syncNow();
      const connectionState = getConnectionState(result.sourceStatus);
      await savePreferences({
        ultimaSincronizacao: result.lastUpdated ?? persistedConfig.ultimaSincronizacao,
      });
      toast({
        title:
          connectionState === "connected"
            ? "Sincronização concluída"
            : connectionState === "cache"
              ? "Usando cache local"
              : "Erro de conexão",
        description: result.sourceStatus.message,
        variant: connectionState === "error" ? "destructive" : "default",
      });
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="h-full overflow-hidden p-2.5 md:p-3">
      <div className="mx-auto grid h-full min-h-0 w-full max-w-[1680px] grid-rows-[auto_minmax(0,1fr)] gap-2.5 animate-fade-in">
        <PageIntro onSave={handleSave} saved={saved} />

        <div className="grid min-h-0 gap-2.5 lg:grid-cols-[minmax(230px,0.88fr)_minmax(260px,0.98fr)_minmax(300px,1.08fr)]">
          <section className="flex min-h-0 flex-col gap-2.5">
            <SectionCard
              eyebrow="Integração"
              title="Fonte de dados"
              description="Leitura do Apps Script e sincronização manual."
              icon={Wifi}
            >
              <Field label="URL da API">
                <input
                  value={config.fonteUrl}
                  onChange={(event) =>
                    setConfig((previous) => ({
                      ...previous,
                      fonteUrl: event.target.value,
                    }))
                  }
                  className="field-input w-full px-3 py-2 text-sm"
                />
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Endpoint publicado do Apps Script usado pelo app.
                </p>
              </Field>

              <div className="grid gap-2 sm:grid-cols-[minmax(0,1fr)_minmax(0,0.95fr)] sm:items-end">
                <Field label="Intervalo de atualização (minutos)">
                  <input
                    type="number"
                    min={1}
                    value={config.intervalo}
                    onChange={(event) =>
                      setConfig((previous) => ({
                        ...previous,
                        intervalo: Number(event.target.value || 1),
                      }))
                    }
                    className="field-input w-full px-3 py-2 text-sm"
                  />
                </Field>

                <div className="rounded-2xl border border-border/80 bg-background/35 px-3 py-2">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.22em] text-muted-foreground/70">
                    Última sincronização
                  </p>
                  <p className="mt-0.5 text-sm font-semibold text-foreground">
                    {config.ultimaSincronizacao
                      ? new Date(config.ultimaSincronizacao).toLocaleString("pt-BR")
                      : "Ainda não registrada"}
                  </p>
                </div>
              </div>

              <div className="grid gap-2 sm:grid-cols-3">
                <button
                  onClick={handleTest}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-border/80 bg-secondary px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:bg-accent"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${testing ? "animate-spin" : ""}`} />
                  {testing ? "Testando..." : "Testar conexão"}
                </button>

                <button
                  onClick={handleSync}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-border/80 bg-secondary px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:bg-accent"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${syncing ? "animate-spin" : ""}`} />
                  {syncing ? "Sincronizando..." : "Atualizar agora"}
                </button>

                <button
                  onClick={() => rodarDiagnosticoPlacarApi(config.fonteUrl)}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-border/80 bg-secondary px-3 py-2 text-xs font-semibold text-foreground transition-colors hover:bg-accent"
                >
                  Testar API do Placar
                </button>
              </div>
            </SectionCard>

            <SectionCard
              eyebrow="Interface"
              title="Aparência e navegação"
              description="Leitura mais densa e uso máximo da área útil."
              icon={MonitorCog}
            >
              <Field label="Tema visual da implementação">
                <div className="rounded-2xl border border-border bg-secondary/45 px-3 py-2.5">
                  <p className="text-sm font-semibold text-foreground">Escuro fixo</p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">
                    Identidade dark fixa nesta implementação.
                  </p>
                </div>
              </Field>

              <Field label={`Zoom da interface (${config.zoomLevel ?? 100}%)`}>
                <div className="rounded-2xl border border-border bg-secondary/55 px-3 py-2.5">
                  <div className="mb-2 flex items-center justify-between text-[11px] text-muted-foreground">
                    <span>70%</span>
                    <span>100%</span>
                    <span>130%</span>
                  </div>
                  <Slider
                    value={[config.zoomLevel ?? 100]}
                    min={70}
                    max={130}
                    step={5}
                    onValueChange={([value]) =>
                      setConfig((previous) => ({
                        ...previous,
                        zoomLevel: value,
                      }))
                    }
                  />
                </div>
              </Field>

              <label className="flex items-start gap-3 rounded-2xl border border-border bg-secondary/40 px-3 py-2.5">
                <input
                  type="checkbox"
                  checked={Boolean(config.sidebarCollapsed)}
                  onChange={(event) =>
                    setConfig((previous) => ({
                      ...previous,
                      sidebarCollapsed: event.target.checked,
                    }))
                  }
                  className="mt-1 h-4 w-4 rounded border-border text-primary focus:ring-primary/40"
                />
                <div>
                  <p className="flex items-center gap-2 text-sm font-semibold text-foreground">
                    <LayoutPanelLeft className="h-4 w-4 text-primary" />
                    Iniciar com barra lateral recolhida
                  </p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">
                    Abre mais área útil em telas menores.
                  </p>
                </div>
              </label>
            </SectionCard>
          </section>

          <section className="flex min-h-0 flex-col gap-2.5">
            <SectionCard
              eyebrow="Ambiente"
              title="Contexto e alerta"
              description="Dados locais usados pelo aplicativo."
              icon={CheckCircle2}
            >
              <div className="grid gap-2 sm:grid-cols-2">
                <Field label="Nome do ambiente">
                  <input
                    value={config.nomeAmbiente || ""}
                    onChange={(event) =>
                      setConfig((previous) => ({
                        ...previous,
                        nomeAmbiente: event.target.value,
                      }))
                    }
                    className="field-input w-full px-3 py-2 text-sm"
                  />
                </Field>

                <Field label="E-mail de alerta">
                  <input
                    type="email"
                    value={config.emailAlerta || ""}
                    onChange={(event) =>
                      setConfig((previous) => ({
                        ...previous,
                        emailAlerta: event.target.value,
                      }))
                    }
                    className="field-input w-full px-3 py-2 text-sm"
                  />
                </Field>
              </div>
            </SectionCard>

            <SectionCard
              eyebrow="Resumo"
              title="Resumo atual"
              description="Leitura rápida das preferências em uso."
              icon={ZoomIn}
            >
              <div className="grid gap-2 sm:grid-cols-2">
                <SummaryTile label="Modo atual" value={getConnectionLabel(data.sourceStatus)} />
                <SummaryTile label="Zoom" value={`${config.zoomLevel ?? 100}%`} />
                <SummaryTile
                  label="Sidebar"
                  value={config.sidebarCollapsed ? "Recolhida" : "Expandida"}
                />
                <SummaryTile
                  label="Perfis de dev"
                  value={String(config.devProfiles?.length ?? 0)}
                />
              </div>
            </SectionCard>
          </section>

          <SectionCard
            eyebrow="Diagnóstico"
            title="Debug da sincronização"
            description="Comparação rápida entre origem, adaptador e estado final."
            icon={RefreshCw}
            className="h-full min-h-0"
          >
            <div className="grid gap-2 sm:grid-cols-2">
              <SummaryRow label="Cache" value={data.debug.cache.message} />
              <SummaryRow
                label="Cache atualizado"
                value={
                  data.debug.cache.updatedAt
                    ? new Date(data.debug.cache.updatedAt).toLocaleString("pt-BR")
                    : "-"
                }
              />
            </div>

            <div className="flex min-h-0 flex-col gap-2">
              <div className="grid gap-2">
                <DebugBlock title="Resposta bruta da API" payload={data.debug.rawApiPayload} />
                <DebugBlock title="Resultado do adaptador" payload={data.debug.adaptedPayload} />
                <DebugBlock title="Estado final renderizado" payload={renderedPayload} />
              </div>
            </div>
          </SectionCard>
        </div>
      </div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div>
      <label className="mb-1 block text-[11px] uppercase tracking-[0.22em] text-muted-foreground/80">
        {label}
      </label>
      {children}
    </div>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-2xl border border-border/80 bg-background/35 px-3 py-2 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className="min-w-0 text-right font-semibold text-foreground">{value}</span>
    </div>
  );
}

function DebugBlock({
  title,
  payload,
}: {
  title: string;
  payload: unknown;
}) {
  return (
    <details className="rounded-2xl border border-border/80 bg-secondary/35 px-3 py-2">
      <summary className="cursor-pointer text-sm font-medium text-foreground">
        {title}
      </summary>
      <pre className="mt-2 max-h-40 overflow-auto rounded-xl bg-background/70 p-2 text-[11px] leading-relaxed text-muted-foreground scrollbar-thin">
        {formatDebugJson(payload)}
      </pre>
    </details>
  );
}

function formatDebugJson(payload: unknown) {
  if (payload === null || payload === undefined) {
    return "Sem dados capturados nesta etapa.";
  }

  return JSON.stringify(payload, null, 2);
}

function showConnectionToast(result: SourceConnectionResult) {
  if (result.ok) {
    toast({
      title: "Conexão OK",
      description: `A API respondeu com status ${result.status}.`,
    });
    return;
  }

  toast({
    title: "Falha na conexão",
    description:
      result.error ||
      `Não foi possível acessar a API${result.status ? ` (status ${result.status})` : ""}.`,
    variant: "destructive",
  });
}
