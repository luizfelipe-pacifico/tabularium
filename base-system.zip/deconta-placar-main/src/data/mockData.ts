export interface Demanda {
  id: string;
  data: string;
  categoria: "Bug critico" | "Bug leve" | "Melhoria" | "Sugestao";
  grau: "Critica" | "Alta" | "Media" | "Baixa";
  area: string;
  status: "Em aberto" | "Em andamento" | "Concluida" | "Recusada";
  operador: string;
  descricao: string;
  cliente?: string;
}

export const demandas: Demanda[] = [
  { id: "DC-1042", data: "2026-03-12", categoria: "Bug critico", grau: "Critica", area: "Contratos", status: "Em aberto", operador: "Luiz", descricao: "Erro ao gerar PDF de contrato com clausulas especiais", cliente: "Escritorio Silva & Associados" },
  { id: "DC-1041", data: "2026-03-12", categoria: "Bug leve", grau: "Media", area: "Financeiro", status: "Em andamento", operador: "Will", descricao: "Valor total nao atualiza ao remover item da fatura", cliente: "Contab Express" },
  { id: "DC-1040", data: "2026-03-11", categoria: "Melhoria", grau: "Alta", area: "Dashboard", status: "Em aberto", operador: "Nao atribuida", descricao: "Adicionar filtro por periodo no relatorio de receitas" },
  { id: "DC-1039", data: "2026-03-11", categoria: "Bug leve", grau: "Baixa", area: "Cadastros", status: "Em andamento", operador: "Luiz", descricao: "Campo CNPJ nao valida digito verificador corretamente", cliente: "PME Gestao" },
  { id: "DC-1038", data: "2026-03-11", categoria: "Sugestao", grau: "Baixa", area: "Relatorios", status: "Em aberto", operador: "Nao atribuida", descricao: "Permitir exportacao em formato ODS alem de XLSX" },
  { id: "DC-1037", data: "2026-03-10", categoria: "Bug critico", grau: "Critica", area: "Autenticacao", status: "Em andamento", operador: "Will", descricao: "Sessao expira prematuramente em algumas contas", cliente: "Grupo Omega" },
  { id: "DC-1036", data: "2026-03-10", categoria: "Melhoria", grau: "Alta", area: "Contratos", status: "Em aberto", operador: "Luiz", descricao: "Implementar assinatura digital integrada" },
  { id: "DC-1035", data: "2026-03-10", categoria: "Bug leve", grau: "Media", area: "Financeiro", status: "Concluida", operador: "Will", descricao: "Arredondamento incorreto em calculos tributarios" },
  { id: "DC-1034", data: "2026-03-09", categoria: "Melhoria", grau: "Media", area: "Cadastros", status: "Concluida", operador: "Luiz", descricao: "Adicionar busca avancada por multiplos campos" },
  { id: "DC-1033", data: "2026-03-09", categoria: "Bug leve", grau: "Baixa", area: "Dashboard", status: "Concluida", operador: "Will", descricao: "Grafico de barras nao renderiza no Safari" },
  { id: "DC-1032", data: "2026-03-08", categoria: "Sugestao", grau: "Baixa", area: "Relatorios", status: "Recusada", operador: "Luiz", descricao: "Criar relatorio de inadimplencia automatico" },
  { id: "DC-1031", data: "2026-03-08", categoria: "Bug critico", grau: "Alta", area: "Contratos", status: "Concluida", operador: "Will", descricao: "Duplicacao de contrato ao clicar multiplas vezes", cliente: "JR Contabilidade" },
  { id: "DC-1030", data: "2026-03-07", categoria: "Melhoria", grau: "Media", area: "Financeiro", status: "Recusada", operador: "Luiz", descricao: "Integrar com gateway de pagamento PIX" },
  { id: "DC-1029", data: "2026-03-07", categoria: "Bug leve", grau: "Baixa", area: "Cadastros", status: "Concluida", operador: "Will", descricao: "Layout quebrado na tela de edicao em resolucao 1366px" },
  { id: "DC-1028", data: "2026-03-06", categoria: "Sugestao", grau: "Baixa", area: "Dashboard", status: "Concluida", operador: "Luiz", descricao: "Adicionar widget de tarefas pendentes na home" },
];

export const operadores = [
  { nome: "Luiz", avatar: "L", email: "luiz@deconta.com.br", cargo: "Desenvolvedor Senior" },
  { nome: "Will", avatar: "W", email: "will@deconta.com.br", cargo: "Desenvolvedor Pleno" },
];

export const areas = ["Contratos", "Financeiro", "Dashboard", "Cadastros", "Relatorios", "Autenticacao"];

export function getStats() {
  const emAberto = demandas.filter((d) => d.status === "Em aberto");
  const emAndamento = demandas.filter((d) => d.status === "Em andamento");
  const concluidas = demandas.filter((d) => d.status === "Concluida");
  const recusadas = demandas.filter((d) => d.status === "Recusada");
  const ativas = [...emAberto, ...emAndamento];
  const historico = [...concluidas, ...recusadas];

  return {
    totalDemandas: demandas.length,
    totalAtivas: ativas.length,
    totalHistorico: historico.length,
    emAberto: emAberto.length,
    emAndamento: emAndamento.length,
    concluidas: concluidas.length,
    recusadas: recusadas.length,
    porGrau: {
      Critica: ativas.filter((d) => d.grau === "Critica").length,
      Alta: ativas.filter((d) => d.grau === "Alta").length,
      Media: ativas.filter((d) => d.grau === "Media").length,
      Baixa: ativas.filter((d) => d.grau === "Baixa").length,
    },
    porCategoria: {
      "Bug critico": ativas.filter((d) => d.categoria === "Bug critico").length,
      "Bug leve": ativas.filter((d) => d.categoria === "Bug leve").length,
      Melhoria: ativas.filter((d) => d.categoria === "Melhoria").length,
      Sugestao: ativas.filter((d) => d.categoria === "Sugestao").length,
    },
    porOperador: {
      "Nao atribuida": ativas.filter((d) => d.operador === "Nao atribuida").length,
      Luiz: ativas.filter((d) => d.operador === "Luiz").length,
      Will: ativas.filter((d) => d.operador === "Will").length,
    },
  };
}
