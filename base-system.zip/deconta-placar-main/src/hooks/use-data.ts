import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  createEmptyAppData,
  pickNewestAppData,
  type AppData,
} from "@/lib/app-data";
import { fetchData } from "@/services/dataService";

const QUERY_KEY = ["sheetData"];

export function useRemoteData() {
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: QUERY_KEY,
    queryFn: async () => {
      const incoming = await fetchData();
      const current = queryClient.getQueryData<AppData>(QUERY_KEY);

      return pickNewestAppData(current, incoming);
    },
    retry: 1,
    refetchOnWindowFocus: false,
    initialData: createEmptyAppData({
      sourceStatus: {
        mode: "fallback",
        message: "Aguardando a primeira sincronização.",
        error: null,
      },
    }),
  });

  useEffect(() => {
    if (!window.electronAPI?.onDataUpdate) {
      return;
    }

    const handler = (_event: unknown, data: AppData) => {
      queryClient.setQueryData(QUERY_KEY, (current?: AppData) =>
        pickNewestAppData(current, data),
      );
    };

    window.electronAPI.onDataUpdate(handler);
    return () => {
      window.electronAPI?.offDataUpdate?.(handler);
    };
  }, [queryClient]);

  return query;
}
