import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import type { AppConfig } from "@/lib/app-data";
import { normalizeDevProfiles } from "@/lib/dev-profiles";
import {
  DEFAULT_SOURCE_URL,
  loadConfig,
  saveConfig,
} from "@/services/configService";

const DEFAULT_CONFIG: AppConfig = {
  fonteUrl: DEFAULT_SOURCE_URL,
  intervalo: 5,
  emailAlerta: "",
  nomeAmbiente: "",
  tema: "dark",
  ultimaSincronizacao: null,
  zoomLevel: 100,
  sidebarCollapsed: false,
  devProfiles: [],
};

interface AppPreferencesContextValue {
  config: AppConfig;
  isReady: boolean;
  savePreferences: (nextConfig: Partial<AppConfig>) => Promise<AppConfig>;
}

const AppPreferencesContext = createContext<AppPreferencesContextValue | null>(null);

function normalizeConfig(config: AppConfig): AppConfig {
  return {
    ...DEFAULT_CONFIG,
    ...config,
    fonteUrl:
      typeof config.fonteUrl === "string" && config.fonteUrl.trim().length > 0
        ? config.fonteUrl.trim()
        : DEFAULT_CONFIG.fonteUrl,
    zoomLevel:
      typeof config.zoomLevel === "number" &&
      config.zoomLevel >= 70 &&
      config.zoomLevel <= 130
        ? Math.round(config.zoomLevel)
        : 100,
    sidebarCollapsed: Boolean(config.sidebarCollapsed),
    tema: "dark",
    devProfiles: normalizeDevProfiles(config.devProfiles),
  };
}

export function AppPreferencesProvider({ children }: { children: ReactNode }) {
  const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let cancelled = false;

    loadConfig()
      .then((loadedConfig) => {
        if (!cancelled) {
          setConfig(normalizeConfig(loadedConfig));
          setIsReady(true);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setConfig(DEFAULT_CONFIG);
          setIsReady(true);
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    document.documentElement.classList.remove("light");
    document.documentElement.dataset.theme = "dark";
  }, []);

  useEffect(() => {
    const zoom = Math.max(70, Math.min(130, config.zoomLevel ?? 100));
    document.body.style.zoom = `${zoom}%`;

    return () => {
      document.body.style.zoom = "100%";
    };
  }, [config.zoomLevel]);

  const savePreferences = async (nextConfig: Partial<AppConfig>) => {
    const savedConfig = normalizeConfig(
      await saveConfig({
        ...nextConfig,
        tema: "dark",
      }),
    );
    setConfig(savedConfig);
    return savedConfig;
  };

  const value = {
    config,
    isReady,
    savePreferences,
  };

  return (
    <AppPreferencesContext.Provider value={value}>
      {children}
    </AppPreferencesContext.Provider>
  );
}

export function useAppPreferences() {
  const context = useContext(AppPreferencesContext);

  if (!context) {
    throw new Error("useAppPreferences must be used within AppPreferencesProvider");
  }

  return context;
}
