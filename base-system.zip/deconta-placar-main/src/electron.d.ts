import type { AppConfig, AppData } from "@/lib/app-data";

interface SourceConnectionResult {
  ok: boolean;
  status: number | null;
  error?: string | null;
}

interface SaveReportDocumentResult {
  canceled: boolean;
  filePath: string | null;
}

interface SaveReportPdfOptions {
  landscape?: boolean;
  pageSize?: "A4" | { width: number; height: number };
  preferCSSPageSize?: boolean;
}

interface SaveReportCaptureOptions {
  width: number;
  height: number;
}

type SaveReportOutputFormat = "pdf" | "pptx" | "jpeg";

declare global {
  interface Window {
    electronAPI?: {
      getConfig: () => Promise<AppConfig>;
      setConfig: (config: Partial<AppConfig>) => Promise<AppConfig>;
      testSourceUrl: (url?: string) => Promise<SourceConnectionResult>;
      fetchData: () => Promise<AppData>;
      syncNow: () => Promise<AppData>;
      saveReportDocument: (payload: {
        html: string;
        fileName?: string;
        outputFormat?: SaveReportOutputFormat;
        pdfOptions?: SaveReportPdfOptions;
        captureOptions?: SaveReportCaptureOptions;
      }) => Promise<SaveReportDocumentResult>;
      reloadApp: () => Promise<void>;
      minimizeWindow: () => Promise<void>;
      toggleMaximizeWindow: () => Promise<void>;
      onDataUpdate: (callback: (event: unknown, data: AppData) => void) => void;
      offDataUpdate: (callback: (event: unknown, data: AppData) => void) => void;
      quit: () => Promise<void>;
    };
  }
}

export {};
