import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import {
  HashRouter as Router,
  Route,
  Routes,
  useLocation,
  useNavigate,
} from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppLayout } from "@/components/layout/AppLayout";
import { AppPreferencesProvider } from "@/contexts/app-preferences";
import {
  LAST_ROUTE_STORAGE_KEY,
  getStoredLaunchRoute,
  normalizeRoutePath,
} from "@/lib/route-memory";
import DashboardPage from "./pages/DashboardPage";
import DemandasPage from "./pages/DemandasPage";
import KanbanDevPage from "./pages/KanbanDevPage";
import HistoricoPage from "./pages/HistoricoPage";
import RoadmapBoardPage from "./pages/RoadmapBoardPage";
import RoadmapPage from "./pages/RoadmapPage";
import SuportePage from "./pages/SuportePage";
import NotasPage from "./pages/NotasPage";
import IntegracoesPage from "./pages/IntegracoesPage";
import ManualPage from "./pages/ManualPage";
import OperadoresPage from "./pages/OperadoresPage";
import RelatoriosPage from "./pages/RelatoriosPage";
import ConfiguracoesPage from "./pages/ConfiguracoesPage";
import PerfilPage from "./pages/PerfilPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function RoutePersistence() {
  const location = useLocation();
  const navigate = useNavigate();
  const restoredRef = useRef(false);

  useEffect(() => {
    if (restoredRef.current || typeof window === "undefined") {
      return;
    }

    restoredRef.current = true;
    const storedRoute = getStoredLaunchRoute(
      location.pathname,
      window.localStorage.getItem(LAST_ROUTE_STORAGE_KEY),
    );

    if (storedRoute) {
      navigate(storedRoute, { replace: true });
    }
  }, [location.pathname, navigate]);

  useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }

    const normalizedPath = normalizeRoutePath(location.pathname);
    if (normalizedPath) {
      window.localStorage.setItem(LAST_ROUTE_STORAGE_KEY, normalizedPath);
    }
  }, [location.pathname]);

  return null;
}

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AppPreferencesProvider>
        <TooltipProvider>
          <Toaster />
          <Router>
            <RoutePersistence />
            <AppLayout>
              <Routes>
                <Route path="/" element={<DashboardPage />} />
                <Route path="/demandas" element={<DemandasPage />} />
                <Route path="/kanban-dev" element={<KanbanDevPage />} />
                <Route path="/suporte" element={<SuportePage />} />
                <Route path="/roadmap" element={<RoadmapPage />} />
                <Route path="/roadmap-board" element={<RoadmapBoardPage />} />
                <Route path="/notas" element={<NotasPage />} />
                <Route path="/integracoes" element={<IntegracoesPage />} />
                <Route path="/manual" element={<ManualPage />} />
                <Route path="/historico" element={<HistoricoPage mode="historico" title="Histórico" />} />
                <Route path="/relatorios" element={<RelatoriosPage />} />
                <Route path="/operadores" element={<OperadoresPage />} />
                <Route path="/configuracoes" element={<ConfiguracoesPage />} />
                <Route path="/perfil" element={<PerfilPage />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </AppLayout>
          </Router>
        </TooltipProvider>
      </AppPreferencesProvider>
    </QueryClientProvider>
  );
};

export default App;
