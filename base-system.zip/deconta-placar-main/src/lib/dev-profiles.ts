import type {
  AppConfig,
  DevProfile,
  NormalizedDemanda,
  OperatorSummary,
} from "@/lib/app-data";

const DEFAULT_CARGO = "Desenvolvedor";

function normalizeIdentity(value: string | undefined | null): string {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

export function getAvatarLabel(name: string): string {
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");

  return initials || "DV";
}

export function normalizeDevProfiles(profiles: AppConfig["devProfiles"]): DevProfile[] {
  if (!Array.isArray(profiles)) {
    return [];
  }

  const seen = new Set<string>();

  return profiles
    .map<DevProfile | null>((profile) => {
      if (!profile) {
        return null;
      }

      const nome = String(profile.nome ?? "").trim();
      const email = String(profile.email ?? "").trim();

      if (!nome) {
        return null;
      }

      const dedupeKey = normalizeIdentity(email || nome);
      if (dedupeKey && seen.has(dedupeKey)) {
        return null;
      }

      if (dedupeKey) {
        seen.add(dedupeKey);
      }

      return {
        nome,
        email,
        fotoUrl: String(profile.fotoUrl ?? "").trim(),
        cargo: String(profile.cargo ?? DEFAULT_CARGO).trim() || DEFAULT_CARGO,
      };
    })
    .filter((profile): profile is DevProfile => Boolean(profile));
}

function isProfileMatch(profile: DevProfile, operator: OperatorSummary): boolean {
  const profileName = normalizeIdentity(profile.nome);
  const profileEmail = normalizeIdentity(profile.email);
  const operatorName = normalizeIdentity(operator.nome);
  const operatorEmail = normalizeIdentity(operator.email);

  if (profileEmail && operatorEmail) {
    return profileEmail === operatorEmail;
  }

  return profileName.length > 0 && profileName === operatorName;
}

export function mergeOperatorSummaries(
  operators: OperatorSummary[],
  profiles: AppConfig["devProfiles"],
): OperatorSummary[] {
  const normalizedProfiles = normalizeDevProfiles(profiles);
  const usedProfiles = new Set<string>();

  const mergedOperators = operators.map((operator) => {
    const matchedProfile = normalizedProfiles.find((profile) =>
      isProfileMatch(profile, operator),
    );

    if (matchedProfile) {
      usedProfiles.add(normalizeIdentity(matchedProfile.email || matchedProfile.nome));
    }

    const nome = matchedProfile?.nome || operator.nome;

    return {
      ...operator,
      nome,
      email: matchedProfile?.email || operator.email,
      cargo: matchedProfile?.cargo || operator.cargo || DEFAULT_CARGO,
      fotoUrl: matchedProfile?.fotoUrl || operator.fotoUrl || "",
      avatar: getAvatarLabel(nome),
    };
  });

  const emptyProfiles = normalizedProfiles
    .filter((profile) => {
      const key = normalizeIdentity(profile.email || profile.nome);
      return key ? !usedProfiles.has(key) : true;
    })
    .map<OperatorSummary>((profile) => ({
      nome: profile.nome,
      avatar: getAvatarLabel(profile.nome),
      email: profile.email,
      fotoUrl: profile.fotoUrl || "",
      cargo: profile.cargo || DEFAULT_CARGO,
      total: 0,
      abertas: 0,
      andamento: 0,
      concluidas: 0,
      recusadas: 0,
      ativas: 0,
    }));

  return [...mergedOperators, ...emptyProfiles].sort((left, right) => {
    if (right.total !== left.total) {
      return right.total - left.total;
    }

    return left.nome.localeCompare(right.nome, "pt-BR");
  });
}

export function countAssignedDemandas(
  demandas: NormalizedDemanda[],
  profile: DevProfile,
): number {
  const profileName = normalizeIdentity(profile.nome);
  const profileEmail = normalizeIdentity(profile.email);

  return demandas.filter((demanda) => {
    const operatorName = normalizeIdentity(demanda.operador);
    return operatorName === profileName || (profileEmail && operatorName === profileEmail);
  }).length;
}
