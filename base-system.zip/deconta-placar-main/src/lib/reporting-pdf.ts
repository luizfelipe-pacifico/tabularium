import {
  formatPercent,
  type ExecutiveHighlight,
  type LocationPerformanceRow,
  type OperatorPerformanceRow,
  type PerformanceReport,
  type ReportBreakdownRow,
  type ReportFilters,
  type ReportPeriodSummary,
  type ReportPressureRow,
  type ReportTone,
  type ReportTrendPoint,
} from "@/lib/reporting";

export type ReportDocumentMode = "report" | "presentation";
export type PresentationDownloadFormat = "pptx" | "jpeg";
export type ReportDownloadFormat = "pdf" | PresentationDownloadFormat;

interface ReportPdfDocumentOptions {
  report: PerformanceReport;
  sourceMessage: string;
  generatedAt: string;
  operatorScopeLabel: string;
  mode?: ReportDocumentMode;
}

interface ReportDocumentSpec {
  filePrefix: string;
  pageTitle: string;
  headerTitle: string;
  headerSubtitle: string;
  cssPageSize: string;
  pageWidth: string;
  pageHeight: string;
  pdfPageSize: "A4" | { width: number; height: number };
  captureSize?: { width: number; height: number };
  landscape: boolean;
  preferCssPageSize: boolean;
  outerPadding: string;
  bodyColumns: string;
  baseFontSize: string;
  titleFontSize: string;
  subtitleFontSize: string;
  metricValueSize: string;
  sectionTitleSize: string;
  metaValueSize: string;
  gap: string;
}

export interface ReportDownloadRequest {
  fileName: string;
  outputFormat: ReportDownloadFormat;
  pdfOptions?: {
    landscape: boolean;
    pageSize: "A4" | { width: number; height: number };
    preferCSSPageSize: boolean;
  };
  captureOptions?: {
    width: number;
    height: number;
  };
}

const PRESENTATION_PAGE_SIZE = {
  width: 338667,
  height: 190500,
};

const DONUT_COLORS = ["#16c784", "#38bdf8", "#f59e0b", "#fb4b79", "#a78bfa", "#94a3b8"];

const DOCUMENT_SPECS: Record<ReportDocumentMode, ReportDocumentSpec> = {
  report: {
    filePrefix: "relatorio-performance",
    pageTitle: "Relatorio de performance",
    headerTitle: "PLACAR DECONTA - RELATORIO DE PERFORMANCE",
    headerSubtitle: "Leitura executiva do periodo selecionado",
    cssPageSize: "210mm 297mm",
    pageWidth: "210mm",
    pageHeight: "296.4mm",
    pdfPageSize: "A4",
    landscape: false,
    preferCssPageSize: true,
    outerPadding: "8mm 8mm 7mm",
    bodyColumns: "minmax(0, 1.18fr) minmax(0, 0.82fr)",
    baseFontSize: "9px",
    titleFontSize: "16px",
    subtitleFontSize: "9px",
    metricValueSize: "21px",
    sectionTitleSize: "11px",
    metaValueSize: "9px",
    gap: "8px",
  },
  presentation: {
    filePrefix: "apresentacao-performance",
    pageTitle: "Apresentacao executiva",
    headerTitle: "PLACAR DECONTA - APRESENTACAO EXECUTIVA",
    headerSubtitle: "Painel visual do periodo selecionado",
    cssPageSize: "1920px 1080px",
    pageWidth: "1920px",
    pageHeight: "1080px",
    pdfPageSize: PRESENTATION_PAGE_SIZE,
    captureSize: { width: 1920, height: 1080 },
    landscape: true,
    preferCssPageSize: false,
    outerPadding: "32px 38px 28px",
    bodyColumns: "minmax(0, 1.22fr) minmax(0, 0.78fr)",
    baseFontSize: "12px",
    titleFontSize: "28px",
    subtitleFontSize: "12px",
    metricValueSize: "34px",
    sectionTitleSize: "15px",
    metaValueSize: "12px",
    gap: "14px",
  },
};

export function getReportPdfRequest(
  filters: ReportFilters,
  mode: ReportDocumentMode = "report",
): ReportDownloadRequest {
  const spec = DOCUMENT_SPECS[mode];

  return {
    fileName: buildFileName(spec.filePrefix, filters, "pdf"),
    outputFormat: "pdf",
    pdfOptions: {
      landscape: spec.landscape,
      pageSize: spec.pdfPageSize,
      preferCSSPageSize: spec.preferCssPageSize,
    },
    captureOptions: spec.captureSize,
  };
}

export function getReportDownloadRequest(
  filters: ReportFilters,
  mode: ReportDocumentMode = "report",
  presentationFormat: PresentationDownloadFormat = "pptx",
): ReportDownloadRequest {
  if (mode === "report") {
    return getReportPdfRequest(filters, mode);
  }

  const spec = DOCUMENT_SPECS[mode];
  return {
    fileName: buildFileName(spec.filePrefix, filters, presentationFormat),
    outputFormat: presentationFormat,
    captureOptions: spec.captureSize,
  };
}

export function buildPerformanceReportHtml({
  report,
  sourceMessage: _sourceMessage,
  generatedAt,
  operatorScopeLabel,
  mode = "report",
}: ReportPdfDocumentOptions): string {
  const spec = DOCUMENT_SPECS[mode];
  const highlights = normalizeHighlights(report.highlights);

  return `<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8" />
    <title>${escapeHtml(spec.pageTitle)}</title>
    <style>${buildStyles(spec)}</style>
  </head>
  <body>
    <div class="page">
      <section class="topbar">
        <div>
          <p class="eyebrow">Placar DeConta</p>
          <h1 class="page-title">${escapeHtml(spec.headerTitle)}</h1>
          <p class="page-subtitle">${escapeHtml(spec.headerSubtitle)}</p>
        </div>
        <div class="meta-box">
          ${renderMetaRow("Periodo", report.currentLabel)}
          ${renderMetaRow("Comparativo", report.previousLabel)}
          ${renderMetaRow("Operadores", shortenText(operatorScopeLabel || "Todos os operadores", 32))}
          ${renderMetaRow("Gerado em", formatGeneratedAt(generatedAt))}
        </div>
      </section>
      <section class="kpi-grid">
        ${report.kpis.map((kpi) => renderKpiCard(kpi)).join("")}
      </section>
      <section class="body-grid">
        <div class="main-stack">
          ${renderPressurePanel(report.pressureRows, report.current)}
          <div class="mix-grid">
            ${renderDonutPanel("Status", report.statusRows)}
            ${renderDonutPanel("Prioridade", report.priorityRows)}
            ${renderBarPanel("Categoria", report.categoryRows, "Mix")}
          </div>
        </div>
        <div class="side-stack">
          ${renderHotspotPanel(report.hotspotRows.slice(0, 5))}
          ${renderOperatorPanel(report.operatorRows.slice(0, 5))}
        </div>
      </section>
      <section class="footer-grid">
        ${highlights.map((highlight) => renderHighlightCard(highlight)).join("")}
      </section>
    </div>
  </body>
</html>`;
}

function buildFileName(prefix: string, filters: ReportFilters, extension: string) {
  return `${prefix}-${filters.startDate}-a-${filters.endDate}.${extension}`;
}

function buildStyles(spec: ReportDocumentSpec) {
  return `@page{size:${spec.cssPageSize};margin:0}
:root{color-scheme:dark;--page-width:${spec.pageWidth};--page-height:${spec.pageHeight};--page-padding:${spec.outerPadding};--page-gap:${spec.gap};--body-columns:${spec.bodyColumns};--font-base:${spec.baseFontSize};--title-size:${spec.titleFontSize};--subtitle-size:${spec.subtitleFontSize};--metric-size:${spec.metricValueSize};--section-size:${spec.sectionTitleSize};--meta-size:${spec.metaValueSize};--bg:#050d18;--panel:rgba(11,23,40,.98);--panel-soft:rgba(14,28,49,.98);--border:rgba(120,144,173,.16);--border-strong:rgba(22,199,132,.18);--text:#eff5fb;--muted:#90a4bf;--shadow:0 20px 50px rgba(0,0,0,.28)}
*{box-sizing:border-box}html,body{margin:0;width:var(--page-width);height:var(--page-height);overflow:hidden;background:var(--bg);color:var(--text);font-family:"Segoe UI",Tahoma,Geneva,Verdana,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{background:radial-gradient(circle at top right,rgba(22,199,132,.12),transparent 26%),radial-gradient(circle at bottom left,rgba(56,189,248,.08),transparent 20%),linear-gradient(180deg,#07111d 0%,#050d18 100%)}.page{width:var(--page-width);height:var(--page-height);overflow:hidden;padding:var(--page-padding);display:grid;grid-template-rows:auto auto minmax(0,1fr) auto;gap:var(--page-gap);background:radial-gradient(circle at top right,rgba(22,199,132,.1),transparent 28%),radial-gradient(circle at bottom left,rgba(56,189,248,.07),transparent 20%),linear-gradient(180deg,#07111d 0%,#050d18 100%);break-inside:avoid;page-break-inside:avoid;break-after:avoid-page;page-break-after:avoid}.topbar{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:start;padding:9px 11px;border-radius:18px;border:1px solid var(--border-strong);background:linear-gradient(180deg,rgba(12,23,41,.95),rgba(8,16,29,.95));box-shadow:var(--shadow)}.eyebrow{margin:0 0 5px;color:#7de1b4;font-size:8px;font-weight:700;letter-spacing:.28em;text-transform:uppercase}.page-title{margin:0;font-size:var(--title-size);line-height:1.04;letter-spacing:-.02em}.page-subtitle{margin:4px 0 0;color:var(--muted);font-size:var(--subtitle-size)}.meta-box{min-width:240px;padding:8px 10px;border-radius:14px;border:1px solid var(--border);background:rgba(255,255,255,.03);display:grid;gap:5px}.meta-row{display:grid;grid-template-columns:76px minmax(0,1fr);gap:8px}.meta-label{color:var(--muted);font-size:8px;font-weight:700;letter-spacing:.12em;text-transform:uppercase}.meta-value{min-width:0;font-size:var(--meta-size);font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.kpi-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:var(--page-gap)}.kpi-card,.panel-card,.highlight-card{border:1px solid var(--border);border-radius:18px;background:linear-gradient(180deg,var(--panel-soft),var(--panel));box-shadow:var(--shadow)}.kpi-card{padding:10px 11px;display:grid;gap:6px}.kpi-top{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.kpi-label{color:var(--muted);font-size:8px;font-weight:700;letter-spacing:.14em;text-transform:uppercase}.kpi-delta{display:inline-flex;align-items:center;justify-content:center;min-width:58px;padding:3px 7px;border-radius:999px;border:1px solid transparent;font-size:8px;font-weight:700;white-space:nowrap}.tone-positive{color:#99efc8;border-color:rgba(34,197,94,.22);background:rgba(34,197,94,.11)}.tone-warning{color:#ffd281;border-color:rgba(245,158,11,.22);background:rgba(245,158,11,.11)}.tone-neutral{color:#b7c4d8;border-color:rgba(148,163,184,.18);background:rgba(148,163,184,.08)}.kpi-value{font-size:var(--metric-size);line-height:.94;font-weight:800;letter-spacing:-.04em}.kpi-detail{color:var(--muted);font-size:9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.body-grid{min-height:0;display:grid;grid-template-columns:var(--body-columns);gap:var(--page-gap)}.main-stack,.side-stack{min-height:0;display:grid;gap:var(--page-gap)}.main-stack{grid-template-rows:minmax(0,.98fr) minmax(0,1.04fr)}.mix-grid{min-height:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:var(--page-gap)}.category-panel{grid-column:1/-1}.side-stack{grid-template-rows:minmax(0,1fr) minmax(0,1fr)}.panel-card{min-height:0;padding:10px 11px;display:grid;grid-template-rows:auto minmax(0,1fr);gap:8px}.panel-head{display:flex;align-items:center;justify-content:space-between;gap:10px}.panel-title{font-size:var(--section-size);font-weight:700;line-height:1.1}.panel-tag{color:var(--muted);font-size:8px;font-weight:700;letter-spacing:.16em;text-transform:uppercase}.pressure-layout{min-height:0;display:grid;grid-template-columns:minmax(0,1fr) 108px;gap:10px}.pressure-table{display:grid;gap:6px;align-content:start}.pressure-head,.pressure-row{display:grid;grid-template-columns:84px repeat(4,minmax(0,1fr)) 38px;gap:6px;align-items:stretch}.pressure-head{align-items:end}.pressure-axis,.pressure-status,.pressure-total{display:flex;align-items:center;justify-content:center;border-radius:10px;font-size:8px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}.pressure-axis{min-height:22px;color:var(--muted);background:rgba(255,255,255,.03);border:1px solid rgba(148,163,184,.08)}.pressure-status{justify-content:flex-start;padding:0 8px;color:var(--text);background:rgba(255,255,255,.03);border:1px solid rgba(148,163,184,.08);text-transform:none;letter-spacing:0;font-size:8px}.pressure-total{color:var(--muted);background:rgba(255,255,255,.02);border:1px solid rgba(148,163,184,.08)}.pressure-cell{min-height:44px;border-radius:12px;border:1px solid rgba(148,163,184,.12);padding:4px;display:grid;align-content:center;justify-items:center;gap:2px;text-align:center}.pressure-cell-value{font-size:15px;font-weight:800;line-height:1}.pressure-cell-share{font-size:8px;color:#d8e2f0}.pressure-cell-empty{opacity:.42}.pressure-side{width:108px;display:grid;gap:6px;align-content:start}.stat-chip{padding:8px;border-radius:14px;border:1px solid rgba(148,163,184,.12);background:rgba(255,255,255,.03)}.stat-chip-label{display:block;color:var(--muted);font-size:7px;font-weight:700;letter-spacing:.14em;text-transform:uppercase}.stat-chip-value{display:block;margin-top:4px;font-size:16px;font-weight:800;line-height:1}.stat-chip-sub{display:block;margin-top:3px;color:var(--muted);font-size:8px}.donut-layout{min-height:0;display:grid;grid-template-columns:92px minmax(0,1fr);gap:10px;align-items:center}.donut-shell{position:relative;width:92px;height:92px;border-radius:999px;display:flex;align-items:center;justify-content:center;background:rgba(148,163,184,.12)}.donut-shell::after{content:"";width:56px;height:56px;border-radius:999px;background:#081223;box-shadow:inset 0 0 0 1px rgba(148,163,184,.08)}.donut-center{position:absolute;display:grid;justify-items:center;gap:2px;z-index:1}.donut-value{font-size:15px;font-weight:800;line-height:1}.donut-label{color:var(--muted);font-size:7px;font-weight:700;letter-spacing:.1em;text-transform:uppercase}.legend-list,.bar-list,.hotspot-list,.operator-list{display:grid;gap:7px;align-content:start}.legend-item,.bar-row,.hotspot-row,.operator-row{display:grid;align-items:center;gap:8px}.legend-item{grid-template-columns:auto minmax(0,1fr) auto}.legend-dot{width:8px;height:8px;border-radius:999px}.legend-label{min-width:0;font-size:9px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.legend-value{color:var(--muted);font-size:9px;font-variant-numeric:tabular-nums}.bar-row{grid-template-columns:minmax(0,82px) minmax(0,1fr) auto}.bar-label,.hotspot-label,.operator-name{min-width:0;font-size:9px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bar-track,.hotspot-track,.operator-track{height:10px;border-radius:999px;overflow:hidden;background:rgba(148,163,184,.12)}.bar-fill,.hotspot-fill,.stack-active,.stack-closed{height:100%;border-radius:999px}.bar-meta,.hotspot-meta{display:flex;gap:5px;align-items:center;justify-content:flex-end;min-width:58px;font-size:9px;font-variant-numeric:tabular-nums}.bar-share,.hotspot-share,.operator-sub{color:var(--muted)}.hotspot-row{grid-template-columns:18px minmax(0,1fr) minmax(0,96px) auto;padding:4px 0;border-bottom:1px solid rgba(148,163,184,.08)}.hotspot-row:last-child,.operator-row:last-child{border-bottom:none}.hotspot-rank{color:var(--muted);font-size:8px;font-weight:800;text-align:center}.hotspot-area{margin-top:2px;color:var(--muted);font-size:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.delta-positive{color:#22c55e}.delta-negative{color:#ef4444}.delta-neutral{color:var(--muted)}.operator-row{grid-template-columns:minmax(0,70px) minmax(0,1fr) auto;padding:5px 0;border-bottom:1px solid rgba(148,163,184,.08)}.operator-text{min-width:0}.operator-sub{margin-top:2px;font-size:8px}.operator-track{display:flex}.stack-active{background:linear-gradient(90deg,rgba(56,189,248,.88),rgba(14,165,233,.82))}.stack-closed{background:linear-gradient(90deg,rgba(22,199,132,.92),rgba(34,197,94,.82))}.operator-rate{min-width:48px;text-align:right;font-size:9px;font-weight:800;font-variant-numeric:tabular-nums}.footer-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:var(--page-gap)}.highlight-card{padding:8px 10px;display:grid;gap:4px}.highlight-title{color:var(--muted);font-size:8px;font-weight:700;letter-spacing:.16em;text-transform:uppercase}.highlight-text{font-size:10px;font-weight:700;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.empty{min-height:100%;display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:9px;border-radius:12px;border:1px dashed rgba(148,163,184,.22);background:rgba(255,255,255,.02)}`;
}

function renderMetaRow(label: string, value: string) {
  return `
    <div class="meta-row">
      <span class="meta-label">${escapeHtml(label)}</span>
      <span class="meta-value">${escapeHtml(value)}</span>
    </div>
  `;
}

function renderKpiCard(item: PerformanceReport["kpis"][number]) {
  return `
    <article class="kpi-card">
      <div class="kpi-top">
        <span class="kpi-label">${escapeHtml(item.title)}</span>
        <span class="kpi-delta ${getToneClass(item.tone)}">${escapeHtml(item.delta)}</span>
      </div>
      <div class="kpi-value">${escapeHtml(item.value)}</div>
      <div class="kpi-detail">${renderMultilineText(item.detail)}</div>
    </article>
  `;
}

function renderPressurePanel(rows: ReportPressureRow[], current: ReportPeriodSummary) {
  const flatCells = rows.flatMap((row) =>
    row.cells.map((cell) => ({
      status: row.status,
      priority: cell.priority,
      total: cell.total,
      share: cell.share,
    })),
  );

  const maxCellValue = Math.max(1, ...flatCells.map((cell) => cell.total));
  const topCell = flatCells.reduce(
    (best, cell) => (cell.total > best.total ? cell : best),
    flatCells[0] ?? { status: "-", priority: "-", total: 0, share: 0 },
  );
  const activeHighPriority = flatCells
    .filter(
      (cell) =>
        isActiveStatus(cell.status) &&
        (cell.priority === "Crítica" || cell.priority === "Alta"),
    )
    .reduce((sum, cell) => sum + cell.total, 0);
  const closedShare =
    current.totalDemandas > 0 ? (current.totalHistorico / current.totalDemandas) * 100 : 0;

  return `
    <article class="panel-card">
      <div class="panel-head">
        <div class="panel-title">Pressao operacional</div>
        <span class="panel-tag">Matriz</span>
      </div>
      ${
        flatCells.length > 0
          ? `
            <div class="pressure-layout">
              <div class="pressure-table">
                <div class="pressure-head">
                  <span class="pressure-axis">Status</span>
                  ${rows[0]?.cells
                    .map(
                      (cell) => `<span class="pressure-axis">${escapeHtml(shortenText(cell.priority, 7))}</span>`,
                    )
                    .join("")}
                  <span class="pressure-axis">Tot</span>
                </div>
                ${rows
                  .map(
                    (row) => `
                      <div class="pressure-row">
                        <span class="pressure-status">${escapeHtml(shortenText(row.status, 12))}</span>
                        ${row.cells
                          .map((cell) => {
                            const intensity = maxCellValue > 0 ? cell.total / maxCellValue : 0;
                            const cellStyle = getPressureCellStyle(row.status, cell.priority, intensity);

                            return `
                              <div class="pressure-cell ${cell.total === 0 ? "pressure-cell-empty" : ""}" style="${cellStyle}">
                                <span class="pressure-cell-value">${cell.total}</span>
                                <span class="pressure-cell-share">${escapeHtml(formatPercent(cell.share))}</span>
                              </div>
                            `;
                          })
                          .join("")}
                        <span class="pressure-total">${row.total}</span>
                      </div>
                    `,
                  )
                  .join("")}
              </div>
              <div class="pressure-side">
                ${renderStatChip(
                  "Maior bloco",
                  String(topCell.total),
                  `${shortenText(topCell.status, 10)} / ${shortenText(topCell.priority, 7)}`,
                )}
                ${renderStatChip(
                  "Crit-alta ativa",
                  String(activeHighPriority),
                  "em aberto e andamento",
                )}
                ${renderStatChip(
                  "Concl. / rec.",
                  `${current.concluidas}/${current.recusadas}`,
                  `${formatPercent(closedShare)} do periodo`,
                )}
                ${renderStatChip(
                  "Sem dono",
                  String(current.backlogSemResponsavel),
                  "ativas sem operador",
                )}
              </div>
            </div>
          `
          : `<div class="empty">Sem dados no periodo.</div>`
      }
    </article>
  `;
}

function renderTrendPanel(points: ReportTrendPoint[], totalDemandas: number) {
  if (points.length === 0) {
    return `
      <article class="panel-card">
        <div class="panel-head">
          <div class="panel-title">Ritmo</div>
          <span class="panel-tag">Linha</span>
        </div>
        <div class="empty">Sem historico no periodo selecionado.</div>
      </article>
    `;
  }

  const peak = Math.max(0, ...points.map((point) => point.total));
  const average = totalDemandas > 0 ? totalDemandas / Math.max(1, points.length) : 0;
  const topDay = points.reduce(
    (best, point) => (point.total > best.total ? point : best),
    points[0],
  );

  return `
    <article class="panel-card">
      <div class="panel-head">
        <div class="panel-title">Ritmo do periodo</div>
        <span class="panel-tag">Linha</span>
      </div>
      <div class="trend-layout">
        <div class="trend-chart">${renderTrendSvg(points)}</div>
        <div class="trend-side">
          ${renderStatChip("Pico", String(peak), topDay.label)}
          ${renderStatChip("Media", formatCompactNumber(average), "por dia")}
          ${renderStatChip(
            "Concl. / rec.",
            String(points.reduce((sum, point) => sum + point.encerradas, 0)),
            "no recorte",
          )}
        </div>
      </div>
    </article>
  `;
}

function renderTrendSvg(points: ReportTrendPoint[]) {
  const width = 520;
  const height = 190;
  const padding = { top: 12, right: 8, bottom: 22, left: 8 };
  const chartWidth = width - padding.left - padding.right;
  const chartHeight = height - padding.top - padding.bottom;
  const maxValue = Math.max(
    1,
    ...points.map((point) => Math.max(point.total, point.encerradas, point.ativas)),
  );
  const getX = (index: number) =>
    padding.left + (points.length <= 1 ? chartWidth / 2 : (chartWidth * index) / (points.length - 1));
  const getY = (value: number) => padding.top + chartHeight - (value / maxValue) * chartHeight;
  const totalPolyline = points.map((point, index) => `${getX(index)},${getY(point.total)}`).join(" ");
  const closedPolyline = points.map((point, index) => `${getX(index)},${getY(point.encerradas)}`).join(" ");
  const areaPath = [
    `M ${getX(0)} ${padding.top + chartHeight}`,
    ...points.map((point, index) => `L ${getX(index)} ${getY(point.total)}`),
    `L ${getX(points.length - 1)} ${padding.top + chartHeight}`,
    "Z",
  ].join(" ");

  return `
    <svg class="trend-svg" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-label="Tendencia do periodo">
      <defs>
        <linearGradient id="trend-area" x1="0%" x2="0%" y1="0%" y2="100%">
          <stop offset="0%" stop-color="rgba(22,199,132,0.34)" />
          <stop offset="100%" stop-color="rgba(22,199,132,0.02)" />
        </linearGradient>
      </defs>
      <line x1="${padding.left}" y1="${padding.top + chartHeight}" x2="${width - padding.right}" y2="${padding.top + chartHeight}" stroke="rgba(148,163,184,0.18)" stroke-width="1" />
      <path d="${areaPath}" fill="url(#trend-area)" />
      <polyline points="${totalPolyline}" fill="none" stroke="#16c784" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
      <polyline points="${closedPolyline}" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="2 6" />
      ${points.map((point, index) => `<circle cx="${getX(index)}" cy="${getY(point.total)}" r="2.6" fill="#16c784" />`).join("")}
      ${getAxisLabels(points).map((item) => `<text x="${item.x}" y="${height - 6}" text-anchor="middle" fill="#90a4bf" font-size="10">${escapeHtml(item.label)}</text>`).join("")}
      <text x="${padding.left}" y="11" fill="#90a4bf" font-size="10">Volume</text>
      <text x="${width - padding.right}" y="11" text-anchor="end" fill="#90a4bf" font-size="10">Concl. + rec.</text>
    </svg>
  `;
}

function renderDonutPanel(title: string, rows: ReportBreakdownRow[]) {
  const visibleRows = rows.slice(0, 5);
  const total = visibleRows.reduce((sum, row) => sum + row.total, 0);
  const topShare = visibleRows[0]?.share ?? 0;

  return `
    <article class="panel-card">
      <div class="panel-head">
        <div class="panel-title">${escapeHtml(title)}</div>
        <span class="panel-tag">Pizza</span>
      </div>
      ${
        visibleRows.length > 0
          ? `
            <div class="donut-layout">
              <div class="donut-shell" style="background:${buildDonutGradient(visibleRows)};">
                <div class="donut-center">
                  <span class="donut-value">${total}</span>
                  <span class="donut-label">${escapeHtml(formatPercent(topShare))}</span>
                </div>
              </div>
              <div class="legend-list">
                ${visibleRows.map((row, index) => `
                  <div class="legend-item">
                    <span class="legend-dot" style="background:${DONUT_COLORS[index % DONUT_COLORS.length]}"></span>
                    <span class="legend-label">${escapeHtml(row.label)}</span>
                    <span class="legend-value">${row.total}</span>
                  </div>
                `).join("")}
              </div>
            </div>
          `
          : `<div class="empty">Sem dados no periodo.</div>`
      }
    </article>
  `;
}

function renderBarPanel(title: string, rows: ReportBreakdownRow[], tag: string) {
  const visibleRows = rows.slice(0, 6);
  const max = Math.max(1, ...visibleRows.map((row) => row.total));

  return `
    <article class="panel-card category-panel">
      <div class="panel-head">
        <div class="panel-title">${escapeHtml(title)}</div>
        <span class="panel-tag">${escapeHtml(tag)}</span>
      </div>
      ${
        visibleRows.length > 0
          ? `
            <div class="bar-list">
              ${visibleRows.map((row) => `
                <div class="bar-row">
                  <span class="bar-label">${escapeHtml(shortenText(row.label, 18))}</span>
                  <div class="bar-track">
                    <div class="bar-fill" style="width:${Math.max(6, (row.total / max) * 100)}%;background:${getSeriesColor(row.label)}"></div>
                  </div>
                  <span class="bar-meta">
                    <span>${row.total}</span>
                    <span class="bar-share">${escapeHtml(formatPercent(row.share))}</span>
                  </span>
                </div>
              `).join("")}
            </div>
          `
          : `<div class="empty">Sem dados no periodo.</div>`
      }
    </article>
  `;
}

function renderHotspotPanel(rows: LocationPerformanceRow[]) {
  const max = Math.max(1, ...rows.map((row) => row.total));

  return `
    <article class="panel-card">
      <div class="panel-head">
        <div class="panel-title">Hotspots</div>
        <span class="panel-tag">Ranking</span>
      </div>
      ${
        rows.length > 0
          ? `
            <div class="hotspot-list">
              ${rows.map((row, index) => `
                <div class="hotspot-row">
                  <span class="hotspot-rank">${index + 1}</span>
                  <div>
                    <div class="hotspot-label">${escapeHtml(shortenText(row.label, 26))}</div>
                    <div class="hotspot-area">${escapeHtml(shortenText(row.area || "Sem area", 22))}</div>
                  </div>
                  <div class="hotspot-track">
                    <div class="hotspot-fill" style="width:${Math.max(7, (row.total / max) * 100)}%;background:linear-gradient(90deg, rgba(251,75,121,0.85), rgba(245,158,11,0.85))"></div>
                  </div>
                  <div class="hotspot-meta">
                    <span>${row.total}</span>
                    <span class="${getDeltaClass(row.deltaTotal)}">${formatSignedNumber(row.deltaTotal)}</span>
                    <span class="hotspot-share">${escapeHtml(formatPercent(row.share))}</span>
                  </div>
                </div>
              `).join("")}
            </div>
          `
          : `<div class="empty">Sem hotspots no periodo.</div>`
      }
    </article>
  `;
}

function renderOperatorPanel(rows: OperatorPerformanceRow[]) {
  const max = Math.max(1, ...rows.map((row) => row.total));

  return `
    <article class="panel-card">
      <div class="panel-head">
        <div class="panel-title">Operadores</div>
        <span class="panel-tag">Barras</span>
      </div>
      ${
        rows.length > 0
          ? `
            <div class="operator-list">
              ${rows.map((row) => {
                const activeWidth = row.total > 0 ? (row.ativas / row.total) * 100 : 0;
                const closedWidth = row.total > 0 ? (row.encerradas / row.total) * 100 : 0;

                return `
                  <div class="operator-row">
                    <div class="operator-text">
                      <div class="operator-name">${escapeHtml(shortenText(row.nome, 14))}</div>
                      <div class="operator-sub">Total ${row.total}<br />Ab. ${row.abertas} | And. ${row.andamento}<br />Concl. ${row.concluidas} | Rec. ${row.recusadas}</div>
                    </div>
                    <div class="operator-track" style="max-width:${Math.max(52, (row.total / max) * 100)}%">
                      <div class="stack-active" style="width:${activeWidth}%"></div>
                      <div class="stack-closed" style="width:${closedWidth}%"></div>
                    </div>
                    <div class="operator-rate">${escapeHtml(formatPercent(row.taxaFechamento))}</div>
                  </div>
                `;
              }).join("")}
            </div>
          `
          : `<div class="empty">Sem operadores no periodo.</div>`
      }
    </article>
  `;
}

function renderHighlightCard(item: ExecutiveHighlight) {
  return `
    <article class="highlight-card ${getToneClass(item.tone)}">
      <span class="highlight-title">${escapeHtml(item.title)}</span>
      <span class="highlight-text">${renderMultilineText(item.text)}</span>
    </article>
  `;
}

function renderMultilineText(value: string) {
  return escapeHtml(value).replace(/\n/g, "<br />");
}

function renderStatChip(label: string, value: string, sub: string) {
  return `
    <div class="stat-chip">
      <span class="stat-chip-label">${escapeHtml(label)}</span>
      <span class="stat-chip-value">${escapeHtml(value)}</span>
      <span class="stat-chip-sub">${escapeHtml(sub)}</span>
    </div>
  `;
}

function getAxisLabels(points: ReportTrendPoint[]) {
  if (points.length <= 3) {
    return points.map((point, index) => ({
      label: point.label,
      x: 8 + ((520 - 16) * index) / Math.max(1, points.length - 1),
    }));
  }

  const indices = Array.from(new Set([0, Math.floor((points.length - 1) / 2), points.length - 1]));
  return indices.map((index) => ({
    label: points[index]?.label ?? "",
    x: 8 + ((520 - 16) * index) / Math.max(1, points.length - 1),
  }));
}

function buildDonutGradient(rows: ReportBreakdownRow[]) {
  const total = rows.reduce((sum, row) => sum + row.total, 0);
  if (total <= 0) {
    return "rgba(148,163,184,.12)";
  }

  let cursor = 0;
  return `conic-gradient(${rows.map((row, index) => {
    const slice = (row.total / total) * 100;
    const segment = `${DONUT_COLORS[index % DONUT_COLORS.length]} ${cursor}% ${cursor + slice}%`;
    cursor += slice;
    return segment;
  }).join(", ")})`;
}

function getPressureCellStyle(
  status: string,
  priority: string,
  intensity: number,
) {
  const hasVolume = intensity > 0;
  const isHotCell =
    isActiveStatus(status) && (priority === "Crítica" || priority === "Alta");
  const isClosedCell = status === "Concluída";
  const isRejectedCell = status === "Recusada";

  if (!hasVolume) {
    return "background:rgba(255,255,255,.02);border-color:rgba(148,163,184,.08);";
  }

  if (isHotCell) {
    return `background:linear-gradient(180deg, rgba(251,75,121,${0.18 + intensity * 0.56}), rgba(245,158,11,${0.22 + intensity * 0.52}));border-color:rgba(245,158,11,${0.22 + intensity * 0.44});box-shadow:inset 0 0 0 1px rgba(251,75,121,.08);`;
  }

  if (isClosedCell) {
    return `background:linear-gradient(180deg, rgba(22,199,132,${0.14 + intensity * 0.46}), rgba(34,197,94,${0.14 + intensity * 0.34}));border-color:rgba(34,197,94,${0.18 + intensity * 0.28});`;
  }

  if (isRejectedCell) {
    return `background:linear-gradient(180deg, rgba(71,85,105,${0.18 + intensity * 0.32}), rgba(100,116,139,${0.12 + intensity * 0.24}));border-color:rgba(148,163,184,${0.18 + intensity * 0.22});`;
  }

  return `background:linear-gradient(180deg, rgba(56,189,248,${0.14 + intensity * 0.42}), rgba(14,165,233,${0.12 + intensity * 0.28}));border-color:rgba(56,189,248,${0.18 + intensity * 0.2});`;
}

function isActiveStatus(status: string) {
  return status === "Em aberto" || status === "Em andamento";
}

function normalizeHighlights(highlights: ExecutiveHighlight[]) {
  if (highlights.length >= 3) {
    return highlights.slice(0, 3);
  }

  return [
    highlights[0] ?? {
      title: "Status",
      text: "Ab. 0 | And. 0",
      tone: "neutral",
    },
    highlights[1] ?? {
      title: "Saida",
      text: "Concl. 0 | Rec. 0",
      tone: "neutral",
    },
    highlights[2] ?? {
      title: "Foco",
      text: "Tudo com dono",
      tone: "neutral",
    },
  ];
}

function formatGeneratedAt(value: string) {
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleString("pt-BR");
}

function formatCompactNumber(value: number) {
  if (!Number.isFinite(value)) {
    return "0";
  }

  return new Intl.NumberFormat("pt-BR", {
    minimumFractionDigits: 0,
    maximumFractionDigits: value < 10 ? 1 : 0,
  }).format(value);
}

function shortenText(value: string, maxLength: number) {
  const normalized = value.trim().replace(/\s+/g, " ");
  if (normalized.length <= maxLength) {
    return normalized;
  }

  return `${normalized.slice(0, Math.max(0, maxLength - 1)).trimEnd()}...`;
}

function formatSignedNumber(value: number) {
  if (value === 0) {
    return "0";
  }

  return `${value > 0 ? "+" : ""}${value}`;
}

function getSeriesColor(label: string) {
  const normalized = label.toLowerCase();

  if (normalized.includes("crit")) {
    return "linear-gradient(90deg, rgba(251,75,121,0.95), rgba(239,68,68,0.9))";
  }

  if (normalized.includes("alta") || normalized.includes("leve") || normalized.includes("aberto")) {
    return "linear-gradient(90deg, rgba(245,158,11,0.95), rgba(251,191,36,0.9))";
  }

  if (normalized.includes("andag") || normalized.includes("melhoria") || normalized.includes("media")) {
    return "linear-gradient(90deg, rgba(56,189,248,0.95), rgba(14,165,233,0.9))";
  }

  if (normalized.includes("concl")) {
    return "linear-gradient(90deg, rgba(22,199,132,0.95), rgba(34,197,94,0.9))";
  }

  if (normalized.includes("recus")) {
    return "linear-gradient(90deg, rgba(239,68,68,0.95), rgba(248,113,113,0.9))";
  }

  return "linear-gradient(90deg, rgba(22,199,132,0.95), rgba(56,189,248,0.85))";
}

function getToneClass(tone: ReportTone) {
  if (tone === "positive") {
    return "tone-positive";
  }

  if (tone === "warning") {
    return "tone-warning";
  }

  return "tone-neutral";
}

function getDeltaClass(value: number) {
  if (value > 0) {
    return "delta-positive";
  }

  if (value < 0) {
    return "delta-negative";
  }

  return "delta-neutral";
}

function escapeHtml(value: string) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
