import type { NormalizedDemanda } from "@/lib/app-data";

export function getDemandLocationInfo(
  demanda: Pick<NormalizedDemanda, "area" | "localExato">,
) {
  const area = demanda.area.trim();
  const localExato = demanda.localExato.trim();

  if (localExato && area && localExato !== area) {
    return {
      primary: localExato,
      secondary: area,
    };
  }

  return {
    primary: localExato || area || "-",
    secondary: "",
  };
}
