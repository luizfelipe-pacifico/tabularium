import type { NormalizedDemanda } from "@/lib/app-data";
import { UNASSIGNED_OPERATOR } from "@/lib/app-data";

const GRAU_POINTS: Record<string, number> = {
  "Crítica": 120,
  Alta: 80,
  "Média": 50,
  Baixa: 20,
};

const CATEGORIA_POINTS: Record<string, number> = {
  "Bug crítico": 90,
  "Bug leve": 55,
  Melhoria: 35,
  Sugestão: 20,
};

export interface PrioritizedDemanda {
  demanda: NormalizedDemanda;
  score: number;
  ageInDays: number;
}

function parseDemandDate(value: string | null | undefined): Date | null {
  if (!value) {
    return null;
  }

  const raw = String(value).trim();
  if (!raw) {
    return null;
  }

  const nativeDate = new Date(raw);
  if (!Number.isNaN(nativeDate.getTime())) {
    return nativeDate;
  }

  const brMatch = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2}))?/);
  if (!brMatch) {
    return null;
  }

  const [, day, month, year, hour = "0", minute = "0"] = brMatch;
  const parsed = new Date(
    Number(year),
    Number(month) - 1,
    Number(day),
    Number(hour),
    Number(minute),
  );

  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

export function getDemandPriorityScore(
  demanda: NormalizedDemanda,
  referenceDate = new Date(),
): PrioritizedDemanda {
  const createdAt = parseDemandDate(demanda.dataDaRequisicao || demanda.data);
  const ageInDays = createdAt
    ? Math.max(
        0,
        Math.floor((referenceDate.getTime() - createdAt.getTime()) / (1000 * 60 * 60 * 24)),
      )
    : 0;

  const grauPoints = GRAU_POINTS[demanda.grau] ?? 10;
  const categoriaPoints = CATEGORIA_POINTS[demanda.categoria] ?? 10;
  const agePoints = Math.min(ageInDays * 5, 80);
  const statusPoints =
    demanda.status === "Em aberto" ? 30 : demanda.status === "Em andamento" ? 15 : 0;
  const operatorPoints = demanda.operador === UNASSIGNED_OPERATOR ? 12 : 0;

  return {
    demanda,
    ageInDays,
    score: grauPoints + categoriaPoints + agePoints + statusPoints + operatorPoints,
  };
}

export function getTopPriorityDemandas(
  demandas: NormalizedDemanda[],
  limit = 5,
): PrioritizedDemanda[] {
  return demandas
    .map((demanda) => getDemandPriorityScore(demanda))
    .sort((left, right) => {
      if (right.score !== left.score) {
        return right.score - left.score;
      }

      if (right.ageInDays !== left.ageInDays) {
        return right.ageInDays - left.ageInDays;
      }

      return left.demanda.id.localeCompare(right.demanda.id, "pt-BR");
    })
    .slice(0, limit);
}
