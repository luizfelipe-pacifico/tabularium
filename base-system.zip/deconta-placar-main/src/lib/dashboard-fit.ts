const DEFAULT_MAX_SCALE = 1;
const DEFAULT_MIN_SCALE = 0.4;

export interface DashboardFitMetrics {
  availableWidth: number;
  availableHeight: number;
  contentWidth: number;
  contentHeight: number;
  maxScale?: number;
  minScale?: number;
}

function clampScale(value: number, minScale: number, maxScale: number) {
  if (!Number.isFinite(value)) {
    return maxScale;
  }

  return Math.max(minScale, Math.min(maxScale, value));
}

export function calculateDashboardFitScale({
  availableWidth,
  availableHeight,
  contentWidth,
  contentHeight,
  maxScale = DEFAULT_MAX_SCALE,
  minScale = DEFAULT_MIN_SCALE,
}: DashboardFitMetrics) {
  if (
    availableWidth <= 0 ||
    availableHeight <= 0 ||
    contentWidth <= 0 ||
    contentHeight <= 0
  ) {
    return maxScale;
  }

  const widthScale = availableWidth / contentWidth;
  const heightScale = availableHeight / contentHeight;

  return clampScale(Math.min(maxScale, widthScale, heightScale), minScale, maxScale);
}

export function getDashboardFitWidth(scale: number) {
  if (!Number.isFinite(scale) || scale >= 0.999) {
    return "100%";
  }

  return `${100 / scale}%`;
}
