export const LAST_ROUTE_STORAGE_KEY = "deconta:last-route";

export function normalizeRoutePath(path: string | null | undefined) {
  if (!path) {
    return null;
  }

  const trimmed = path.trim();
  if (!trimmed.startsWith("/")) {
    return null;
  }

  if (trimmed === "/") {
    return "/";
  }

  return trimmed.replace(/\/+$/, "") || "/";
}

export function getStoredLaunchRoute(
  currentPath: string,
  storedPath: string | null | undefined,
) {
  const normalizedStored = normalizeRoutePath(storedPath);
  if (currentPath !== "/" || !normalizedStored || normalizedStored === "/") {
    return null;
  }

  return normalizedStored;
}
