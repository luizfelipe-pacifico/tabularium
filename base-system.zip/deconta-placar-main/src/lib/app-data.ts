export const STATUS_LABELS = [
  "Em aberto",
  "Em andamento",
  "Concluída",
  "Recusada",
] as const;

export const PRIORITY_LABELS = [
  "Crítica",
  "Alta",
  "Média",
  "Baixa",
] as const;

export const CATEGORY_LABELS = [
  "Bug crítico",
  "Bug leve",
  "Melhoria",
  "Sugestão",
] as const;

export const UNASSIGNED_OPERATOR = "Não atribuída";

export type StatusLabel = (typeof STATUS_LABELS)[number];
export type PriorityLabel = (typeof PRIORITY_LABELS)[number];
export type CategoryLabel = (typeof CATEGORY_LABELS)[number];

export interface DevProfile {
  nome: string;
  email: string;
  fotoUrl?: string;
  cargo?: string;
}

export interface AppConfig {
  fonteUrl: string;
  intervalo: number;
  emailAlerta?: string;
  nomeAmbiente?: string;
  tema?: string;
  ultimaSincronizacao?: string | null;
  zoomLevel?: number;
  sidebarCollapsed?: boolean;
  devProfiles?: DevProfile[];
}

export interface NormalizedDemanda {
  id: string;
  data: string;
  dataDaRequisicao: string | null;
  aba?: string;
  nome: string;
  email: string;
  categoria: CategoryLabel | string;
  grau: PriorityLabel | string;
  status: StatusLabel | string;
  operador: string;
  area: string;
  localExato: string;
  descricao: string;
  comoAconteceu: string;
  oQueDeveriaAcontecer: string;
  anexo: string;
  observacoesExtras: string;
  cliente?: string;
}

export interface OperatorSummary {
  nome: string;
  avatar: string;
  email: string;
  fotoUrl?: string;
  cargo: string;
  total: number;
  abertas: number;
  andamento: number;
  concluidas: number;
  recusadas: number;
  ativas: number;
}

export interface DashboardStats {
  totalDemandas: number;
  totalAtivas: number;
  totalHistorico: number;
  emAberto: number;
  emAndamento: number;
  concluidas: number;
  recusadas: number;
  porGrau: Record<PriorityLabel, number>;
  porCategoria: Record<CategoryLabel, number>;
  porOperador: Record<string, number>;
}

export interface SourceStatus {
  mode: "remote" | "cache" | "fallback";
  message: string;
  error?: string | null;
}

export type ConnectionState = "connected" | "cache" | "error";

export interface CacheDebugInfo {
  status: "not-used" | "used" | "empty";
  message: string;
  updatedAt: string | null;
}

export interface AppDataSnapshot {
  success: boolean;
  generatedAt: string | null;
  lastUpdated: string | null;
  intervalo: number;
  fonteUrl: string;
  demandas: NormalizedDemanda[];
  demandasAtivas: NormalizedDemanda[];
  demandasHistorico: NormalizedDemanda[];
  ultimasDemandas: NormalizedDemanda[];
  operadores: OperatorSummary[];
  stats: DashboardStats;
  sourceStatus: SourceStatus;
}

export interface AppDataDebugInfo {
  rawApiPayload: unknown | null;
  adaptedPayload: AppDataSnapshot | null;
  cache: CacheDebugInfo;
}

export interface AppData extends AppDataSnapshot {
  debug: AppDataDebugInfo;
}

export function createEmptyStats(): DashboardStats {
  return {
    totalDemandas: 0,
    totalAtivas: 0,
    totalHistorico: 0,
    emAberto: 0,
    emAndamento: 0,
    concluidas: 0,
    recusadas: 0,
    porGrau: {
      Crítica: 0,
      Alta: 0,
      Média: 0,
      Baixa: 0,
    },
    porCategoria: {
      "Bug crítico": 0,
      "Bug leve": 0,
      Melhoria: 0,
      Sugestão: 0,
    },
    porOperador: {
      [UNASSIGNED_OPERATOR]: 0,
    },
  };
}

export function createEmptyDebugInfo(): AppDataDebugInfo {
  return {
    rawApiPayload: null,
    adaptedPayload: null,
    cache: {
      status: "empty",
      message: "Nenhum cache local foi utilizado nesta leitura.",
      updatedAt: null,
    },
  };
}

export function createEmptyAppData(overrides: Partial<AppData> = {}): AppData {
  const baseStats = createEmptyStats();
  const baseDebug = createEmptyDebugInfo();

  return {
    success: false,
    generatedAt: null,
    lastUpdated: null,
    intervalo: 5,
    fonteUrl: "",
    demandas: [],
    demandasAtivas: [],
    demandasHistorico: [],
    ultimasDemandas: [],
    operadores: [],
    sourceStatus: {
      mode: "fallback",
      message: "Sem dados sincronizados.",
      error: null,
    },
    ...overrides,
    stats: {
      ...baseStats,
      ...overrides.stats,
      porGrau: {
        ...baseStats.porGrau,
        ...overrides.stats?.porGrau,
      },
      porCategoria: {
        ...baseStats.porCategoria,
        ...overrides.stats?.porCategoria,
      },
      porOperador: {
        ...baseStats.porOperador,
        ...overrides.stats?.porOperador,
      },
    },
    debug: {
      ...baseDebug,
      ...overrides.debug,
      cache: {
        ...baseDebug.cache,
        ...overrides.debug?.cache,
      },
    },
  };
}

export function toAppDataSnapshot(data: AppData | AppDataSnapshot): AppDataSnapshot {
  if ("debug" in data) {
    const { debug: _debug, ...snapshot } = data;
    return snapshot;
  }

  return { ...data };
}

export function getAppDataFreshness(data?: Partial<AppData> | null): number {
  const reference = data?.lastUpdated ?? data?.generatedAt;
  if (!reference) {
    return 0;
  }

  const parsed = new Date(reference).getTime();
  return Number.isFinite(parsed) ? parsed : 0;
}

export function pickNewestAppData(
  current: AppData | undefined,
  incoming: AppData,
): AppData {
  if (!current) {
    return incoming;
  }

  const incomingFreshness = getAppDataFreshness(incoming);
  const currentFreshness = getAppDataFreshness(current);

  return incomingFreshness >= currentFreshness ? incoming : current;
}

export function getMaxValue(values: number[]): number {
  return values.length > 0 ? Math.max(0, ...values) : 0;
}

export function getSortedEntries(
  values: Record<string, number>,
): Array<[string, number]> {
  return Object.entries(values).sort((left, right) => {
    if (right[1] !== left[1]) {
      return right[1] - left[1];
    }

    return left[0].localeCompare(right[0], "pt-BR");
  });
}

export function getSourceStatusTone(
  mode: SourceStatus["mode"],
): "success" | "warning" | "destructive" {
  if (mode === "remote") {
    return "success";
  }

  if (mode === "cache") {
    return "warning";
  }

  return "destructive";
}

export function getConnectionState(sourceStatus: SourceStatus): ConnectionState {
  if (sourceStatus.mode === "cache") {
    return "cache";
  }

  if (sourceStatus.mode === "fallback" || Boolean(sourceStatus.error)) {
    return "error";
  }

  return "connected";
}

export function getConnectionLabel(sourceStatus: SourceStatus): string {
  const state = getConnectionState(sourceStatus);

  if (state === "connected") {
    return "Conectado";
  }

  if (state === "cache") {
    return "Usando cache";
  }

  return "Erro de conexão";
}

export function getConnectionTone(
  sourceStatus: SourceStatus,
): "success" | "warning" | "destructive" {
  const state = getConnectionState(sourceStatus);

  if (state === "connected") {
    return "success";
  }

  if (state === "cache") {
    return "warning";
  }

  return "destructive";
}
