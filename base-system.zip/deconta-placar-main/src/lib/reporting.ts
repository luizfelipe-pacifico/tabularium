import {
  CATEGORY_LABELS,
  PRIORITY_LABELS,
  STATUS_LABELS,
  UNASSIGNED_OPERATOR,
  type AppData,
  type NormalizedDemanda,
} from "@/lib/app-data";
import { getDemandPriorityScore, type PrioritizedDemanda } from "@/lib/demand-priority";
import { getDemandLocationInfo } from "@/lib/demand-location";

export type ReportPreset = "last7" | "last14" | "month";

export interface ReportFilters {
  startDate: string;
  endDate: string;
  operators: string[];
}

export interface MetricDelta {
  current: number;
  previous: number;
  absolute: number;
  percentage: number | null;
  direction: "up" | "down" | "stable";
}

export type ReportTone = "positive" | "warning" | "neutral";

export interface ReportKpiCard {
  title: string;
  value: string;
  detail: string;
  delta: string;
  tone: ReportTone;
}

export interface ReportBreakdownRow {
  label: string;
  total: number;
  share: number;
}

export interface ReportPressureCell {
  priority: string;
  total: number;
  share: number;
}

export interface ReportPressureRow {
  status: string;
  total: number;
  cells: ReportPressureCell[];
}

export interface ReportTrendPoint {
  label: string;
  total: number;
  ativas: number;
  encerradas: number;
}

export interface ExecutiveHighlight {
  title: string;
  text: string;
  tone: ReportTone;
}

export interface ReportNarrativeItem {
  title: string;
  text: string;
  tone: "positive" | "warning" | "neutral";
}

export interface ReportReason {
  title: string;
  description: string;
  detail: string;
  tone: "positive" | "warning" | "neutral";
}

export interface OperatorPerformanceRow {
  nome: string;
  total: number;
  abertas: number;
  andamento: number;
  ativas: number;
  encerradas: number;
  concluidas: number;
  recusadas: number;
  share: number;
  taxaFechamento: number;
  previousTotal: number;
  deltaTotal: number;
}

export interface LocationPerformanceRow {
  label: string;
  area: string;
  total: number;
  previousTotal: number;
  deltaTotal: number;
  share: number;
}

export interface ReportPeriodSummary {
  demandas: NormalizedDemanda[];
  totalDemandas: number;
  totalAtivas: number;
  totalHistorico: number;
  emAberto: number;
  emAndamento: number;
  concluidas: number;
  recusadas: number;
  backlogSemResponsavel: number;
  ativasComOperador: number;
  highPriorityCount: number;
  taxaFechamento: number;
  taxaConclusao: number;
  coberturaAtribuicao: number;
  shareAltaPrioridade: number;
  byStatus: Record<string, number>;
  byCategoria: Record<string, number>;
  byPrioridade: Record<string, number>;
  byOperador: Record<string, number>;
  byLocal: Record<string, { total: number; area: string }>;
}

export interface PerformanceReport {
  filters: ReportFilters;
  currentLabel: string;
  previousLabel: string;
  periodDays: number;
  selectedOperatorNames: string[];
  current: ReportPeriodSummary;
  previous: ReportPeriodSummary;
  kpis: ReportKpiCard[];
  pressureRows: ReportPressureRow[];
  trendPoints: ReportTrendPoint[];
  statusRows: ReportBreakdownRow[];
  categoryRows: ReportBreakdownRow[];
  priorityRows: ReportBreakdownRow[];
  deltas: {
    totalDemandas: MetricDelta;
    totalHistorico: MetricDelta;
    concluidas: MetricDelta;
    backlogSemResponsavel: MetricDelta;
    taxaFechamento: MetricDelta;
    coberturaAtribuicao: MetricDelta;
    shareAltaPrioridade: MetricDelta;
  };
  operatorRows: OperatorPerformanceRow[];
  hotspotRows: LocationPerformanceRow[];
  highlights: ExecutiveHighlight[];
  narratives: ReportNarrativeItem[];
  reasons: ReportReason[];
  topDemandas: PrioritizedDemanda[];
}

const ACTIVE_STATUSES = new Set(["Em aberto", "Em andamento"]);
const HISTORIC_STATUSES = new Set(["Concluída", "Recusada"]);
const HIGH_PRIORITY_LABELS = new Set(["Crítica", "Alta"]);

export function getAvailableReportOperators(data: AppData): string[] {
  const names = new Set<string>();

  data.operadores.forEach((operator) => {
    if (operator.nome) {
      names.add(operator.nome);
    }
  });

  data.demandas.forEach((demanda) => {
    names.add(normalizeOperatorName(demanda.operador));
  });

  return Array.from(names).sort((left, right) => {
    if (left === UNASSIGNED_OPERATOR) {
      return 1;
    }

    if (right === UNASSIGNED_OPERATOR) {
      return -1;
    }

    return left.localeCompare(right, "pt-BR");
  });
}

export function getSuggestedReportRange(
  demandas: NormalizedDemanda[],
  preset: ReportPreset = "last7",
): Pick<ReportFilters, "startDate" | "endDate"> {
  const referenceDate = getLatestDemandDate(demandas) ?? new Date();
  const endDate = stripTime(referenceDate);
  let startDate = new Date(endDate);

  if (preset === "last14") {
    startDate = addDays(endDate, -13);
  } else if (preset === "month") {
    startDate = new Date(endDate.getFullYear(), endDate.getMonth(), 1);
  } else {
    startDate = addDays(endDate, -6);
  }

  return {
    startDate: formatInputDate(startDate),
    endDate: formatInputDate(endDate),
  };
}

export function buildPerformanceReport(
  data: AppData,
  filters: ReportFilters,
): PerformanceReport {
  const normalizedFilters = normalizeFilters(filters);
  const allOperators = getAvailableReportOperators(data);
  const selectedOperatorNames =
    normalizedFilters.operators.length > 0
      ? normalizedFilters.operators
      : allOperators;
  const currentDemandas = filterDemandasByPeriod(
    data.demandas,
    normalizedFilters.startDate,
    normalizedFilters.endDate,
    selectedOperatorNames,
  );

  const periodDays = getPeriodDays(normalizedFilters.startDate, normalizedFilters.endDate);
  const previousEnd = addDays(parseInputDate(normalizedFilters.startDate), -1);
  const previousStart = addDays(previousEnd, -(periodDays - 1));

  const previousDemandas = filterDemandasByPeriod(
    data.demandas,
    formatInputDate(previousStart),
    formatInputDate(previousEnd),
    selectedOperatorNames,
  );

  const current = summarizePeriod(currentDemandas);
  const previous = summarizePeriod(previousDemandas);
  const operatorRows = buildOperatorRows(current, previous, selectedOperatorNames);
  const hotspotRows = buildHotspotRows(current, previous);
  const deltas = {
    totalDemandas: buildDelta(current.totalDemandas, previous.totalDemandas),
    totalHistorico: buildDelta(current.totalHistorico, previous.totalHistorico),
    concluidas: buildDelta(current.concluidas, previous.concluidas),
    backlogSemResponsavel: buildDelta(
      current.backlogSemResponsavel,
      previous.backlogSemResponsavel,
    ),
    taxaFechamento: buildDelta(current.taxaFechamento, previous.taxaFechamento),
    coberturaAtribuicao: buildDelta(
      current.coberturaAtribuicao,
      previous.coberturaAtribuicao,
    ),
    shareAltaPrioridade: buildDelta(
      current.shareAltaPrioridade,
      previous.shareAltaPrioridade,
    ),
  };

  return {
    filters: normalizedFilters,
    currentLabel: formatPeriodLabel(
      normalizedFilters.startDate,
      normalizedFilters.endDate,
    ),
    previousLabel: formatPeriodLabel(
      formatInputDate(previousStart),
      formatInputDate(previousEnd),
    ),
    periodDays,
    selectedOperatorNames,
    current,
    previous,
    kpis: buildKpiCards(current, previous),
    pressureRows: buildPressureRows(current.demandas, current.totalDemandas),
    trendPoints: buildTrendPoints(
      currentDemandas,
      normalizedFilters.startDate,
      normalizedFilters.endDate,
    ),
    statusRows: buildBreakdownRows(current.byStatus, current.totalDemandas, STATUS_LABELS),
    categoryRows: buildBreakdownRows(
      current.byCategoria,
      current.totalDemandas,
      CATEGORY_LABELS,
    ),
    priorityRows: buildBreakdownRows(
      current.byPrioridade,
      current.totalDemandas,
      PRIORITY_LABELS,
    ),
    deltas,
    operatorRows,
    hotspotRows,
    highlights: buildExecutiveHighlights(current, previous, deltas, hotspotRows, operatorRows),
    narratives: buildNarratives(current, previous, deltas, hotspotRows, selectedOperatorNames),
    reasons: buildReasons(current, previous, deltas, hotspotRows, operatorRows),
    topDemandas: current.demandas
      .map((demanda) => getDemandPriorityScore(demanda))
      .sort((left, right) => {
        if (right.score !== left.score) {
          return right.score - left.score;
        }

        return right.ageInDays - left.ageInDays;
      })
      .slice(0, 3),
  };
}

export function formatPercent(value: number, maximumFractionDigits = 0): string {
  return `${new Intl.NumberFormat("pt-BR", {
    minimumFractionDigits: 0,
    maximumFractionDigits,
  }).format(value)}%`;
}

export function formatDeltaLabel(
  delta: MetricDelta,
  suffix = "",
  maximumFractionDigits = 0,
): string {
  if (delta.direction === "stable") {
    return `Sem variação${suffix}`;
  }

  if (delta.percentage === null) {
    return `${delta.direction === "up" ? "+" : "-"}${Math.abs(delta.absolute)}${suffix}`;
  }

  return `${delta.direction === "up" ? "+" : "-"}${formatPercent(
    Math.abs(delta.percentage),
    maximumFractionDigits,
  )}${suffix}`;
}

function normalizeFilters(filters: ReportFilters): ReportFilters {
  const suggestedRange = getSuggestedReportRange([], "last7");
  const startDate = filters.startDate || suggestedRange.startDate;
  const endDate = filters.endDate || startDate;
  const normalizedStart = startDate <= endDate ? startDate : endDate;
  const normalizedEnd = startDate <= endDate ? endDate : startDate;

  return {
    startDate: normalizedStart,
    endDate: normalizedEnd,
    operators: Array.from(
      new Set(filters.operators.map((value) => normalizeOperatorName(value))),
    ),
  };
}

function filterDemandasByPeriod(
  demandas: NormalizedDemanda[],
  startDate: string,
  endDate: string,
  operators: string[],
): NormalizedDemanda[] {
  const start = startOfDay(parseInputDate(startDate)).getTime();
  const end = endOfDay(parseInputDate(endDate)).getTime();
  const scopedOperators = new Set(operators);

  return demandas.filter((demanda) => {
    const timestamp = getDemandTimestamp(demanda);
    if (!timestamp || timestamp < start || timestamp > end) {
      return false;
    }

    if (scopedOperators.size === 0) {
      return true;
    }

    return scopedOperators.has(normalizeOperatorName(demanda.operador));
  });
}

function summarizePeriod(demandas: NormalizedDemanda[]): ReportPeriodSummary {
  const byStatus = createSeedCountMap(STATUS_LABELS);
  const byCategoria = createSeedCountMap(CATEGORY_LABELS);
  const byPrioridade = createSeedCountMap(PRIORITY_LABELS);
  const byOperador: Record<string, number> = {};
  const byLocal: Record<string, { total: number; area: string }> = {};

  let totalAtivas = 0;
  let totalHistorico = 0;
  let emAberto = 0;
  let emAndamento = 0;
  let concluidas = 0;
  let recusadas = 0;
  let backlogSemResponsavel = 0;
  let highPriorityCount = 0;

  demandas.forEach((demanda) => {
    const status = demanda.status;
    const categoria = demanda.categoria;
    const prioridade = demanda.grau;
    const operador = normalizeOperatorName(demanda.operador);
    const location = getDemandLocationInfo(demanda);

    byStatus[status] = (byStatus[status] ?? 0) + 1;
    byCategoria[categoria] = (byCategoria[categoria] ?? 0) + 1;
    byPrioridade[prioridade] = (byPrioridade[prioridade] ?? 0) + 1;
    byOperador[operador] = (byOperador[operador] ?? 0) + 1;
    byLocal[location.primary] = {
      total: (byLocal[location.primary]?.total ?? 0) + 1,
      area: location.secondary,
    };

    if (status === "Em aberto") {
      emAberto += 1;
      totalAtivas += 1;
    } else if (status === "Em andamento") {
      emAndamento += 1;
      totalAtivas += 1;
    } else if (status === "Concluída") {
      concluidas += 1;
      totalHistorico += 1;
    } else if (status === "Recusada") {
      recusadas += 1;
      totalHistorico += 1;
    } else if (ACTIVE_STATUSES.has(status)) {
      totalAtivas += 1;
    } else if (HISTORIC_STATUSES.has(status)) {
      totalHistorico += 1;
    }

    if (ACTIVE_STATUSES.has(status) && operador === UNASSIGNED_OPERATOR) {
      backlogSemResponsavel += 1;
    }

    if (HIGH_PRIORITY_LABELS.has(prioridade)) {
      highPriorityCount += 1;
    }
  });

  const totalDemandas = demandas.length;
  const taxaFechamento = totalDemandas > 0 ? (totalHistorico / totalDemandas) * 100 : 0;
  const taxaConclusao = totalHistorico > 0 ? (concluidas / totalHistorico) * 100 : 0;
  const ativasComOperador = Math.max(0, totalAtivas - backlogSemResponsavel);
  const coberturaAtribuicao =
    totalAtivas > 0 ? (ativasComOperador / totalAtivas) * 100 : 100;
  const shareAltaPrioridade =
    totalDemandas > 0 ? (highPriorityCount / totalDemandas) * 100 : 0;

  return {
    demandas,
    totalDemandas,
    totalAtivas,
    totalHistorico,
    emAberto,
    emAndamento,
    concluidas,
    recusadas,
    backlogSemResponsavel,
    ativasComOperador,
    highPriorityCount,
    taxaFechamento,
    taxaConclusao,
    coberturaAtribuicao,
    shareAltaPrioridade,
    byStatus,
    byCategoria,
    byPrioridade,
    byOperador,
    byLocal,
  };
}

function buildOperatorRows(
  current: ReportPeriodSummary,
  previous: ReportPeriodSummary,
  operatorScope: string[],
): OperatorPerformanceRow[] {
  const names = operatorScope.length > 0
    ? operatorScope
    : Array.from(
        new Set([
          ...Object.keys(current.byOperador),
          ...Object.keys(previous.byOperador),
        ]),
      );

  return names
    .map((name) => {
      const currentDemandas = current.demandas.filter(
        (demanda) => normalizeOperatorName(demanda.operador) === name,
      );
      const previousTotal = previous.byOperador[name] ?? 0;
      const total = currentDemandas.length;
      const abertas = currentDemandas.filter(
        (demanda) => demanda.status === "Em aberto",
      ).length;
      const andamento = currentDemandas.filter(
        (demanda) => demanda.status === "Em andamento",
      ).length;
      const concluidas = currentDemandas.filter(
        (demanda) => demanda.status === "Concluída",
      ).length;
      const recusadas = currentDemandas.filter(
        (demanda) => demanda.status === "Recusada",
      ).length;

      return {
        nome: name,
        total,
        abertas,
        andamento,
        ativas: abertas + andamento,
        encerradas: concluidas + recusadas,
        concluidas,
        recusadas,
        share: current.totalDemandas > 0 ? (total / current.totalDemandas) * 100 : 0,
        taxaFechamento: total > 0 ? ((concluidas + recusadas) / total) * 100 : 0,
        previousTotal,
        deltaTotal: total - previousTotal,
      };
    })
    .sort((left, right) => {
      if (right.total !== left.total) {
        return right.total - left.total;
      }

      if (right.concluidas !== left.concluidas) {
        return right.concluidas - left.concluidas;
      }

      return left.nome.localeCompare(right.nome, "pt-BR");
    });
}

function buildHotspotRows(
  current: ReportPeriodSummary,
  previous: ReportPeriodSummary,
): LocationPerformanceRow[] {
  const labels = new Set([
    ...Object.keys(current.byLocal),
    ...Object.keys(previous.byLocal),
  ]);

  return Array.from(labels)
    .map((label) => {
      const currentItem = current.byLocal[label];
      const previousItem = previous.byLocal[label];
      const total = currentItem?.total ?? 0;
      const previousTotal = previousItem?.total ?? 0;

      return {
        label,
        area: currentItem?.area || previousItem?.area || "",
        total,
        previousTotal,
        deltaTotal: total - previousTotal,
        share: current.totalDemandas > 0 ? (total / current.totalDemandas) * 100 : 0,
      };
    })
    .sort((left, right) => {
      if (right.total !== left.total) {
        return right.total - left.total;
      }

      if (Math.abs(right.deltaTotal) !== Math.abs(left.deltaTotal)) {
        return Math.abs(right.deltaTotal) - Math.abs(left.deltaTotal);
      }

      return left.label.localeCompare(right.label, "pt-BR");
    })
    .slice(0, 5);
}

function buildKpiCards(
  current: ReportPeriodSummary,
  previous: ReportPeriodSummary,
): ReportKpiCard[] {
  const totalDemandasDelta = buildDelta(current.totalDemandas, previous.totalDemandas);
  const taxaFechamentoDelta = buildDelta(current.taxaFechamento, previous.taxaFechamento);
  const coberturaDelta = buildDelta(
    current.coberturaAtribuicao,
    previous.coberturaAtribuicao,
  );
  const altaPrioridadeDelta = buildDelta(
    current.shareAltaPrioridade,
    previous.shareAltaPrioridade,
  );

  return [
    {
      title: "No período",
      value: String(current.totalDemandas),
      detail: buildStatusSummaryDetail(current),
      delta: formatKpiDelta(totalDemandasDelta),
      tone: getKpiTone(totalDemandasDelta, "volume"),
    },
    {
      title: "Fechamento",
      value: formatPercent(current.taxaFechamento),
      detail: `Concl. ${current.concluidas} | Rec. ${current.recusadas}`,
      delta: formatKpiDelta(taxaFechamentoDelta, { percentageDigits: 1 }),
      tone: getKpiTone(taxaFechamentoDelta, "higher_better"),
    },
    {
      title: "Com dono",
      value:
        current.totalAtivas > 0
          ? formatPercent(current.coberturaAtribuicao)
          : "100%",
      detail:
        current.totalAtivas > 0
          ? `Sem dono ${current.backlogSemResponsavel}`
          : "Sem fila ativa",
      delta: formatKpiDelta(coberturaDelta, { percentageDigits: 1 }),
      tone: getKpiTone(coberturaDelta, "higher_better"),
    },
    {
      title: "Crit. / alta",
      value: formatPercent(current.shareAltaPrioridade),
      detail: `Crit. ${current.byPrioridade[PRIORITY_LABELS[0]] ?? 0} | Alta ${current.byPrioridade[PRIORITY_LABELS[1]] ?? 0}`,
      delta: formatKpiDelta(altaPrioridadeDelta, { percentageDigits: 1 }),
      tone: getKpiTone(altaPrioridadeDelta, "lower_better"),
    },
  ];
}

function buildStatusSummaryDetail(current: ReportPeriodSummary): string {
  return `Ab. ${current.emAberto} | And. ${current.emAndamento}\nConcl. ${current.concluidas} | Rec. ${current.recusadas}`;
}

function buildBreakdownRows(
  values: Record<string, number>,
  totalDemandas: number,
  preferredOrder: readonly string[],
): ReportBreakdownRow[] {
  const preferredRows = preferredOrder
    .map((label) => ({
      label,
      total: values[label] ?? 0,
      share: totalDemandas > 0 ? ((values[label] ?? 0) / totalDemandas) * 100 : 0,
    }))
    .filter((row) => row.total > 0);

  const extras = Object.entries(values)
    .filter(([label, total]) => total > 0 && !preferredOrder.includes(label))
    .sort((left, right) => {
      if (right[1] !== left[1]) {
        return right[1] - left[1];
      }

      return left[0].localeCompare(right[0], "pt-BR");
    })
    .map(([label, total]) => ({
      label,
      total,
      share: totalDemandas > 0 ? (total / totalDemandas) * 100 : 0,
    }));

  return [...preferredRows, ...extras];
}

function buildPressureRows(
  demandas: NormalizedDemanda[],
  totalDemandas: number,
): ReportPressureRow[] {
  return STATUS_LABELS.map((status) => {
    const scopedDemandas = demandas.filter((demanda) => demanda.status === status);

    return {
      status,
      total: scopedDemandas.length,
      cells: PRIORITY_LABELS.map((priority) => {
        const total = scopedDemandas.filter((demanda) => demanda.grau === priority).length;

        return {
          priority,
          total,
          share: totalDemandas > 0 ? (total / totalDemandas) * 100 : 0,
        };
      }),
    };
  });
}

function buildTrendPoints(
  demandas: NormalizedDemanda[],
  startDate: string,
  endDate: string,
): ReportTrendPoint[] {
  const dailyMap = new Map<string, ReportTrendPoint>();
  const formatter = new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "2-digit",
  });

  let cursor = parseInputDate(startDate);
  const limit = parseInputDate(endDate);

  while (cursor.getTime() <= limit.getTime()) {
    const key = formatInputDate(cursor);
    dailyMap.set(key, {
      label: formatter.format(cursor),
      total: 0,
      ativas: 0,
      encerradas: 0,
    });
    cursor = addDays(cursor, 1);
  }

  demandas.forEach((demanda) => {
    const timestamp = getDemandTimestamp(demanda);
    if (!timestamp) {
      return;
    }

    const demandDate = formatInputDate(new Date(timestamp));
    const bucket = dailyMap.get(demandDate);
    if (!bucket) {
      return;
    }

    bucket.total += 1;

    if (ACTIVE_STATUSES.has(demanda.status)) {
      bucket.ativas += 1;
    } else if (HISTORIC_STATUSES.has(demanda.status)) {
      bucket.encerradas += 1;
    }
  });

  return Array.from(dailyMap.values());
}

function buildExecutiveHighlights(
  current: ReportPeriodSummary,
  previous: ReportPeriodSummary,
  deltas: PerformanceReport["deltas"],
  hotspotRows: LocationPerformanceRow[],
  operatorRows: OperatorPerformanceRow[],
): ExecutiveHighlight[] {
  return [
    {
      title: "Status",
      text: `Ab. ${current.emAberto} | And. ${current.emAndamento}`,
      tone: current.totalAtivas > 0 ? "warning" : "neutral",
    },
    {
      title: "Saída",
      text: `Concl. ${current.concluidas} | Rec. ${current.recusadas}`,
      tone: current.totalHistorico > 0 ? "positive" : "neutral",
    },
    {
      title: "Foco",
      text:
        current.backlogSemResponsavel > 0
          ? `${current.backlogSemResponsavel} sem dono | ${current.highPriorityCount} crit./alta`
          : `${current.highPriorityCount} crit./alta | tudo com dono`,
      tone:
        current.backlogSemResponsavel > 0 || current.highPriorityCount > 0
          ? "warning"
          : "neutral",
    },
  ];
}

function buildNarratives(
  current: ReportPeriodSummary,
  previous: ReportPeriodSummary,
  deltas: PerformanceReport["deltas"],
  hotspotRows: LocationPerformanceRow[],
  selectedOperatorNames: string[],
): ReportNarrativeItem[] {
  const topCategoria = getTopEntry(current.byCategoria);
  const topHotspot = hotspotRows.find((row) => row.total > 0);
  const operatorScopeLabel =
    selectedOperatorNames.length > 0
      ? `${selectedOperatorNames.length} operador(es) no escopo`
      : "Todos os operadores";

  const items: ReportNarrativeItem[] = [
    {
      title: "Volume da semana",
      text:
        previous.totalDemandas > 0
          ? `O período fechou com ${current.totalDemandas} demanda(s), ${describeDelta(deltas.totalDemandas)} em relação ao recorte anterior.`
          : `O período atual reúne ${current.totalDemandas} demanda(s) e inaugura a primeira base comparável desse recorte.`,
      tone: deltas.totalDemandas.direction === "up" ? "warning" : "positive",
    },
    {
      title: "Eficiência operacional",
      text: `A taxa de fechamento ficou em ${formatPercent(current.taxaFechamento)}, com ${current.concluidas} concluída(s) e ${current.recusadas} recusada(s). Isso representa ${describeDelta(
        deltas.taxaFechamento,
        " percentual",
      )} sobre o período anterior.`,
      tone:
        current.taxaFechamento >= previous.taxaFechamento ? "positive" : "warning",
    },
    {
      title: "Direcionamento para a reunião",
      text: topHotspot
        ? `O principal foco está em ${topHotspot.label}${topHotspot.area ? `, dentro de ${topHotspot.area}` : ""}, enquanto ${topCategoria.total > 0 ? topCategoria.label : "as categorias ficaram sem dominância clara"}${topCategoria.total > 0 ? " segue como a categoria mais recorrente" : ""}. Escopo atual: ${operatorScopeLabel}.`
        : `Não houve concentração relevante por local exato no período. Escopo atual: ${operatorScopeLabel}.`,
      tone: "neutral",
    },
  ];

  if (current.backlogSemResponsavel > 0) {
    items.push({
      title: "Risco de fila sem dono",
      text: `${current.backlogSemResponsavel} demanda(s) ativa(s) seguem sem operador definido, afetando a cobertura de atribuição, hoje em ${formatPercent(
        current.coberturaAtribuicao,
      )}.`,
      tone: "warning",
    });
  }

  return items;
}

function buildReasons(
  current: ReportPeriodSummary,
  previous: ReportPeriodSummary,
  deltas: PerformanceReport["deltas"],
  hotspotRows: LocationPerformanceRow[],
  operatorRows: OperatorPerformanceRow[],
): ReportReason[] {
  const categoryDelta = getLargestChange(current.byCategoria, previous.byCategoria);
  const priorityDelta = getLargestChange(current.byPrioridade, previous.byPrioridade);
  const topHotspot = hotspotRows.find((row) => row.total > 0);
  const topOperator = operatorRows.find((row) => row.total > 0);

  return [
    {
      title:
        deltas.totalDemandas.direction === "up"
          ? "Aumento do volume"
          : deltas.totalDemandas.direction === "down"
            ? "Redução do volume"
            : "Volume estável",
      description:
        categoryDelta.delta !== 0
          ? `${categoryDelta.label} foi a maior alavanca do período, com variação de ${formatSignedValue(categoryDelta.delta)} demanda(s).`
          : "A distribuição por categoria ficou estável entre os dois recortes.",
      detail: topHotspot
        ? `${topHotspot.label} concentrou ${topHotspot.total} registro(s) no recorte atual.`
        : "Sem hotspot dominante por local exato.",
      tone: deltas.totalDemandas.direction === "up" ? "warning" : "positive",
    },
    {
      title: "Composição da fila",
      description:
        priorityDelta.delta !== 0
          ? `${priorityDelta.label} foi a prioridade que mais mudou, com ${formatSignedValue(priorityDelta.delta)} item(ns).`
          : "A composição por prioridade ficou equilibrada frente ao período anterior.",
      detail:
        current.backlogSemResponsavel > 0
          ? `${current.backlogSemResponsavel} demanda(s) ativa(s) seguem sem operador, pressionando a alocação.`
          : "Não há demandas ativas sem operador no recorte atual.",
      tone:
        current.backlogSemResponsavel > previous.backlogSemResponsavel
          ? "warning"
          : "neutral",
    },
    {
      title: "Capacidade do time",
      description: topOperator
        ? `${topOperator.nome} lidera o recorte com ${topOperator.total} demanda(s), taxa de fechamento de ${formatPercent(
            topOperator.taxaFechamento,
          )}.`
        : "Nenhum operador apareceu no recorte atual.",
      detail:
        current.totalHistorico > 0
          ? `Foram encerradas ${current.totalHistorico} demanda(s), sendo ${current.concluidas} concluída(s) e ${current.recusadas} recusada(s).`
          : "Ainda não houve encerramentos no período selecionado.",
      tone:
        deltas.totalHistorico.direction === "down" ? "warning" : "positive",
    },
  ];
}

function buildDelta(current: number, previous: number): MetricDelta {
  const absolute = current - previous;
  const direction =
    absolute > 0 ? "up" : absolute < 0 ? "down" : "stable";
  const percentage =
    previous === 0 ? (current === 0 ? 0 : null) : (absolute / previous) * 100;

  return {
    current,
    previous,
    absolute,
    percentage,
    direction,
  };
}

function formatKpiDelta(
  delta: MetricDelta,
  options: { percentageDigits?: number } = {},
): string {
  if (delta.direction === "stable") {
    return "Estável";
  }

  if (delta.percentage === null) {
    return "Base inicial";
  }

  const arrow = delta.direction === "up" ? "↑" : "↓";
  return `${arrow} ${formatPercent(Math.abs(delta.percentage), options.percentageDigits ?? 0)}`;
}

function getKpiTone(
  delta: MetricDelta,
  metricType: "volume" | "higher_better" | "lower_better",
): ReportTone {
  if (delta.direction === "stable") {
    return "neutral";
  }

  if (metricType === "volume") {
    return delta.direction === "up" ? "warning" : "positive";
  }

  if (metricType === "higher_better") {
    return delta.direction === "up" ? "positive" : "warning";
  }

  return delta.direction === "down" ? "positive" : "warning";
}

function createSeedCountMap(values: readonly string[]): Record<string, number> {
  return values.reduce<Record<string, number>>((accumulator, label) => {
    accumulator[label] = 0;
    return accumulator;
  }, {});
}

function getLargestChange(
  current: Record<string, number>,
  previous: Record<string, number>,
): { label: string; delta: number } {
  const labels = new Set([...Object.keys(current), ...Object.keys(previous)]);
  let best = { label: "-", delta: 0 };

  labels.forEach((label) => {
    const delta = (current[label] ?? 0) - (previous[label] ?? 0);
    if (Math.abs(delta) > Math.abs(best.delta)) {
      best = { label, delta };
    }
  });

  return best;
}

function getTopEntry(values: Record<string, number>): { label: string; total: number } {
  const [label = "-", total = 0] =
    Object.entries(values).sort((left, right) => {
      if (right[1] !== left[1]) {
        return right[1] - left[1];
      }

      return left[0].localeCompare(right[0], "pt-BR");
    })[0] ?? [];

  if (total <= 0) {
    return { label: "-", total: 0 };
  }

  return { label, total };
}

function describeDelta(delta: MetricDelta, suffix = ""): string {
  if (delta.direction === "stable") {
    return `sem variação${suffix}`;
  }

  if (delta.percentage === null) {
    return `${formatSignedValue(delta.absolute)}${suffix}`;
  }

  return `${delta.direction === "up" ? "a mais" : "a menos"} em ${formatPercent(
    Math.abs(delta.percentage),
  )}${suffix}`;
}

function formatSignedValue(value: number): string {
  return `${value > 0 ? "+" : value < 0 ? "-" : ""}${Math.abs(value)}`;
}

function formatCompactSignedValue(
  value: number,
  maximumFractionDigits = 0,
): string {
  const formatted = new Intl.NumberFormat("pt-BR", {
    minimumFractionDigits: 0,
    maximumFractionDigits,
  }).format(Math.abs(value));

  return `${value > 0 ? "+" : value < 0 ? "-" : ""}${formatted}`;
}

function formatCompactSignedInteger(value: number): string {
  return `${value > 0 ? "+" : value < 0 ? "-" : ""}${Math.abs(Math.round(value))}`;
}

function buildSuggestedAction(
  attentionKey: string | undefined,
  topHotspot?: LocationPerformanceRow,
): string {
  if (attentionKey === "backlog") {
    return "Atribuir a fila sem dono e revisar a triagem";
  }

  if (attentionKey === "priority") {
    return topHotspot
      ? `Priorizar ${buildShortLabel(topHotspot.label, 22)} na próxima janela`
      : "Priorizar a fila crítica e alta do período";
  }

  if (attentionKey === "hotspot" && topHotspot) {
    return `Atacar a causa recorrente em ${buildShortLabel(topHotspot.label, 24)}`;
  }

  return "Manter a cadência e reavaliar o próximo recorte";
}

function buildShortLabel(value: string, maxLength: number): string {
  const normalized = value.trim().replace(/\s+/g, " ");
  if (normalized.length <= maxLength) {
    return normalized;
  }

  return `${normalized.slice(0, Math.max(0, maxLength - 1)).trimEnd()}…`;
}

function normalizeOperatorName(value: string): string {
  const cleaned = value.trim();
  return cleaned || UNASSIGNED_OPERATOR;
}

function parseInputDate(value: string): Date {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(year, (month || 1) - 1, day || 1);
}

function formatInputDate(value: Date): string {
  const year = value.getFullYear();
  const month = String(value.getMonth() + 1).padStart(2, "0");
  const day = String(value.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatPeriodLabel(startDate: string, endDate: string): string {
  const formatter = new Intl.DateTimeFormat("pt-BR");
  return `${formatter.format(parseInputDate(startDate))} a ${formatter.format(
    parseInputDate(endDate),
  )}`;
}

function getPeriodDays(startDate: string, endDate: string): number {
  const start = startOfDay(parseInputDate(startDate)).getTime();
  const end = startOfDay(parseInputDate(endDate)).getTime();
  return Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);
}

function addDays(value: Date, amount: number): Date {
  const next = new Date(value);
  next.setDate(next.getDate() + amount);
  return next;
}

function startOfDay(value: Date): Date {
  return new Date(
    value.getFullYear(),
    value.getMonth(),
    value.getDate(),
    0,
    0,
    0,
    0,
  );
}

function endOfDay(value: Date): Date {
  return new Date(
    value.getFullYear(),
    value.getMonth(),
    value.getDate(),
    23,
    59,
    59,
    999,
  );
}

function stripTime(value: Date): Date {
  return new Date(value.getFullYear(), value.getMonth(), value.getDate());
}

function getLatestDemandDate(demandas: NormalizedDemanda[]): Date | null {
  const timestamps = demandas
    .map((demanda) => getDemandTimestamp(demanda))
    .filter((value): value is number => value > 0);

  if (timestamps.length === 0) {
    return null;
  }

  return new Date(Math.max(...timestamps));
}

function getDemandTimestamp(demanda: NormalizedDemanda): number {
  const raw = demanda.dataDaRequisicao || demanda.data;
  if (!raw) {
    return 0;
  }

  const nativeDate = new Date(raw);
  if (!Number.isNaN(nativeDate.getTime())) {
    return nativeDate.getTime();
  }

  const brMatch = raw.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:[ T,](\d{1,2}):(\d{2})(?::(\d{2}))?)?/,
  );
  if (!brMatch) {
    return 0;
  }

  const [, day, month, year, hour = "0", minute = "0", second = "0"] = brMatch;
  const parsed = new Date(
    Number(year),
    Number(month) - 1,
    Number(day),
    Number(hour),
    Number(minute),
    Number(second),
  );

  return Number.isNaN(parsed.getTime()) ? 0 : parsed.getTime();
}
