import { toast } from "@/hooks/use-toast";
import { diagnosticarPlacarApi } from "./placarApiDiagnostic";

export async function rodarDiagnosticoPlacarApi(url: string): Promise<void> {
  try {
    toast({
      title: "Diagnóstico iniciado",
      description: "Testando conexão com a API do Placar...",
    });

    const resultado = await diagnosticarPlacarApi(url);

    console.group("Diagnóstico da API do Placar DeConta");
    console.log("Resultado completo:", resultado);
    console.groupEnd();

    if (resultado.sucesso) {
      toast({
        title: "Diagnóstico concluído",
        description: `API funcionando! ${resultado.mensagem}`,
      });
    } else {
      toast({
        title: "Erro no diagnóstico",
        description: resultado.mensagem,
        variant: "destructive",
      });
    }
  } catch (error) {
    console.error("Erro no diagnóstico da API:", error);
    toast({
      title: "Erro no diagnóstico",
      description: error instanceof Error ? error.message : "Erro desconhecido",
      variant: "destructive",
    });
  }
}
