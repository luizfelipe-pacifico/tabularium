export type PlacarApiDiagnosticResult = {
  ok: boolean;
  step: string;
  url: string;
  httpStatus?: number;
  statusText?: string;
  redirected?: boolean;
  finalUrl?: string;
  contentType?: string | null;
  rawPreview?: string;
  parsedJsonPreview?: unknown;
  errorMessage?: string;
  errorStack?: string;
  timestamp: string;
};

export async function diagnosticarPlacarApi(url: string): Promise<PlacarApiDiagnosticResult> {
  const timestamp = new Date().toISOString();

  try {
    if (!url || !url.trim()) {
      return {
        ok: false,
        step: "validacao_url",
        url,
        errorMessage: "URL da API não informada.",
        timestamp,
      };
    }

    const response = await fetch(url, {
      method: "GET",
      redirect: "follow",
      headers: {
        Accept: "application/json, text/plain, */*",
      },
    });

    const contentType = response.headers.get("content-type");
    const rawText = await response.text();
    const rawPreview = rawText.slice(0, 1500);

    if (!response.ok) {
      return {
        ok: false,
        step: "http_response",
        url,
        httpStatus: response.status,
        statusText: response.statusText,
        redirected: response.redirected,
        finalUrl: response.url,
        contentType,
        rawPreview,
        errorMessage: `Resposta HTTP inválida: ${response.status} ${response.statusText}`,
        timestamp,
      };
    }

    let parsed: unknown = null;

    try {
      parsed = JSON.parse(rawText);
    } catch (parseError) {
      return {
        ok: false,
        step: "json_parse",
        url,
        httpStatus: response.status,
        statusText: response.statusText,
        redirected: response.redirected,
        finalUrl: response.url,
        contentType,
        rawPreview,
        errorMessage: parseError instanceof Error ? parseError.message : "Falha ao converter resposta em JSON.",
        errorStack: parseError instanceof Error ? parseError.stack : undefined,
        timestamp,
      };
    }

    const jsonObj = parsed as Record<string, unknown>;

    return {
      ok: true,
      step: "sucesso",
      url,
      httpStatus: response.status,
      statusText: response.statusText,
      redirected: response.redirected,
      finalUrl: response.url,
      contentType,
      rawPreview,
      parsedJsonPreview: {
        success: jsonObj?.success,
        generatedAt: jsonObj?.generatedAt,
        keys: typeof parsed === "object" && parsed !== null ? Object.keys(jsonObj) : [],
        totais: jsonObj?.totais,
      },
      timestamp,
    };
  } catch (error) {
    return {
      ok: false,
      step: "fetch_exception",
      url,
      errorMessage: error instanceof Error ? error.message : "Erro desconhecido no fetch.",
      errorStack: error instanceof Error ? error.stack : undefined,
      timestamp,
    };
  }
}