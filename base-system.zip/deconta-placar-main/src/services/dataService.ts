import { createEmptyAppData, type AppData } from "@/lib/app-data";

export async function fetchData(): Promise<AppData> {
  if (!window.electronAPI?.fetchData) {
    return createEmptyAppData({
      sourceStatus: {
        mode: "fallback",
        message: "Integração com o Electron indisponível. Exibindo estrutura zerada.",
        error: null,
      },
    });
  }

  try {
    return await window.electronAPI.fetchData();
  } catch (error) {
    return createEmptyAppData({
      sourceStatus: {
        mode: "fallback",
        message: "Falha ao carregar dados. Exibindo estrutura zerada.",
        error: error instanceof Error ? error.message : String(error),
      },
    });
  }
}

export async function syncNow(): Promise<AppData> {
  if (!window.electronAPI?.syncNow) {
    return createEmptyAppData({
      sourceStatus: {
        mode: "fallback",
        message: "Sincronização indisponível fora do Electron.",
        error: null,
      },
    });
  }

  try {
    return await window.electronAPI.syncNow();
  } catch (error) {
    return createEmptyAppData({
      sourceStatus: {
        mode: "fallback",
        message: "Falha ao sincronizar. Exibindo estrutura zerada.",
        error: error instanceof Error ? error.message : String(error),
      },
    });
  }
}
