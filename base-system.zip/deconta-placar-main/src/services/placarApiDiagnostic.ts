interface DiagnosticoResultado {
  sucesso: boolean;
  mensagem: string;
  detalhes?: any;
}

export async function diagnosticarPlacarApi(url: string): Promise<DiagnosticoResultado> {
  try {
    const response = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
      },
    });

    if (!response.ok) {
      return {
        sucesso: false,
        mensagem: `Erro HTTP ${response.status}: ${response.statusText}`,
      };
    }

    const data = await response.json();

    if (!data.success) {
      return {
        sucesso: false,
        mensagem: "API retornou success: false",
        detalhes: data,
      };
    }

    const totalDemandas = data.demandas?.length || 0;
    const totalAtivasExplicitas = data.demandasAtivas?.length || 0;
    const totalHistoricoExplicito = data.demandasHistorico?.length || 0;
    const totalUltimas = data.ultimasDemandas?.length || 0;
    const demandas = Array.isArray(data.demandas) ? data.demandas : [];
    const totalAtivasDerivado = demandas.filter((item) => getDemandBucket(item) === "controle").length;
    const totalHistoricoDerivado = demandas.filter((item) => getDemandBucket(item) === "historico").length;
    const totalAtivas = totalAtivasExplicitas > 0 ? totalAtivasExplicitas : totalAtivasDerivado;
    const totalHistorico =
      totalHistoricoExplicito > 0 ? totalHistoricoExplicito : totalHistoricoDerivado;
    const payloadParcial =
      totalUltimas > 0 &&
      totalAtivas === 0 &&
      totalHistorico === 0 &&
      totalDemandas === 0;

    if (payloadParcial) {
      return {
        sucesso: false,
        mensagem:
          "API respondeu parcialmente: só ultimasDemandas veio preenchido. Totais e listas estruturadas vieram zerados.",
        detalhes: {
          totalDemandas,
          totalAtivas,
          totalHistorico,
          totalUltimas,
          totalAtivasExplicitas,
          totalHistoricoExplicito,
          generatedAt: data.generatedAt,
        },
      };
    }

    return {
      sucesso: true,
      mensagem: `Demandas: ${totalDemandas}, Ativas: ${totalAtivas}, Histórico: ${totalHistorico}, Últimas: ${totalUltimas}`,
      detalhes: {
        totalDemandas,
        totalAtivas,
        totalHistorico,
        totalUltimas,
        totalAtivasExplicitas,
        totalHistoricoExplicito,
        generatedAt: data.generatedAt,
      },
    };
  } catch (error) {
    return {
      sucesso: false,
      mensagem: error instanceof Error ? error.message : "Erro desconhecido",
    };
  }
}

function getDemandBucket(item: any): "controle" | "historico" | "unknown" {
  const aba = normalizeToken(item?.aba ?? item?.sheetName ?? item?.sheet ?? "");
  if (aba === "controle") {
    return "controle";
  }

  if (aba === "historico") {
    return "historico";
  }

  const status = normalizeToken(
    item?.status ?? item?.statusDaDemanda ?? item?.sTATUSDADEMANDA ?? "",
  );
  if (status.includes("concluida") || status.includes("recusada")) {
    return "historico";
  }

  if (status.includes("emaberto") || status.includes("emandamento")) {
    return "controle";
  }

  return "unknown";
}

function normalizeToken(value: unknown): string {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\w\s]/g, "")
    .toLowerCase()
    .replace(/\s+/g, "");
}
