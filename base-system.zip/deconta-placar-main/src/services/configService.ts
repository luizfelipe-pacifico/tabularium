import type { AppConfig } from "@/lib/app-data";

export interface SourceConnectionResult {
  ok: boolean;
  status: number | null;
  error?: string | null;
}

export const DEFAULT_SOURCE_URL =
  "https://script.google.com/macros/s/AKfycbzfkXYf6mzOOLRhCbQfB8gS7DVWpPNQf-GGiSGd3gJTjOcyJS6FJ_AXCTO9iYh_UJk/exec";

const DEFAULT_LOCAL_CONFIG: AppConfig = {
  fonteUrl: DEFAULT_SOURCE_URL,
  intervalo: 5,
  emailAlerta: "",
  nomeAmbiente: "",
  tema: "dark",
  ultimaSincronizacao: null,
  zoomLevel: 100,
  sidebarCollapsed: false,
  devProfiles: [],
};

function normalizeSourceUrl(input?: string | null): string {
  if (typeof input !== "string") {
    return DEFAULT_SOURCE_URL;
  }

  const trimmed = input.trim();
  if (!trimmed) {
    return DEFAULT_SOURCE_URL;
  }

  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      return DEFAULT_SOURCE_URL;
    }

    return parsed.toString();
  } catch {
    return DEFAULT_SOURCE_URL;
  }
}

function normalizeConfig(config?: Partial<AppConfig> | null): AppConfig {
  return {
    ...DEFAULT_LOCAL_CONFIG,
    ...config,
    fonteUrl: normalizeSourceUrl(config?.fonteUrl),
  };
}

export async function loadConfig(): Promise<AppConfig> {
  if (!window.electronAPI?.getConfig) {
    return DEFAULT_LOCAL_CONFIG;
  }

  return normalizeConfig(await window.electronAPI.getConfig());
}

export async function saveConfig(
  config: Partial<AppConfig>,
): Promise<AppConfig> {
  if (!window.electronAPI?.setConfig) {
    return normalizeConfig(config);
  }

  return normalizeConfig(
    await window.electronAPI.setConfig(config),
  );
}

export async function testConnection(
  url: string,
): Promise<SourceConnectionResult> {
  const targetUrl = normalizeSourceUrl(url);

  if (window.electronAPI?.testSourceUrl) {
    return window.electronAPI.testSourceUrl(targetUrl);
  }

  try {
    const response = await fetch(targetUrl, {
      method: "GET",
      cache: "no-store",
      headers: {
        Accept: "application/json",
      },
    });
    const text = (await response.text()).trim();

    if (!response.ok) {
      return {
        ok: false,
        status: response.status,
        error: "Falha ao acessar a fonte remota.",
      };
    }

    if (!text) {
      return {
        ok: false,
        status: response.status,
        error: "A fonte remota retornou conteúdo vazio.",
      };
    }

    if (text.startsWith("<")) {
      return {
        ok: false,
        status: response.status,
        error: "A fonte remota retornou HTML em vez de JSON.",
      };
    }

    try {
      JSON.parse(text);
    } catch {
      return {
        ok: false,
        status: response.status,
        error: "A fonte remota retornou JSON inválido.",
      };
    }

    return {
      ok: true,
      status: response.status,
      error: null,
    };
  } catch (error) {
    return {
      ok: false,
      status: null,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}
