"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_THEME = exports.DEFAULT_ZOOM_LEVEL = exports.DEFAULT_SYNC_INTERVAL_MINUTES = exports.DEFAULT_SOURCE_URL = void 0;
exports.normalizeSourceUrl = normalizeSourceUrl;
exports.normalizeAppConfig = normalizeAppConfig;
exports.loadAppConfig = loadAppConfig;
exports.saveAppConfig = saveAppConfig;
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const db_js_1 = require("./db.js");
const DISTRIBUTION_CONFIG_PATH = path_1.default.join(__dirname, "distribution-config.json");
const SHARED_CONFIG_REVISION_KEY = "appSharedRevision";
exports.DEFAULT_SOURCE_URL = "https://script.google.com/macros/s/AKfycbzfkXYf6mzOOLRhCbQfB8gS7DVWpPNQf-GGiSGd3gJTjOcyJS6FJ_AXCTO9iYh_UJk/exec";
exports.DEFAULT_SYNC_INTERVAL_MINUTES = 5;
exports.DEFAULT_ZOOM_LEVEL = 100;
exports.DEFAULT_THEME = "dark";
function normalizeSourceUrl(input) {
    if (typeof input !== "string") {
        return exports.DEFAULT_SOURCE_URL;
    }
    const trimmed = input.trim();
    if (!trimmed) {
        return exports.DEFAULT_SOURCE_URL;
    }
    try {
        const parsed = new URL(trimmed);
        if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
            return exports.DEFAULT_SOURCE_URL;
        }
        return parsed.toString();
    }
    catch {
        return exports.DEFAULT_SOURCE_URL;
    }
}
function normalizeDevProfiles(input) {
    if (!Array.isArray(input)) {
        return [];
    }
    const normalized = [];
    for (const item of input) {
        if (!item || typeof item !== "object") {
            continue;
        }
        const raw = item;
        const nome = typeof raw.nome === "string" && raw.nome.trim().length > 0
            ? raw.nome.trim()
            : "";
        const email = typeof raw.email === "string" && raw.email.trim().length > 0
            ? raw.email.trim()
            : "";
        if (!nome) {
            continue;
        }
        normalized.push({
            nome,
            email,
            fotoUrl: typeof raw.fotoUrl === "string" && raw.fotoUrl.trim().length > 0
                ? raw.fotoUrl.trim()
                : "",
            cargo: typeof raw.cargo === "string" && raw.cargo.trim().length > 0
                ? raw.cargo.trim()
                : "Desenvolvedor",
        });
    }
    return normalized;
}
function pickLocalPreferences(input) {
    if (!input || typeof input !== "object") {
        return {};
    }
    return {
        ultimaSincronizacao: typeof input.ultimaSincronizacao === "string"
            ? input.ultimaSincronizacao
            : null,
        zoomLevel: typeof input.zoomLevel === "number" ? Math.round(input.zoomLevel) : undefined,
        sidebarCollapsed: Boolean(input.sidebarCollapsed),
        tema: typeof input.tema === "string" ? input.tema : exports.DEFAULT_THEME,
    };
}
function mergeBundledConfig(stored, bundled) {
    return normalizeAppConfig({
        ...stored,
        ...bundled,
        ...pickLocalPreferences(stored),
    });
}
async function loadDistributionConfig() {
    try {
        const raw = await promises_1.default.readFile(DISTRIBUTION_CONFIG_PATH, "utf8");
        const parsed = JSON.parse(raw);
        return {
            revision: typeof parsed.revision === "string" && parsed.revision.trim().length > 0
                ? parsed.revision.trim()
                : undefined,
            config: parsed.config && typeof parsed.config === "object" ? parsed.config : null,
        };
    }
    catch {
        return {};
    }
}
function normalizeAppConfig(input) {
    const raw = input ?? {};
    const fonteUrl = normalizeSourceUrl(raw.fonteUrl);
    const intervaloValue = typeof raw.intervalo === "number"
        ? raw.intervalo
        : Number(raw.intervalo ?? exports.DEFAULT_SYNC_INTERVAL_MINUTES);
    const intervalo = Number.isFinite(intervaloValue) && intervaloValue > 0
        ? intervaloValue
        : exports.DEFAULT_SYNC_INTERVAL_MINUTES;
    const zoomValue = typeof raw.zoomLevel === "number"
        ? raw.zoomLevel
        : Number(raw.zoomLevel ?? exports.DEFAULT_ZOOM_LEVEL);
    const zoomLevel = Number.isFinite(zoomValue) && zoomValue >= 70 && zoomValue <= 130
        ? Math.round(zoomValue)
        : exports.DEFAULT_ZOOM_LEVEL;
    return {
        fonteUrl,
        intervalo,
        emailAlerta: typeof raw.emailAlerta === "string" ? raw.emailAlerta : "",
        nomeAmbiente: typeof raw.nomeAmbiente === "string" && raw.nomeAmbiente.trim().length > 0
            ? raw.nomeAmbiente.trim()
            : "Produção",
        tema: exports.DEFAULT_THEME,
        ultimaSincronizacao: typeof raw.ultimaSincronizacao === "string"
            ? raw.ultimaSincronizacao
            : null,
        zoomLevel,
        sidebarCollapsed: Boolean(raw.sidebarCollapsed),
        devProfiles: normalizeDevProfiles(raw.devProfiles),
    };
}
async function loadAppConfig() {
    const [stored, importedRevision, distributionConfig] = await Promise.all([
        (0, db_js_1.getConfig)("app"),
        (0, db_js_1.getConfig)(SHARED_CONFIG_REVISION_KEY),
        loadDistributionConfig(),
    ]);
    const bundledRevision = typeof distributionConfig.revision === "string"
        ? distributionConfig.revision
        : null;
    const bundledConfig = distributionConfig.config;
    const storedRevision = typeof importedRevision === "string" ? importedRevision : null;
    if (!stored) {
        const seededConfig = normalizeAppConfig(bundledConfig);
        await (0, db_js_1.setConfig)("app", seededConfig);
        if (bundledRevision) {
            await (0, db_js_1.setConfig)(SHARED_CONFIG_REVISION_KEY, bundledRevision);
        }
        return seededConfig;
    }
    if (bundledConfig && bundledRevision && bundledRevision !== storedRevision) {
        const mergedConfig = mergeBundledConfig(stored, bundledConfig);
        await (0, db_js_1.setConfig)("app", mergedConfig);
        await (0, db_js_1.setConfig)(SHARED_CONFIG_REVISION_KEY, bundledRevision);
        return mergedConfig;
    }
    return normalizeAppConfig(stored);
}
async function saveAppConfig(nextConfig) {
    const current = await loadAppConfig();
    const normalized = normalizeAppConfig({
        ...current,
        ...nextConfig,
    });
    await (0, db_js_1.setConfig)("app", normalized);
    return normalized;
}
