"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const promises_1 = __importDefault(require("fs/promises"));
const path_1 = __importDefault(require("path"));
const electron_1 = require("electron");
const sheetService_js_1 = require("./sheetService.js");
let mainWindow = null;
let syncTimer = null;
function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1200,
        height: 800,
        show: false,
        webPreferences: {
            preload: path_1.default.join(__dirname, "preload.js"),
            contextIsolation: true,
            nodeIntegration: false,
        },
    });
    const devUrl = process.env.VITE_DEV_SERVER_URL;
    const useDevServer = Boolean(devUrl);
    if (useDevServer && devUrl) {
        mainWindow.loadURL(devUrl);
        mainWindow.webContents.openDevTools({ mode: "detach" });
    }
    else {
        mainWindow.loadFile(path_1.default.join(__dirname, "../dist/index.html"));
    }
    mainWindow.once("ready-to-show", () => {
        mainWindow?.show();
    });
    mainWindow.webContents.on("did-fail-load", (_event, errorCode, errorDescription, validatedURL) => {
        console.error("[electron] failed to load", {
            errorCode,
            errorDescription,
            validatedURL,
        });
    });
    mainWindow.on("closed", () => {
        mainWindow = null;
    });
}
function notifyUpdate(data) {
    if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("data-updated", data);
    }
}
async function fetchAndNotify() {
    const data = await (0, sheetService_js_1.fetchFromSheet)();
    notifyUpdate(data);
    return data;
}
async function scheduleSync() {
    const config = await (0, sheetService_js_1.getCurrentConfig)();
    if (syncTimer) {
        clearInterval(syncTimer);
        syncTimer = null;
    }
    const intervalMinutes = Math.max(1, config.intervalo || 1);
    fetchAndNotify().catch((error) => {
        console.error("[electron] initial sync failed", error);
    });
    syncTimer = setInterval(() => {
        fetchAndNotify().catch((error) => {
            console.error("[electron] scheduled sync failed", error);
        });
    }, intervalMinutes * 60 * 1000);
}
async function saveReportPdf(payload) {
    const html = payload.html?.trim();
    if (!html) {
        throw new Error("O relatório em HTML não foi informado.");
    }
    const defaultFileName = sanitizePdfFileName(payload.fileName);
    const defaultPath = path_1.default.join(electron_1.app.getPath("documents"), defaultFileName);
    const saveDialogOptions = {
        defaultPath,
        filters: [{ name: "PDF", extensions: ["pdf"] }],
    };
    const saveResult = mainWindow
        ? await electron_1.dialog.showSaveDialog(mainWindow, saveDialogOptions)
        : await electron_1.dialog.showSaveDialog(saveDialogOptions);
    if (saveResult.canceled || !saveResult.filePath) {
        return {
            canceled: true,
            filePath: null,
        };
    }
    const reportWindow = new electron_1.BrowserWindow({
        show: false,
        backgroundColor: "#07111d",
    });
    try {
        await reportWindow.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(html)}`);
        const pdfBuffer = await reportWindow.webContents.printToPDF({
            printBackground: true,
            landscape: false,
            pageSize: "A4",
            margins: {
                top: 0,
                bottom: 0,
                left: 0,
                right: 0,
            },
        });
        await promises_1.default.writeFile(saveResult.filePath, pdfBuffer);
        return {
            canceled: false,
            filePath: saveResult.filePath,
        };
    }
    finally {
        if (!reportWindow.isDestroyed()) {
            reportWindow.destroy();
        }
    }
}
function registerIpcHandlers() {
    electron_1.ipcMain.handle("get-config", async () => (0, sheetService_js_1.getCurrentConfig)());
    electron_1.ipcMain.handle("set-config", async (_event, config) => {
        const savedConfig = await (0, sheetService_js_1.updateConfig)(config);
        await scheduleSync();
        return savedConfig;
    });
    electron_1.ipcMain.handle("test-source-url", async (_event, url) => {
        return (0, sheetService_js_1.testSourceConnection)(url);
    });
    electron_1.ipcMain.handle("fetch-data", async () => (0, sheetService_js_1.fetchFromSheet)());
    electron_1.ipcMain.handle("sync-now", fetchAndNotify);
    electron_1.ipcMain.handle("save-report-pdf", async (_event, payload) => saveReportPdf(payload));
    electron_1.ipcMain.handle("reload-app", () => {
        if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.reloadIgnoringCache();
        }
    });
    electron_1.ipcMain.handle("app-quit", () => {
        electron_1.app.quit();
    });
}
electron_1.app.whenReady().then(async () => {
    createWindow();
    registerIpcHandlers();
    await (0, sheetService_js_1.getCurrentConfig)();
    await scheduleSync();
    electron_1.app.on("activate", () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});
electron_1.app.on("window-all-closed", () => {
    if (syncTimer) {
        clearInterval(syncTimer);
        syncTimer = null;
    }
    if (process.platform !== "darwin") {
        electron_1.app.quit();
    }
});
function sanitizePdfFileName(value) {
    const baseName = (value || "relatorio-performance.pdf")
        .replace(/[<>:"/\\|?*\u0000-\u001F]/g, "-")
        .trim();
    if (!baseName) {
        return "relatorio-performance.pdf";
    }
    return baseName.toLowerCase().endsWith(".pdf") ? baseName : `${baseName}.pdf`;
}
