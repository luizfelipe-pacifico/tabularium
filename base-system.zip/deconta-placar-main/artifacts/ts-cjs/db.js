"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initDatabase = void 0;
exports.getConfig = getConfig;
exports.setConfig = setConfig;
exports.getCache = getCache;
exports.setCache = setCache;
exports.log = log;
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const electron_1 = require("electron");
const sql_js_1 = __importDefault(require("sql.js"));
let db = null;
let dbPath = "";
let isInitialized = false;
const initDb = async () => {
    if (isInitialized)
        return;
    dbPath = path_1.default.join(electron_1.app.getPath("userData"), "deconta.db");
    const SQL = await (0, sql_js_1.default)();
    try {
        if (fs_1.default.existsSync(dbPath)) {
            const buffer = fs_1.default.readFileSync(dbPath);
            db = new SQL.Database(buffer);
        }
        else {
            db = new SQL.Database();
        }
    }
    catch {
        db = new SQL.Database();
    }
    // initialize tables
    if (db) {
        db.run(`
      CREATE TABLE IF NOT EXISTS config (
        key TEXT PRIMARY KEY,
        value TEXT
      );
      CREATE TABLE IF NOT EXISTS cache (
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at INTEGER
      );
      CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        message TEXT,
        level TEXT,
        timestamp INTEGER
      );
    `);
        saveDb();
    }
    isInitialized = true;
};
exports.initDatabase = initDb;
const saveDb = () => {
    if (db && dbPath) {
        try {
            const data = db.export();
            const buffer = Buffer.from(data);
            fs_1.default.writeFileSync(dbPath, buffer);
        }
        catch (e) {
            console.error("Failed to save database:", e);
        }
    }
};
async function getConfig(key) {
    if (!db)
        await initDb();
    if (!db)
        return null;
    try {
        const stmt = db.prepare("SELECT value FROM config WHERE key = ?");
        stmt.bind([key]);
        if (stmt.step()) {
            const row = stmt.getAsObject();
            stmt.free();
            const val = row.value;
            return val ? JSON.parse(val) : null;
        }
        stmt.free();
    }
    catch {
        // ignore
    }
    return null;
}
async function setConfig(key, value) {
    if (!db)
        await initDb();
    if (!db)
        return;
    try {
        const str = JSON.stringify(value);
        db.run("INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)", [key, str]);
        saveDb();
    }
    catch (e) {
        console.error("Failed to set config:", e);
    }
}
async function getCache(key) {
    if (!db)
        await initDb();
    if (!db)
        return null;
    try {
        const stmt = db.prepare("SELECT value FROM cache WHERE key = ?");
        stmt.bind([key]);
        if (stmt.step()) {
            const row = stmt.getAsObject();
            stmt.free();
            const val = row.value;
            return val ? JSON.parse(val) : null;
        }
        stmt.free();
    }
    catch {
        // ignore
    }
    return null;
}
async function setCache(key, value) {
    if (!db)
        await initDb();
    if (!db)
        return;
    try {
        const str = JSON.stringify(value);
        const now = Date.now();
        db.run("INSERT OR REPLACE INTO cache (key, value, updated_at) VALUES (?, ?, ?)", [key, str, now]);
        saveDb();
    }
    catch (e) {
        console.error("Failed to set cache:", e);
    }
}
async function log(message, level = "info") {
    if (!db)
        await initDb();
    if (!db)
        return;
    try {
        const ts = Date.now();
        db.run("INSERT INTO logs (message, level, timestamp) VALUES (?, ?, ?)", [message, level, ts]);
        saveDb();
    }
    catch (e) {
        console.error("Failed to log:", e);
    }
}
