# Placar DeConta (Electron)

Painel operacional desktop para leitura de demandas do Google Sheets.

> Guia dedicado para gerar o executavel manualmente:
> [README-GERAR-EXECUTAVEL.md](README-GERAR-EXECUTAVEL.md)

Este repositorio contem uma aplicacao React + Vite que roda dentro de um
container Electron. Ela foi projetada para ser instalada como um programa
Windows (`.exe`) e se conecta a planilhas do Google por um endpoint JSON
definido pelo usuario. Os dados sao cacheados localmente em SQLite e a
sincronizacao e automatica.

## Tecnologias

- Electron (main, preload, renderer)
- React + TypeScript (Vite)
- Tailwind CSS + Radix UI para a interface
- better-sqlite3 para cache/configuracao local
- Axios para requisicoes HTTP
- React Query para gerenciamento de estado de dados

## Executando em desenvolvimento

```bash
npm install
npm run electron:dev
```

O comando acima executa o servidor Vite, compila os scripts do Electron e
abre a janela do aplicativo. A cada modificacao no codigo do renderer ou no
codigo do Electron, o processo recarrega automaticamente.

> **Nota:** caso prefira apenas ver a interface no navegador, use
> `npm run dev`; porem `window.electronAPI` ficara indefinido e algumas
> funcionalidades (configuracoes, sincronizacao) nao funcionarao.

## Construindo um instalador Windows

```bash
npm run build
npm run dist
```

O arquivo resultante ficara em `dist_electron` e pode ser distribuido para
usuarios Windows.

## Configuracao / Fonte de dados

Abra o menu lateral e acesse **Configuracoes**.

- **URL / Caminho da fonte**: endpoint que deve retornar JSON com
  `demandas` e, opcionalmente, `operadores`.
- **Intervalo de atualizacao**: em minutos.
- **Tema**, **nome do ambiente**, **e-mail de alerta** e outras preferencias.

O proprio aplicativo mantem um cache SQLite com a ultima leitura e grava as
configuracoes no mesmo banco, localizado em `%APPDATA%\\PlacarDeConta`.

A forma mais simples de gerar o endpoint e publicar um Apps Script no Google
Sheets que retorne os dados em JSON. A aplicacao nao modifica a planilha;
ela apenas consome os dados.

### Exemplo de estrutura esperada

```json
{
  "demandas": [
    { "id": "DC-1001", "data": "2026-03-12", "categoria": "Bug leve" }
  ],
  "operadores": [{ "nome": "Luiz", "avatar": "L" }]
}
```

O servico interno calcula estatisticas de distribuicao e as entrega ao
renderer, que monta os graficos e tabelas.

## Principais caracteristicas

- Dashboard principal sem scroll vertical
- Tabelas filtraveis de demandas ativas e historico
- Visao por operador
- Configuracoes persistentes e teste de conexao
- Botao "Atualizar agora" funcional e notificacao de sincronizacao
- Fallback offline automatico usando cache SQLite
- Tema escuro e identidade visual da DeConta

## Execucao fora do Electron

Embora seja possivel rodar apenas o frontend (`npm run dev`), o app foi
projetado para funcionar dentro de um container Electron. O codigo de
backend (sincronizacao, banco de dados e IPC) so existe no processo principal
e no preload.

## Proximos passos / placeholders

- A rotina de obtencao de dados presume que o endpoint retorna um JSON
  compativel; personalizacoes podem ser feitas em `electron/sheetService.ts`.
- A estrutura ja permite adicionar novos graficos.
- Logs basicos sao registrados em SQLite e podem ser exportados.
