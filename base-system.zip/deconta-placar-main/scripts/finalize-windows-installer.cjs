const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const outputDir = path.join(__dirname, "..", "dist_electron");
const finalPackageName = "Placar DeConta.zip";

main();

function main() {
  if (!fs.existsSync(outputDir)) {
    throw new Error(`Diretorio de saida nao encontrado: ${outputDir}`);
  }

  const entries = fs.readdirSync(outputDir, { withFileTypes: true });
  const zipEntries = entries.filter(
    (entry) => entry.isFile() && entry.name.toLowerCase().endsWith(".zip"),
  );
  const candidateEntries =
    zipEntries.filter((entry) => entry.name !== finalPackageName).length > 0
      ? zipEntries.filter((entry) => entry.name !== finalPackageName)
      : zipEntries;
  const packageEntry = candidateEntries.sort((left, right) => {
    const leftPath = path.join(outputDir, left.name);
    const rightPath = path.join(outputDir, right.name);

    return fs.statSync(rightPath).mtimeMs - fs.statSync(leftPath).mtimeMs;
  })[0];

  if (!packageEntry) {
    throw new Error("Nenhum pacote .zip foi encontrado em dist_electron.");
  }

  const currentPackagePath = path.join(outputDir, packageEntry.name);
  const finalPackagePath = path.join(outputDir, finalPackageName);

  if (packageEntry.name !== finalPackageName) {
    if (fs.existsSync(finalPackagePath)) {
      fs.rmSync(finalPackagePath, { force: true });
    }

    fs.renameSync(currentPackagePath, finalPackagePath);
  }

  for (const entry of fs.readdirSync(outputDir, { withFileTypes: true })) {
    if (entry.name === finalPackageName) {
      continue;
    }

    const targetPath = path.join(outputDir, entry.name);

    if (entry.isDirectory()) {
      const result = spawnSync("cmd.exe", ["/c", "rmdir", "/s", "/q", targetPath], {
        stdio: "inherit",
      });

      if (result.status !== 0) {
        throw new Error(`Nao foi possivel remover ${targetPath}`);
      }

      continue;
    }

    fs.unlinkSync(targetPath);
  }

  console.log(`[package] Pacote final pronto em ${finalPackagePath}`);
}
