const { spawn } = require("child_process");

const args = process.argv.slice(2);
const env = {
  ...process.env,
  VITE_DEV_SERVER_URL: process.env.VITE_DEV_SERVER_URL || "http://localhost:5173",
};

const child = spawn(process.execPath, ["scripts/launch-electron.cjs", ...args], {
  stdio: "inherit",
  env,
  windowsHide: false,
});

child.on("exit", (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }

  process.exit(code ?? 0);
});
