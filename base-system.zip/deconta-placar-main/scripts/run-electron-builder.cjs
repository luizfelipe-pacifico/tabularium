const { spawnSync } = require("child_process");
const path = require("path");

const cliPath = path.join(
  __dirname,
  "..",
  "node_modules",
  "electron-builder",
  "cli.js",
);

const result = spawnSync(process.execPath, [cliPath, ...process.argv.slice(2)], {
  cwd: path.join(__dirname, ".."),
  stdio: "inherit",
  env: {
    ...process.env,
    CSC_IDENTITY_AUTO_DISCOVERY: "false",
  },
});

if (typeof result.status === "number") {
  process.exit(result.status);
}

process.exit(1);
