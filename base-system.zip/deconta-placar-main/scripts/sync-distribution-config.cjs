const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const initSqlJs = require("sql.js");

const repoRoot = path.resolve(__dirname, "..");
const outputPath = path.join(repoRoot, "electron", "distribution-config.json");
const appDataRoot = process.env.APPDATA || "";

const fallbackConfig = {
  fonteUrl:
    "https://script.google.com/macros/s/AKfycbzfkXYf6mzOOLRhCbQfB8gS7DVWpPNQf-GGiSGd3gJTjOcyJS6FJ_AXCTO9iYh_UJk/exec",
  intervalo: 5,
  emailAlerta: "",
  nomeAmbiente: "Producao",
  devProfiles: [],
};

main().catch((error) => {
  console.error("[build-config] Falha ao sincronizar configuracao distribuida:", error);
  process.exitCode = 1;
});

async function main() {
  const dbPath = findLatestDatabasePath();
  const distributionState = dbPath ? await readDistributionStateFromDb(dbPath) : null;
  const sharedConfig = pickSharedConfig(distributionState?.appConfig ?? null);
  const sharedLastData = pickSharedLastData(distributionState?.lastData ?? null);
  const revision = crypto
    .createHash("sha256")
    .update(JSON.stringify({ config: sharedConfig, lastData: sharedLastData }))
    .digest("hex")
    .slice(0, 16);

  const payload = {
    revision,
    config: sharedConfig,
    lastData: sharedLastData,
  };

  fs.writeFileSync(outputPath, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
  console.log(
    `[build-config] Configuracao distribuida atualizada em ${outputPath}${dbPath ? " usando banco local detectado" : " com fallback padrao"}`,
  );
}

function findLatestDatabasePath() {
  if (!appDataRoot || !fs.existsSync(appDataRoot)) {
    return null;
  }

  const candidates = new Set([
    path.join(appDataRoot, "Placar DeConta", "deconta.db"),
    path.join(appDataRoot, "Placar DêConta", "deconta.db"),
    path.join(appDataRoot, "deconta-placar", "deconta.db"),
  ]);

  for (const entry of fs.readdirSync(appDataRoot, { withFileTypes: true })) {
    if (!entry.isDirectory()) {
      continue;
    }

    candidates.add(path.join(appDataRoot, entry.name, "deconta.db"));
  }

  const existing = [...candidates]
    .filter((candidate) => fs.existsSync(candidate))
    .map((candidate) => ({
      path: candidate,
      mtimeMs: fs.statSync(candidate).mtimeMs,
    }))
    .sort((left, right) => right.mtimeMs - left.mtimeMs);

  return existing[0]?.path ?? null;
}

async function readDistributionStateFromDb(dbPath) {
  const SQL = await initSqlJs();
  const buffer = fs.readFileSync(dbPath);
  const db = new SQL.Database(buffer);

  try {
    return {
      appConfig: readJsonValue(db, "config", "app"),
      lastData: readJsonValue(db, "cache", "lastData"),
    };
  } finally {
    db.close();
  }
}

function readJsonValue(db, tableName, key) {
  const stmt = db.prepare(`SELECT value FROM ${tableName} WHERE key = ?`);
  stmt.bind([key]);

  if (!stmt.step()) {
    stmt.free();
    return null;
  }

  const row = stmt.getAsObject();
  stmt.free();

  if (typeof row.value !== "string" || row.value.trim().length === 0) {
    return null;
  }

  return JSON.parse(row.value);
}

function pickSharedConfig(input) {
  const raw = input && typeof input === "object" ? input : {};
  const devProfiles = Array.isArray(raw.devProfiles)
    ? raw.devProfiles
        .map((item) => normalizeDevProfile(item))
        .filter((item) => item !== null)
    : fallbackConfig.devProfiles;

  return {
    fonteUrl:
      typeof raw.fonteUrl === "string" && raw.fonteUrl.trim().length > 0
        ? raw.fonteUrl.trim()
        : fallbackConfig.fonteUrl,
    intervalo:
      typeof raw.intervalo === "number" && Number.isFinite(raw.intervalo) && raw.intervalo > 0
        ? raw.intervalo
        : fallbackConfig.intervalo,
    emailAlerta:
      typeof raw.emailAlerta === "string" ? raw.emailAlerta.trim() : fallbackConfig.emailAlerta,
    nomeAmbiente:
      typeof raw.nomeAmbiente === "string" && raw.nomeAmbiente.trim().length > 0
        ? raw.nomeAmbiente.trim()
        : fallbackConfig.nomeAmbiente,
    devProfiles,
  };
}

function pickSharedLastData(input) {
  if (!input || typeof input !== "object") {
    return null;
  }

  const { debug, ...snapshot } = input;
  return snapshot;
}

function normalizeDevProfile(input) {
  if (!input || typeof input !== "object") {
    return null;
  }

  const nome =
    typeof input.nome === "string" && input.nome.trim().length > 0
      ? input.nome.trim()
      : "";
  const email =
    typeof input.email === "string" && input.email.trim().length > 0
      ? input.email.trim()
      : "";

  if (!nome) {
    return null;
  }

  return {
    nome,
    email,
    fotoUrl:
      typeof input.fotoUrl === "string" && input.fotoUrl.trim().length > 0
        ? input.fotoUrl.trim()
        : "",
    cargo:
      typeof input.cargo === "string" && input.cargo.trim().length > 0
        ? input.cargo.trim()
        : "Desenvolvedor",
  };
}
