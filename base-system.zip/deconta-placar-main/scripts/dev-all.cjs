const { spawn, spawnSync } = require("child_process");
const waitOn = require("wait-on");

const children = [];
let shuttingDown = false;

function spawnProcess(command, args, extraEnv = {}) {
  const child = spawn(command, args, {
    stdio: "inherit",
    env: { ...process.env, ...extraEnv },
    shell: process.platform === "win32",
    windowsHide: false,
  });

  children.push(child);
  return child;
}

function shutdown(exitCode = 0) {
  if (shuttingDown) {
    return;
  }

  shuttingDown = true;

  for (const child of children) {
    if (!child.killed) {
      child.kill();
    }
  }

  process.exit(exitCode);
}

function handleChildExit(name, child, treatAsFailure = true) {
  child.on("exit", (code, signal) => {
    if (shuttingDown) {
      return;
    }

    if (signal) {
      console.error(`[dev-all] ${name} finalizou com sinal ${signal}.`);
      shutdown(1);
      return;
    }

    if (code && treatAsFailure) {
      console.error(`[dev-all] ${name} finalizou com codigo ${code}.`);
      shutdown(code);
      return;
    }

    if (name === "electron") {
      shutdown(code ?? 0);
    }
  });
}

process.on("SIGINT", () => shutdown(0));
process.on("SIGTERM", () => shutdown(0));

const killPort = spawnSync("pnpm", ["exec", "kill-port", "5173"], {
  stdio: "inherit",
  env: process.env,
  shell: process.platform === "win32",
  windowsHide: false,
});

if (killPort.status && killPort.status !== 0) {
  console.warn("[dev-all] nao foi possivel liberar a porta 5173; continuando.");
}

const vite = spawnProcess("pnpm", ["run", "dev"]);
handleChildExit("vite", vite);

const tscWatch = spawnProcess("pnpm", ["exec", "tsc", "-p", "tsconfig.electron.json", "--watch"]);
handleChildExit("tsc", tscWatch);

waitOn({
  resources: ["http://localhost:5173"],
  timeout: 30000,
})
  .then(() => {
    if (shuttingDown) {
      return;
    }

    const electron = spawnProcess(
      "node",
      ["scripts/launch-electron-dev.cjs", "."],
      { VITE_DEV_SERVER_URL: "http://localhost:5173" },
    );

    handleChildExit("electron", electron, false);
  })
  .catch((error) => {
    console.error("[dev-all] vite nao respondeu em http://localhost:5173.", error);
    shutdown(1);
  });
