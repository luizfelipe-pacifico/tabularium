const fs = require("fs");
const path = require("path");

function loadEnvFile() {
  const envPath = path.join(process.cwd(), ".env");
  if (!fs.existsSync(envPath)) {
    return;
  }

  const lines = fs.readFileSync(envPath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#") || !trimmed.includes("=")) {
      continue;
    }

    const index = trimmed.indexOf("=");
    const key = trimmed.slice(0, index).trim();
    const value = trimmed.slice(index + 1).trim().replace(/^["']|["']$/g, "");
    if (!process.env[key]) {
      process.env[key] = value;
    }
  }
}

async function main() {
  loadEnvFile();

  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error("DATABASE_URL nao encontrado no ambiente.");
  }

  let postgres;
  try {
    postgres = await import("postgres");
  } catch (error) {
    if (error && error.code === "ERR_MODULE_NOT_FOUND") {
      throw new Error(
        "Driver 'postgres' nao instalado. Instale com pnpm add postgres antes de aplicar a migracao automaticamente.",
      );
    }

    throw error;
  }
  const sql = postgres.default(databaseUrl, {
    max: 1,
    ssl: "require",
  });

  const migrationPath = path.join(
    process.cwd(),
    "db",
    "migrations",
    "001_neon_placar_schema.sql",
  );
  const migration = fs.readFileSync(migrationPath, "utf8");

  try {
    await sql.unsafe(migration);
    console.log("Neon schema aplicado com sucesso.");
  } finally {
    await sql.end({ timeout: 5 });
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exit(1);
});
