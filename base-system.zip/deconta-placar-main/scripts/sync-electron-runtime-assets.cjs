const fs = require("fs");
const path = require("path");

const rootDir = path.join(__dirname, "..");
const sourceDir = path.join(rootDir, "electron");
const runtimeDir = path.join(rootDir, "electron-build");
const staticFiles = ["distribution-config.json", "package.json"];
const runtimeAssetsDir = path.join(runtimeDir, "assets");

if (!fs.existsSync(runtimeDir)) {
  fs.mkdirSync(runtimeDir, { recursive: true });
}

if (!fs.existsSync(runtimeAssetsDir)) {
  fs.mkdirSync(runtimeAssetsDir, { recursive: true });
}

for (const fileName of staticFiles) {
  fs.copyFileSync(
    path.join(sourceDir, fileName),
    path.join(runtimeDir, fileName),
  );
}

fs.copyFileSync(
  path.join(rootDir, "public", "app-icon.png"),
  path.join(runtimeAssetsDir, "app-icon.png"),
);
