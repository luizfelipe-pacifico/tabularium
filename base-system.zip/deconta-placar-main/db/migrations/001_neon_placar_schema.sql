-- DeConta Placar Neon schema
-- Mirrors the normalized payload produced by the current Google Apps Script adapter.

create extension if not exists pgcrypto;

do $$ begin
  create type demand_status as enum ('Em aberto', 'Em andamento', 'Concluída', 'Recusada');
exception
  when duplicate_object then null;
end $$;

do $$ begin
  create type demand_priority as enum ('Crítica', 'Alta', 'Média', 'Baixa');
exception
  when duplicate_object then null;
end $$;

do $$ begin
  create type demand_category as enum ('Bug crítico', 'Bug leve', 'Melhoria', 'Sugestão');
exception
  when duplicate_object then null;
end $$;

do $$ begin
  create type demand_bucket as enum ('Controle', 'Histórico');
exception
  when duplicate_object then null;
end $$;

do $$ begin
  create type source_mode as enum ('remote', 'cache', 'fallback');
exception
  when duplicate_object then null;
end $$;

create table if not exists placar_sync_runs (
  id uuid primary key default gen_random_uuid(),
  source text not null default 'google_apps_script',
  mode source_mode not null default 'remote',
  success boolean not null default true,
  source_url text,
  message text,
  error text,
  raw_payload jsonb,
  adapted_payload jsonb,
  generated_at timestamptz,
  fetched_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create table if not exists placar_demands (
  id text primary key,
  requested_at timestamptz,
  display_date text not null default '-',
  bucket demand_bucket not null default 'Controle',
  requester_name text not null default '',
  requester_email text not null default '',
  client_name text not null default '',
  category demand_category not null default 'Melhoria',
  priority demand_priority not null default 'Média',
  status demand_status not null default 'Em aberto',
  operator_name text not null default 'Não atribuída',
  system_area text not null default '',
  exact_location text not null default '',
  description text not null default '',
  how_it_happened text not null default '',
  expected_behavior text not null default '',
  attachment_url text not null default '',
  extra_notes text not null default '',
  support_level text check (support_level in ('N1', 'N2', 'N3') or support_level is null),
  sla_minutes integer check (sla_minutes is null or sla_minutes >= 0),
  action_due_at timestamptz,
  roadmap_track_id uuid,
  source_run_id uuid references placar_sync_runs(id) on delete set null,
  source_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists placar_operators (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  avatar text not null default '?',
  email text not null default '',
  role text not null default 'Operador',
  total_count integer not null default 0,
  open_count integer not null default 0,
  in_progress_count integer not null default 0,
  completed_count integer not null default 0,
  refused_count integer not null default 0,
  active_count integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists placar_roadmap_tracks (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  horizon text not null default 'curto prazo',
  phase text not null default 'Fase 1',
  description text not null default '',
  progress integer not null default 0 check (progress between 0 and 100),
  owner_operator_id uuid references placar_operators(id) on delete set null,
  starts_at date,
  due_at date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table placar_demands
  drop constraint if exists placar_demands_roadmap_track_id_fkey;

alter table placar_demands
  add constraint placar_demands_roadmap_track_id_fkey
  foreign key (roadmap_track_id) references placar_roadmap_tracks(id) on delete set null;

create table if not exists placar_quick_notes (
  id uuid primary key default gen_random_uuid(),
  title text not null default 'Nota rápida',
  body text not null,
  converted_to_demand_id text references placar_demands(id) on delete set null,
  converted_to_track_id uuid references placar_roadmap_tracks(id) on delete set null,
  created_by text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists placar_dashboard_snapshots (
  id uuid primary key default gen_random_uuid(),
  sync_run_id uuid references placar_sync_runs(id) on delete cascade,
  total_demands integer not null default 0,
  total_active integer not null default 0,
  total_history integer not null default 0,
  open_count integer not null default 0,
  in_progress_count integer not null default 0,
  completed_count integer not null default 0,
  refused_count integer not null default 0,
  by_priority jsonb not null default '{}'::jsonb,
  by_category jsonb not null default '{}'::jsonb,
  by_operator jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_placar_demands_status on placar_demands(status);
create index if not exists idx_placar_demands_priority on placar_demands(priority);
create index if not exists idx_placar_demands_category on placar_demands(category);
create index if not exists idx_placar_demands_bucket on placar_demands(bucket);
create index if not exists idx_placar_demands_operator on placar_demands(operator_name);
create index if not exists idx_placar_demands_requested_at on placar_demands(requested_at desc);
create index if not exists idx_placar_demands_source_run on placar_demands(source_run_id);

create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create or replace function parse_placar_timestamptz(value text)
returns timestamptz as $$
begin
  if value is null or btrim(value) = '' or value = '-' then
    return null;
  end if;

  return value::timestamptz;
exception
  when others then
    return null;
end;
$$ language plpgsql immutable;

create or replace function infer_placar_support_level(priority text, category text)
returns text as $$
begin
  if priority = 'Crítica' or category = 'Bug crítico' then
    return 'N3';
  end if;

  if priority = 'Alta' or category = 'Bug leve' then
    return 'N2';
  end if;

  return 'N1';
end;
$$ language plpgsql immutable;

drop trigger if exists trg_placar_demands_updated_at on placar_demands;
create trigger trg_placar_demands_updated_at
before update on placar_demands
for each row execute function set_updated_at();

drop trigger if exists trg_placar_operators_updated_at on placar_operators;
create trigger trg_placar_operators_updated_at
before update on placar_operators
for each row execute function set_updated_at();

drop trigger if exists trg_placar_roadmap_tracks_updated_at on placar_roadmap_tracks;
create trigger trg_placar_roadmap_tracks_updated_at
before update on placar_roadmap_tracks
for each row execute function set_updated_at();

drop trigger if exists trg_placar_quick_notes_updated_at on placar_quick_notes;
create trigger trg_placar_quick_notes_updated_at
before update on placar_quick_notes
for each row execute function set_updated_at();

create or replace view placar_app_payload as
select
  coalesce(
    (
      select jsonb_build_object(
        'success', sr.success,
        'generatedAt', sr.generated_at,
        'lastUpdated', sr.fetched_at,
        'fonteUrl', sr.source_url,
        'sourceStatus', jsonb_build_object(
          'mode', sr.mode,
          'message', sr.message,
          'error', sr.error
        )
      )
      from placar_sync_runs sr
      order by sr.fetched_at desc
      limit 1
    ),
    '{}'::jsonb
  ) ||
  jsonb_build_object(
    'demandas', coalesce(jsonb_agg(to_jsonb(d) order by d.requested_at desc nulls last) filter (where d.id is not null), '[]'::jsonb),
    'demandasAtivas', coalesce(jsonb_agg(to_jsonb(d) order by d.requested_at desc nulls last) filter (where d.bucket = 'Controle'), '[]'::jsonb),
    'demandasHistorico', coalesce(jsonb_agg(to_jsonb(d) order by d.requested_at desc nulls last) filter (where d.bucket = 'Histórico'), '[]'::jsonb)
  ) as payload
from placar_demands d;

create or replace function upsert_placar_app_payload(payload jsonb, source_url text default null)
returns uuid as $$
declare
  sync_run uuid;
  source_mode_value text;
  generated_at_value timestamptz;
begin
  source_mode_value := coalesce(payload #>> '{sourceStatus,mode}', 'remote');
  if source_mode_value not in ('remote', 'cache', 'fallback') then
    source_mode_value := 'remote';
  end if;

  generated_at_value := parse_placar_timestamptz(payload->>'generatedAt');

  insert into placar_sync_runs (
    source,
    mode,
    success,
    source_url,
    message,
    error,
    raw_payload,
    adapted_payload,
    generated_at
  )
  values (
    'google_apps_script',
    source_mode_value::source_mode,
    coalesce((payload->>'success')::boolean, true),
    coalesce(source_url, payload->>'fonteUrl'),
    payload #>> '{sourceStatus,message}',
    payload #>> '{sourceStatus,error}',
    payload,
    payload,
    generated_at_value
  )
  returning id into sync_run;

  insert into placar_demands (
    id,
    requested_at,
    display_date,
    bucket,
    requester_name,
    requester_email,
    client_name,
    category,
    priority,
    status,
    operator_name,
    system_area,
    exact_location,
    description,
    how_it_happened,
    expected_behavior,
    attachment_url,
    extra_notes,
    support_level,
    source_run_id,
    source_payload
  )
  select
    demanda->>'id',
    parse_placar_timestamptz(coalesce(demanda->>'dataDaRequisicao', demanda->>'data')),
    coalesce(demanda->>'data', '-'),
    case
      when demanda->>'aba' = 'Histórico' then 'Histórico'::demand_bucket
      when demanda->>'status' in ('Concluída', 'Recusada') then 'Histórico'::demand_bucket
      else 'Controle'::demand_bucket
    end,
    coalesce(demanda->>'nome', ''),
    coalesce(demanda->>'email', ''),
    coalesce(demanda->>'cliente', ''),
    case
      when demanda->>'categoria' in ('Bug crítico', 'Bug leve', 'Melhoria', 'Sugestão')
        then (demanda->>'categoria')::demand_category
      else 'Melhoria'::demand_category
    end,
    case
      when demanda->>'grau' in ('Crítica', 'Alta', 'Média', 'Baixa')
        then (demanda->>'grau')::demand_priority
      else 'Média'::demand_priority
    end,
    case
      when demanda->>'status' in ('Em aberto', 'Em andamento', 'Concluída', 'Recusada')
        then (demanda->>'status')::demand_status
      else 'Em aberto'::demand_status
    end,
    coalesce(nullif(demanda->>'operador', ''), 'Não atribuída'),
    coalesce(demanda->>'area', ''),
    coalesce(demanda->>'localExato', ''),
    coalesce(demanda->>'descricao', ''),
    coalesce(demanda->>'comoAconteceu', ''),
    coalesce(demanda->>'oQueDeveriaAcontecer', ''),
    coalesce(demanda->>'anexo', ''),
    coalesce(demanda->>'observacoesExtras', ''),
    infer_placar_support_level(demanda->>'grau', demanda->>'categoria'),
    sync_run,
    demanda
  from jsonb_array_elements(coalesce(payload->'demandas', '[]'::jsonb)) as demanda
  where demanda ? 'id'
  on conflict (id) do update set
    requested_at = excluded.requested_at,
    display_date = excluded.display_date,
    bucket = excluded.bucket,
    requester_name = excluded.requester_name,
    requester_email = excluded.requester_email,
    client_name = excluded.client_name,
    category = excluded.category,
    priority = excluded.priority,
    status = excluded.status,
    operator_name = excluded.operator_name,
    system_area = excluded.system_area,
    exact_location = excluded.exact_location,
    description = excluded.description,
    how_it_happened = excluded.how_it_happened,
    expected_behavior = excluded.expected_behavior,
    attachment_url = excluded.attachment_url,
    extra_notes = excluded.extra_notes,
    support_level = excluded.support_level,
    source_run_id = excluded.source_run_id,
    source_payload = excluded.source_payload;

  insert into placar_operators (
    name,
    avatar,
    email,
    role,
    total_count,
    open_count,
    in_progress_count,
    completed_count,
    refused_count,
    active_count
  )
  select
    coalesce(nullif(operador->>'nome', ''), 'Não atribuída'),
    coalesce(nullif(operador->>'avatar', ''), '?'),
    coalesce(operador->>'email', ''),
    coalesce(nullif(operador->>'cargo', ''), 'Operador'),
    coalesce(nullif(operador->>'total', '')::integer, 0),
    coalesce(nullif(operador->>'abertas', '')::integer, 0),
    coalesce(nullif(operador->>'andamento', '')::integer, 0),
    coalesce(nullif(operador->>'concluidas', '')::integer, 0),
    coalesce(nullif(operador->>'recusadas', '')::integer, 0),
    coalesce(nullif(operador->>'ativas', '')::integer, 0)
  from jsonb_array_elements(coalesce(payload->'operadores', '[]'::jsonb)) as operador
  on conflict (name) do update set
    avatar = excluded.avatar,
    email = excluded.email,
    role = excluded.role,
    total_count = excluded.total_count,
    open_count = excluded.open_count,
    in_progress_count = excluded.in_progress_count,
    completed_count = excluded.completed_count,
    refused_count = excluded.refused_count,
    active_count = excluded.active_count;

  insert into placar_dashboard_snapshots (
    sync_run_id,
    total_demands,
    total_active,
    total_history,
    open_count,
    in_progress_count,
    completed_count,
    refused_count,
    by_priority,
    by_category,
    by_operator
  )
  values (
    sync_run,
    coalesce(nullif(payload #>> '{stats,totalDemandas}', '')::integer, 0),
    coalesce(nullif(payload #>> '{stats,totalAtivas}', '')::integer, 0),
    coalesce(nullif(payload #>> '{stats,totalHistorico}', '')::integer, 0),
    coalesce(nullif(payload #>> '{stats,emAberto}', '')::integer, 0),
    coalesce(nullif(payload #>> '{stats,emAndamento}', '')::integer, 0),
    coalesce(nullif(payload #>> '{stats,concluidas}', '')::integer, 0),
    coalesce(nullif(payload #>> '{stats,recusadas}', '')::integer, 0),
    coalesce(payload #> '{stats,porGrau}', '{}'::jsonb),
    coalesce(payload #> '{stats,porCategoria}', '{}'::jsonb),
    coalesce(payload #> '{stats,porOperador}', '{}'::jsonb)
  );

  return sync_run;
end;
$$ language plpgsql;
